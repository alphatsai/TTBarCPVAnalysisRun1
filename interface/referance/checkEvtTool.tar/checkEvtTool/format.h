#define MAX_LEPTONS 	128
#define MAX_TRACKS 	256
#define MAX_JETS 	128
#define MAX_PAIRS 	512
#define MAX_PHOTONS	64
#define MAX_GENS	64
#define MAX_Vertices    64
#define MAX_BX		64
#define N_TRIGGER_BOOKINGS	2014 // from 226 (CMSSW_3_6_1 : 8E29 & 1E31) to 644 (CMSSW_3_8_3 : 2E32) ; 904 (CMSSW_4_1_3 : 5E32); 1212 (CMSSW_4_1_4 : 1E33); 2014 (CMSSW_4_2_3)

#include <TTree.h>

//For CMSSW_3_8_3

class EvtInfoBranches {
   public:
      int   RunNo;
      int   EvtNo;
      int   BxNo;
      int   LumiNo;
      int   McFlag;	      	 // MC or not MC, that's the question
      int   McSigTag;     	 // MC Signature tag	 - 0: others, 1: 2L (opposite-sign), 2: 2L (same-sign), 3: 3L, 4: 4L
      int   McbprimeMode[2]; // b'(bar) decay mode   - 0: others, 1: tW, 2: cW, 3: bZ, 4: bH
      int   MctprimeMode[2]; // t'(bar) decay mode   - 0: others, 1: bW, 2: tZ, 3: tH, 4: tgamma
      int   McWMode[4];   // W- from b'(t'bar)/W+ from t/W+ from b'bar(t')/W- from tbar - 0: others, 1: enu, 2: munu, 3: taunu, 4: jj
      int 	McZMode[2];   	 // Z from b'(bar)/t'(t'bar)	 - 0: others, 1: ee, 2: mumu, 3: tautau, 4: nunu, 5: bb, 6: jj
      float McbprimeMass[2]; // mass: b'(bar)  
      float MctprimeMass[2]; // mass: t'(bar)  
      float MctopMass[2];	 // mass: top(bar)
      float McWMass[4];	 // mass: W- from b'(t'bar)/W+ from t/W+ from b'bar(t')/W- from tbar 
      float McZMass[2];	 // mass: Z from b'(bar) or t'(bar)
      float McDauPt[14];	 // Generic MC daughter information
      float McDauEta[14];	 // MC daughters: 0-1: hard jet from b'bar/t'bar, 2-9: W daughters, 10-13: Z daughters 
      float McDauPhi[14];	 
      float RhoPU;	 
      float SigmaPU;	 
      int   McDauPdgID[14];	 
      int   PDFid1;
      int   PDFid2;
      float PDFx1;
      float PDFx2;
      float PDFscale;
      float PDFv1;
      float PDFv2;
      float MET;
      float METPhi;
      float RawMET;
      float RawMETPhi;
      float SumEt;
      float METSig;
      float eLong;
      float MaxHadTower;
      float MaxEmTower;
      float FracHad;
      float FracEm;
      float GenMET;
      float GenMETPhi;

      // PU
      int nBX;
      int nPU[MAX_BX];
      int BXPU[MAX_BX];

      float PFMET;
      float PFMETPhi;
      float PFRawMET;
      float PFRawMETPhi;
      float PFSumEt;
      float PFMETSig;
      float PFGenMET;
      float PFGenMETPhi;

      float PFMETx; //Uly 2011-04-04
      float PFMETy; //Uly 2011-04-04

      int   TrgCount;	// No. of fired booking bits
      char  TrgBook[N_TRIGGER_BOOKINGS];	// Trigger bits, reserved up to 120 entries
      int   nHLT;
      bool  HLTbits[N_TRIGGER_BOOKINGS];
      int L1[128]; // L1 trigger bits
      int TT[64]; 	// Techical trigger bits
      float HighPurityFraction; //Added by Dmitry to help filter out bad events
      int NofTracks; //Added by Dmitry to help filter out bad events


      void RegisterTree(TTree *root) {
         root->Branch("EvtInfo.RunNo"	    , &RunNo	       , "EvtInfo.RunNo/I"	    );
         root->Branch("EvtInfo.EvtNo"	    , &EvtNo	       , "EvtInfo.EvtNo/I"	    );
         root->Branch("EvtInfo.BxNo"	    , &BxNo	           , "EvtInfo.BxNo/I"	    );
         root->Branch("EvtInfo.LumiNo"	    , &LumiNo	       , "EvtInfo.LumiNo/I"	    );
         root->Branch("EvtInfo.McFlag"	    , &McFlag	       , "EvtInfo.McFlag/I"	    );
         root->Branch("EvtInfo.McSigTag"	    , &McSigTag        , "EvtInfo.McSigTag/I"	    );
         root->Branch("EvtInfo.McbprimeMode" , &McbprimeMode[0] , "EvtInfo.McbprimeMode[2]/I");
         root->Branch("EvtInfo.MctprimeMode" , &MctprimeMode[0] , "EvtInfo.MctprimeMode[2]/I");
         root->Branch("EvtInfo.McWMode"      , &McWMode[0]      , "EvtInfo.McWMode[4]/I"     );
         root->Branch("EvtInfo.McZMode"      , &McZMode[0]      , "EvtInfo.McZMode[2]/I"     );
         root->Branch("EvtInfo.McbprimeMass" , &McbprimeMass[0] , "EvtInfo.McbprimeMass[2]/F");
         root->Branch("EvtInfo.MctprimeMass" , &MctprimeMass[0] , "EvtInfo.MctprimeMass[2]/F");
         root->Branch("EvtInfo.MctopMass"    , &MctopMass[0]    , "EvtInfo.MctopMass[2]/F"   );
         root->Branch("EvtInfo.McWMass"      , &McWMass[0]      , "EvtInfo.McWMass[4]/F"     );
         root->Branch("EvtInfo.McZMass"      , &McZMass[0]      , "EvtInfo.McZMass[2]/F"     );
         root->Branch("EvtInfo.McDauPt"      , &McDauPt[0]      , "EvtInfo.McDauPt[14]/F"    );
         root->Branch("EvtInfo.McDauEta"     , &McDauEta[0]     , "EvtInfo.McDauEta[14]/F"   );
         root->Branch("EvtInfo.McDauPhi"     , &McDauPhi[0]     , "EvtInfo.McDauPhi[14]/F"   );  	 
         root->Branch("EvtInfo.McDauPdgID"   , &McDauPdgID[0]   , "EvtInfo.McDauPdgID[14]/I" );  		 
         root->Branch("EvtInfo.PDFid1"	    , &PDFid1	       , "EvtInfo.PDFid1/I"	    );
         root->Branch("EvtInfo.PDFid2"	    , &PDFid2	       , "EvtInfo.PDFid2/I"	    );
         root->Branch("EvtInfo.PDFx1"	    , &PDFx1	       , "EvtInfo.PDFx1/F"	    );
         root->Branch("EvtInfo.RhoPU"	    , &RhoPU	       , "EvtInfo.RhoPU/F"	    );
         root->Branch("EvtInfo.SigmaPU"	    , &SigmaPU	       , "EvtInfo.SigmaPU/F"	    );
         root->Branch("EvtInfo.PDFx2"	    , &PDFx2	       , "EvtInfo.PDFx2/F"	    );
         root->Branch("EvtInfo.PDFscale"	    , &PDFscale	       , "EvtInfo.PDFscale/F"	    );
         root->Branch("EvtInfo.PDFv1"	    , &PDFv1	       , "EvtInfo.PDFv1/F"	    );
         root->Branch("EvtInfo.PDFv2"	    , &PDFv2	       , "EvtInfo.PDFv2/F"	    );		 
         root->Branch("EvtInfo.MET"	    , &MET	       , "EvtInfo.MET/F"	    );
         root->Branch("EvtInfo.METPhi"	    , &METPhi	       , "EvtInfo.METPhi/F"	    );
         root->Branch("EvtInfo.RawMET"	    , &RawMET	       , "EvtInfo.RawMET/F"	    );
         root->Branch("EvtInfo.RawMETPhi"    , &RawMETPhi       , "EvtInfo.RawMETPhi/F"      );
         root->Branch("EvtInfo.SumEt"	    , &SumEt	       , "EvtInfo.SumEt/F"	    );
         root->Branch("EvtInfo.METSig"	    , &METSig	       , "EvtInfo.METSig/F"	    );
         root->Branch("EvtInfo.eLong"	    , &eLong	       , "EvtInfo.eLong/F"	    );
         root->Branch("EvtInfo.MaxHadTower"  , &MaxHadTower     , "EvtInfo.MaxHadTower/F"    );  
         root->Branch("EvtInfo.MaxEmTower"   , &MaxEmTower      , "EvtInfo.MaxEmTower/F"     ); 
         root->Branch("EvtInfo.FracHad"      , &FracHad         , "EvtInfo.FracHad/F"	    );
         root->Branch("EvtInfo.FracEm"	    , &FracEm	       , "EvtInfo.FracEm/F"	    );
         root->Branch("EvtInfo.GenMET"	    , &GenMET	       , "EvtInfo.GenMET/F"	    );
         root->Branch("EvtInfo.GenMETPhi"    , &GenMETPhi       , "EvtInfo.GenMETPhi/F"      );
         root->Branch("EvtInfo.PFMET"          , &PFMET             , "EvtInfo.PFMET/F"            );
         root->Branch("EvtInfo.PFMETPhi"       , &PFMETPhi          , "EvtInfo.PFMETPhi/F"         );
         root->Branch("EvtInfo.PFRawMET"       , &PFRawMET          , "EvtInfo.PFRawMET/F"         );
         root->Branch("EvtInfo.PFRawMETPhi"    , &PFRawMETPhi       , "EvtInfo.PFRawMETPhi/F"      );
         root->Branch("EvtInfo.PFSumEt"        , &PFSumEt           , "EvtInfo.PFSumEt/F"          );
         root->Branch("EvtInfo.PFMETSig"       , &PFMETSig          , "EvtInfo.PFMETSig/F"         );
         root->Branch("EvtInfo.PFGenMET"       , &PFGenMET          , "EvtInfo.PFGenMET/F"         );
         root->Branch("EvtInfo.PFGenMETPhi"    , &PFGenMETPhi       , "EvtInfo.PFGenMETPhi/F"      );
         root->Branch("EvtInfo.PFMETx"         , &PFMETx            , "EvtInfo.PFMETx/F"            ); //Uly 2011-04-04
         root->Branch("EvtInfo.PFMETy"         , &PFMETy            , "EvtInfo.PFMETy/F"            ); //Uly 2011-04-04
         root->Branch("EvtInfo.TrgCount"     , &TrgCount        , "EvtInfo.TrgCount/I"	    );
         root->Branch("EvtInfo.TrgBook"      , &TrgBook[0]         , "EvtInfo.TrgBook[2014]/B"    );
         root->Branch("EvtInfo.L1"	        , &L1[0]	       , "EvtInfo.L1[128]/I"	    );
         root->Branch("EvtInfo.TT"	        , &TT[0]	       , "EvtInfo.TT[64]/I"	    );
         root->Branch("EvtInfo.HighPurityFraction"    , &HighPurityFraction       , "EvtInfo.HighPurityFraction/F"      );
         root->Branch("EvtInfo.NofTracks"    , &NofTracks       , "EvtInfo.NofTracks/I"      );
	 root->Branch("EvtInfo.nHLT"			, &nHLT	 		, "EvtInfo.nHLT/I");
	 root->Branch("EvtInfo.HLTbits"			, HLTbits		, "EvtInfo.HLTbits[EvtInfo.nHLT]/O");
	 root->Branch("EvtInfo.nBX"			, &nBX	 		, "EvtInfo.nBX/I");
	 root->Branch("EvtInfo.nPU"			, &nPU[0]		, "EvtInfo.nPU[EvtInfo.nBX]/I");
	 root->Branch("EvtInfo.BXPU"			, &BXPU[0]		, "EvtInfo.BXPU[EvtInfo.nBX]/I");
      }										    



      void Register(TTree *root) {
         root->SetBranchAddress("EvtInfo.RunNo"        , &RunNo  	 );
         root->SetBranchAddress("EvtInfo.EvtNo"        , &EvtNo  	 );
         root->SetBranchAddress("EvtInfo.BxNo"         , &BxNo   	 );
         root->SetBranchAddress("EvtInfo.LumiNo"       , &LumiNo  	 );
         root->SetBranchAddress("EvtInfo.McFlag"       , &McFlag 	 );
         root->SetBranchAddress("EvtInfo.McSigTag"     , &McSigTag	 );
         root->SetBranchAddress("EvtInfo.McbprimeMode" , &McbprimeMode[0] );
         root->SetBranchAddress("EvtInfo.MctprimeMode" , &MctprimeMode[0] );
         root->SetBranchAddress("EvtInfo.McWMode"      , &McWMode[0]	 );
         root->SetBranchAddress("EvtInfo.McZMode"      , &McZMode[0]	 );
         root->SetBranchAddress("EvtInfo.McbprimeMass" , &McbprimeMass[0] );
         root->SetBranchAddress("EvtInfo.MctprimeMass" , &MctprimeMass[0] );
         root->SetBranchAddress("EvtInfo.MctopMass"    , &MctopMass[0]    );
         root->SetBranchAddress("EvtInfo.McWMass"      , &McWMass[0]	 );
         root->SetBranchAddress("EvtInfo.McZMass"      , &McZMass[0]	 );
         root->SetBranchAddress("EvtInfo.McDauPt"      , &McDauPt[0]	 );
         root->SetBranchAddress("EvtInfo.McDauEta"     , &McDauEta[0]	 );
         root->SetBranchAddress("EvtInfo.McDauPhi"     , &McDauPhi[0]	 );	      
         root->SetBranchAddress("EvtInfo.McDauPdgID"   , &McDauPdgID[0]   );		      
         root->SetBranchAddress("EvtInfo.PDFid1"       , &PDFid1 	 );
         root->SetBranchAddress("EvtInfo.PDFid2"       , &PDFid2 	 );
         root->SetBranchAddress("EvtInfo.PDFx1"        , &PDFx1  	 );
         root->SetBranchAddress("EvtInfo.RhoPU"        , &RhoPU  	 );
         root->SetBranchAddress("EvtInfo.SigmaPU"        , &SigmaPU  	 );
         root->SetBranchAddress("EvtInfo.PDFx2"        , &PDFx2  	 );
         root->SetBranchAddress("EvtInfo.PDFscale"     , &PDFscale	 );
         root->SetBranchAddress("EvtInfo.PDFv1"        , &PDFv1  	 );
         root->SetBranchAddress("EvtInfo.PDFv2"        , &PDFv2  	 );	      
         root->SetBranchAddress("EvtInfo.MET"	      , &MET		 );
         root->SetBranchAddress("EvtInfo.METPhi"       , &METPhi 	 );
         root->SetBranchAddress("EvtInfo.RawMET"       , &RawMET 	 );
         root->SetBranchAddress("EvtInfo.RawMETPhi"    , &RawMETPhi	 );
         root->SetBranchAddress("EvtInfo.SumEt"        , &SumEt  	 );
         root->SetBranchAddress("EvtInfo.METSig"       , &METSig 	 );
         root->SetBranchAddress("EvtInfo.eLong"        , &eLong  	 );
         root->SetBranchAddress("EvtInfo.MaxHadTower"  , &MaxHadTower	 );  
         root->SetBranchAddress("EvtInfo.MaxEmTower"   , &MaxEmTower	 ); 
         root->SetBranchAddress("EvtInfo.FracHad"      , &FracHad	 );
         root->SetBranchAddress("EvtInfo.FracEm"       , &FracEm 	 );
         root->SetBranchAddress("EvtInfo.GenMET"       , &GenMET 	 );
         root->SetBranchAddress("EvtInfo.GenMETPhi"    , &GenMETPhi	 );

         root->SetBranchAddress("EvtInfo.PFMET"          , &PFMET             );
         root->SetBranchAddress("EvtInfo.PFMETPhi"       , &PFMETPhi          );
         root->SetBranchAddress("EvtInfo.PFRawMET"       , &PFRawMET          );
         root->SetBranchAddress("EvtInfo.PFRawMETPhi"    , &PFRawMETPhi       );
         root->SetBranchAddress("EvtInfo.PFSumEt"        , &PFSumEt           );
         root->SetBranchAddress("EvtInfo.PFMETSig"       , &PFMETSig          );
         root->SetBranchAddress("EvtInfo.PFGenMET"       , &PFGenMET          );
         root->SetBranchAddress("EvtInfo.PFGenMETPhi"    , &PFGenMETPhi       );
         root->SetBranchAddress("EvtInfo.PFMETx"         , &PFMETx            ); //Uly 2011-04-04
         root->SetBranchAddress("EvtInfo.PFMETy"         , &PFMETy            ); //Uly 2011-04-04

         root->SetBranchAddress("EvtInfo.TrgCount"     , &TrgCount	 );
         root->SetBranchAddress("EvtInfo.TrgBook"      , &TrgBook[0]	 );
         root->SetBranchAddress("EvtInfo.L1"           , &L1[0]  	 );
         root->SetBranchAddress("EvtInfo.TT"           , &TT[0]  	 );
         root->SetBranchAddress("EvtInfo.HighPurityFraction"   , &HighPurityFraction	 );
         root->SetBranchAddress("EvtInfo.NofTracks"    , &NofTracks	 );
	 root->SetBranchAddress("EvtInfo.nHLT"			, &nHLT	);
	 root->SetBranchAddress("EvtInfo.HLTbits"			, HLTbits);
	 root->SetBranchAddress("EvtInfo.nBX"			, &nBX);
	 root->SetBranchAddress("EvtInfo.nPU"			, &nPU[0]);
	 root->SetBranchAddress("EvtInfo.BXPU"			, &BXPU[0]);
      }  										    
};


class LepInfoBranches {
   public:
      int	Size; 
      int	Index[MAX_LEPTONS];
      int	isEcalDriven[MAX_LEPTONS];
      int	isTrackerDriven[MAX_LEPTONS];
      int	LeptonType[MAX_LEPTONS];
      int	Charge[MAX_LEPTONS];
      float Pt[MAX_LEPTONS];
      float Et[MAX_LEPTONS];
      float Eta[MAX_LEPTONS];
      float caloEta[MAX_LEPTONS];
      float Phi[MAX_LEPTONS];
      float TrackIso[MAX_LEPTONS];
      float EcalIso[MAX_LEPTONS];
      float HcalIso[MAX_LEPTONS];
      float HcalDepth1Iso[MAX_LEPTONS];
      float HcalDepth2Iso[MAX_LEPTONS];
      float CaloEnergy[MAX_LEPTONS];
      float e1x5[MAX_LEPTONS];
      float e2x5Max[MAX_LEPTONS];
      float e5x5[MAX_LEPTONS];

      float Px[MAX_LEPTONS]; //Uly 2011-04-04
      float Py[MAX_LEPTONS]; //Uly 2011-04-04
      float Pz[MAX_LEPTONS]; //Uly 2011-04-04
      float Energy[MAX_LEPTONS]; //Uly 2011-04-04

      float vertexZ[MAX_LEPTONS]; //Uly 2011-04-04

      bool  MuIDAllGlobalMuons[MAX_LEPTONS];
      bool  MuIDAllStandAloneMuons[MAX_LEPTONS];
      bool  MuIDAllTrackerMuons[MAX_LEPTONS];
      bool  MuIDTrackerMuonArbitrated[MAX_LEPTONS];
      bool  MuIDAllArbitrated[MAX_LEPTONS];
      bool  MuIDGlobalMuonPromptTight[MAX_LEPTONS];
      bool  MuIDTMLastStationLoose[MAX_LEPTONS];
      bool  MuIDTMLastStationTight[MAX_LEPTONS];
      bool  MuIDTM2DCompatibilityLoose[MAX_LEPTONS];
      bool  MuIDTM2DCompatibilityTight[MAX_LEPTONS];
      bool  MuIDTMOneStationLoose[MAX_LEPTONS];
      bool  MuIDTMOneStationTight[MAX_LEPTONS];
      bool  MuIDTMLastStationOptimizedLowPtLoose[MAX_LEPTONS];
      bool  MuIDTMLastStationOptimizedLowPtTight[MAX_LEPTONS];
      bool  MuIDGMTkChiCompatibility[MAX_LEPTONS];
      bool  MuIDGMStaChiCompatibility[MAX_LEPTONS];
      bool  MuIDGMTkKinkTight[MAX_LEPTONS];
      bool  MuIDTMLastStationAngLoose[MAX_LEPTONS];
      bool  MuIDTMLastStationAngTight[MAX_LEPTONS];
      bool  MuIDTMOneStationAngLoose[MAX_LEPTONS];
      bool  MuIDTMOneStationAngTight[MAX_LEPTONS];
      bool  MuIDTMLastStationOptimizedBarrelLowPtLoose[MAX_LEPTONS];
      bool  MuIDTMLastStationOptimizedBarrelLowPtTight[MAX_LEPTONS];

      float MuInnerTrackDz[MAX_LEPTONS];  
      float MuInnerTrackD0[MAX_LEPTONS];  
      float MuInnerTrackDxy_BS[MAX_LEPTONS];  
      float MuInnerTrackDxy_PV[MAX_LEPTONS];  
      float MuInnerTrackDxy_PVBS[MAX_LEPTONS];  
      int   MuInnerTrackNHits[MAX_LEPTONS];
      int   MuNTrackerHits[MAX_LEPTONS];

      float MuGlobalNormalizedChi2[MAX_LEPTONS]; // Dmitry
      float dRmin_10[MAX_LEPTONS]; // Dmitry
      float dRmin_15[MAX_LEPTONS]; // Dmitry
      float dRmin_20[MAX_LEPTONS]; // Dmitry
      float dRmin_05[MAX_LEPTONS]; // Dmitry
      float dRmin[MAX_LEPTONS]; // Dmitry
      float dRminOfficial[MAX_LEPTONS]; // Dmitry
      float dRminOfficial_dz[MAX_LEPTONS]; // Dmitry
      float dRminOfficial_dxy[MAX_LEPTONS]; // Dmitry only for muons now
      float dRminOfficial_PtMin[MAX_LEPTONS]; // Dmitry only for electrons now

      float MuCaloCompat[MAX_LEPTONS];
      int   MuNChambers[MAX_LEPTONS];
      int   MuNChambersMatchesSegment[MAX_LEPTONS];
      int   MuNPixelLayers[MAX_LEPTONS];
      int   MuNPixelLayersWMeasurement[MAX_LEPTONS]; //Uly 2011-04-04
      int   MuNLostInnerHits[MAX_LEPTONS];
      int   MuNLostOuterHits[MAX_LEPTONS];
      int   MuNMuonhits[MAX_LEPTONS];
      int   MuType[MAX_LEPTONS];

      float simpleEleId95relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId90relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId85relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId80relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId70relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId60relIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId95cIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId90cIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId85cIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId80cIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId70cIso[MAX_LEPTONS]; // Add by Jacky
      float simpleEleId60cIso[MAX_LEPTONS]; // Add by Jacky

      // CIC without ISO
      float eidVeryLoose[MAX_LEPTONS];
      float eidLoose[MAX_LEPTONS];
      float eidMedium[MAX_LEPTONS];
      float eidTight[MAX_LEPTONS];
      float eidSuperTight[MAX_LEPTONS];
      float eidHyperTight1[MAX_LEPTONS];
      float eidHyperTight2[MAX_LEPTONS];
      float eidHyperTight3[MAX_LEPTONS];
      float eidHyperTight4[MAX_LEPTONS];
      // CIC with ISO
      float eidVeryLooseMC[MAX_LEPTONS];
      float eidLooseMC[MAX_LEPTONS];
      float eidMediumMC[MAX_LEPTONS];
      float eidTightMC[MAX_LEPTONS];
      float eidSuperTightMC[MAX_LEPTONS];
      float eidHyperTight1MC[MAX_LEPTONS];
      float eidHyperTight2MC[MAX_LEPTONS];
      float eidHyperTight3MC[MAX_LEPTONS];
      float eidHyperTight4MC[MAX_LEPTONS];


      float ElEoverP[MAX_LEPTONS];
      float EldeltaEta[MAX_LEPTONS];
      float EldeltaPhi[MAX_LEPTONS]; 
      float ElHadoverEm[MAX_LEPTONS];
      float ElsigmaIetaIeta[MAX_LEPTONS];	// Jacky
      float ElscSigmaIetaIeta[MAX_LEPTONS];	// Jacky
      float ElEnergyErr[MAX_LEPTONS];
      float ElMomentumErr[MAX_LEPTONS];
      int	ElTrackNHits[MAX_LEPTONS]; //Dmitry
      float ElSharedHitsFraction[MAX_LEPTONS]; //Dmitry
      float dR_gsf_ctfTrack[MAX_LEPTONS]; //Dmitry
      float dPt_gsf_ctfTrack[MAX_LEPTONS]; //Dmitry

      float ElTrackNLostHits[MAX_LEPTONS];  //yjlei
      float ElTrackD0[MAX_LEPTONS];  
      float ElTrackDxy_BS[MAX_LEPTONS];  
      float ElTrackDxy_PV[MAX_LEPTONS];  
      float ElTrackDxy_PVBS[MAX_LEPTONS]; //yjlei
      int	ElNClusters[MAX_LEPTONS];
      int	ElClassification[MAX_LEPTONS];
      float	ElFBrem[MAX_LEPTONS];
      int NumberOfExpectedInnerHits[MAX_LEPTONS]; // Add by Jacky
      float Eldist[MAX_LEPTONS]; // Add by Jacky
      float Eldcot[MAX_LEPTONS]; // Add by Jacky
      float Elconvradius[MAX_LEPTONS]; // Add by Jacky
      float ElConvPoint_x[MAX_LEPTONS]; // Add by Jacky
      float ElConvPoint_y[MAX_LEPTONS]; // Add by Jacky
      float ElConvPoint_z[MAX_LEPTONS]; // Add by Jacky

      // For CIC	
      float dcotdist[MAX_LEPTONS];
      float ElseedEoverP[MAX_LEPTONS];
      float ElEcalIso04[MAX_LEPTONS];
      float ElHcalIso04[MAX_LEPTONS];

      int	ElNumberOfBrems[MAX_LEPTONS];
      float GenPt[MAX_LEPTONS];
      float GenEta[MAX_LEPTONS];
      float GenPhi[MAX_LEPTONS];
      int	GenPdgID[MAX_LEPTONS];
      int	GenMCTag[MAX_LEPTONS]; 	// 0: unknown, 1: decay from W, 2: decay from Z, 
      // 3: from b, 4: from c, 5: match to a parton (q or g), 6: match to a photon
      // (+10) from b'
      // (+20) from t'
      float TrgPt[MAX_LEPTONS];
      float TrgEta[MAX_LEPTONS];
      float TrgPhi[MAX_LEPTONS];
      int TrgID[MAX_LEPTONS];

#ifdef __BPRIMEKIT__
      reco::Candidate* CandRef[MAX_LEPTONS]; // backward pointer to the PAT objects
#endif

      void RegisterTree(TTree *root) {
         root->Branch("LepInfo.Size"	     		 , &Size	  		 , "LepInfo.Size/I"			     	       );
         root->Branch("LepInfo.Index"	     		 , &Index[0]	  		 , "LepInfo.Index[LepInfo.Size]/I"	     	       );
         root->Branch("LepInfo.isEcalDriven"	     	 , &isEcalDriven[0]  		 , "LepInfo.isEcalDriven[LepInfo.Size]/I"	     	       );
         root->Branch("LepInfo.isTrackerDriven"	     	 , &isTrackerDriven[0]  	 , "LepInfo.isTrackerDriven[LepInfo.Size]/I"	     	       );
         root->Branch("LepInfo.LeptonType"    		 , &LeptonType[0] 		 , "LepInfo.LeptonType[LepInfo.Size]/I"    	       );
         root->Branch("LepInfo.Charge"	     		 , &Charge[0]	  		 , "LepInfo.Charge[LepInfo.Size]/I"	     	       );
         root->Branch("LepInfo.Pt"	     		 , &Pt[0]	  		 , "LepInfo.Pt[LepInfo.Size]/F"      		       );
         root->Branch("LepInfo.Et"	     		 , &Et[0]	  		 , "LepInfo.Et[LepInfo.Size]/F"      		       );
         root->Branch("LepInfo.Eta"	     		 , &Eta[0]	  		 , "LepInfo.Eta[LepInfo.Size]/F"     		       );
         root->Branch("LepInfo.caloEta"	     		 , &caloEta[0]	  		 , "LepInfo.caloEta[LepInfo.Size]/F"     		       );
         root->Branch("LepInfo.Phi"	     		 , &Phi[0]	  		 , "LepInfo.Phi[LepInfo.Size]/F"     		       );
         root->Branch("LepInfo.TrackIso"      		 , &TrackIso[0]   		 , "LepInfo.TrackIso[LepInfo.Size]/F"	   	       );
         root->Branch("LepInfo.EcalIso"       		 , &EcalIso[0]    		 , "LepInfo.EcalIso[LepInfo.Size]/F"	     	       );   
         root->Branch("LepInfo.HcalIso"       		 , &HcalIso[0]    		 , "LepInfo.HcalIso[LepInfo.Size]/F"	     	       ); 
         root->Branch("LepInfo.HcalDepth1Iso"       	 , &HcalDepth1Iso[0]   		 , "LepInfo.HcalDepth1Iso[LepInfo.Size]/F"	     	       ); 
         root->Branch("LepInfo.HcalDepth2Iso"       	 , &HcalDepth2Iso[0]   		 , "LepInfo.HcalDepth2Iso[LepInfo.Size]/F"	     	       ); 
         root->Branch("LepInfo.CaloEnergy"    	     	 , &CaloEnergy[0]	  	 , "LepInfo.CaloEnergy[LepInfo.Size]/F"    	       );      
         root->Branch("LepInfo.e1x5"    	         , &e1x5[0]	  	         , "LepInfo.e1x5[LepInfo.Size]/F"    	       );      
         root->Branch("LepInfo.e2x5Max"    	     	 , &e2x5Max[0]	  	         , "LepInfo.e2x5Max[LepInfo.Size]/F"    	       );      
         root->Branch("LepInfo.e5x5"    	         , &e5x5[0]	  	         , "LepInfo.e5x5[LepInfo.Size]/F"    	       );      

         root->Branch("LepInfo.Px"	     		 , &Px[0]	  		 , "LepInfo.Px[LepInfo.Size]/F"      		       ); //Uly 2011-04-04
         root->Branch("LepInfo.Py"	     		 , &Py[0]	  		 , "LepInfo.Py[LepInfo.Size]/F"      		       ); //Uly 2011-04-04
         root->Branch("LepInfo.Pz"	     		 , &Pz[0]	  		 , "LepInfo.Pz[LepInfo.Size]/F"      		       ); //Uly 2011-04-04
         root->Branch("LepInfo.Energy"	     		 , &Energy[0]	  		 , "LepInfo.Energy[LepInfo.Size]/F"    		       ); //Uly 2011-04-04

         root->Branch("LepInfo.vertexZ"    	         , &vertexZ[0]	  	         , "LepInfo.vertexZ[LepInfo.Size]/F"    	       ); //Uly 2011-04-04


         root->Branch("LepInfo.MuIDAllGlobalMuons"                   , &MuIDAllGlobalMuons[0]                   , "LepInfo.MuIDAllGlobalMuons[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDAllTrackerMuons"                   , &MuIDAllTrackerMuons[0]                   , "LepInfo.MuIDAllTrackerMuons[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTrackerMuonArbitrated"                   , &MuIDTrackerMuonArbitrated[0]                   , "LepInfo.MuIDTrackerMuonArbitrated[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDAllArbitrated"                   , &MuIDAllArbitrated[0]                   , "LepInfo.MuIDAllArbitrated[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDGlobalMuonPromptTight"                   , &MuIDGlobalMuonPromptTight[0]                   , "LepInfo.MuIDGlobalMuonPromptTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationLoose"                   , &MuIDTMLastStationLoose[0]                   , "LepInfo.MuIDTMLastStationLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationTight"                   , &MuIDTMLastStationTight[0]                   , "LepInfo.MuIDTMLastStationTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTM2DCompatibilityTight"                   , &MuIDTM2DCompatibilityTight[0]                   , "LepInfo.MuIDTM2DCompatibilityTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMOneStationLoose"                   , &MuIDTMOneStationLoose[0]                   , "LepInfo.MuIDTMOneStationLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMOneStationTight"                   , &MuIDTMOneStationTight[0]                   , "LepInfo.MuIDTMOneStationTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationOptimizedLowPtLoose"                   , &MuIDTMLastStationOptimizedLowPtLoose[0]                   , "LepInfo.MuIDTMLastStationOptimizedLowPtLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationOptimizedLowPtTight"                   , &MuIDTMLastStationOptimizedLowPtTight[0]                   , "LepInfo.MuIDTMLastStationOptimizedLowPtTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDGMTkChiCompatibility"                   , &MuIDGMTkChiCompatibility[0]                   , "LepInfo.MuIDGMTkChiCompatibility[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDGMStaChiCompatibility"                   , &MuIDGMStaChiCompatibility[0]                   , "LepInfo.MuIDGMStaChiCompatibility[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDGMTkKinkTight"                   , &MuIDGMTkKinkTight[0]                   , "LepInfo.MuIDGMTkKinkTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationAngLoose"                   , &MuIDTMLastStationAngLoose[0]                   , "LepInfo.MuIDTMLastStationAngLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationAngTight"                   , &MuIDTMLastStationAngTight[0]                   , "LepInfo.MuIDTMLastStationAngTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMOneStationAngLoose"                   , &MuIDTMOneStationAngLoose[0]                   , "LepInfo.MuIDTMOneStationAngLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMOneStationAngTight"                   , &MuIDTMOneStationAngTight[0]                   , "LepInfo.MuIDTMOneStationAngTight[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationOptimizedBarrelLowPtLoose"                   , &MuIDTMLastStationOptimizedBarrelLowPtLoose[0]                   , "LepInfo.MuIDTMLastStationOptimizedBarrelLowPtLoose[LepInfo.Size]/O"                   );  // Add by Jacky
         root->Branch("LepInfo.MuIDTMLastStationOptimizedBarrelLowPtTight"                   , &MuIDTMLastStationOptimizedBarrelLowPtTight[0]                   , "LepInfo.MuIDTMLastStationOptimizedBarrelLowPtTight[LepInfo.Size]/O"                   );  // Add by Jacky


         root->Branch("LepInfo.MuInnerTrackDz"            , &MuInnerTrackDz[0]            , "LepInfo.MuInnerTrackDz[LepInfo.Size]/F"            );
         root->Branch("LepInfo.MuInnerTrackD0"            , &MuInnerTrackD0[0]            , "LepInfo.MuInnerTrackD0[LepInfo.Size]/F"            );
         root->Branch("LepInfo.MuInnerTrackDxy_BS"        , &MuInnerTrackDxy_BS[0]        , "LepInfo.MuInnerTrackDxy_BS[LepInfo.Size]/F"            );
         root->Branch("LepInfo.MuInnerTrackDxy_PV"        , &MuInnerTrackDxy_PV[0]        , "LepInfo.MuInnerTrackDxy_PV[LepInfo.Size]/F"            );
         root->Branch("LepInfo.MuInnerTrackDxy_PVBS"      , &MuInnerTrackDxy_PVBS[0]      , "LepInfo.MuInnerTrackDxy_PVBS[LepInfo.Size]/F"            );
         root->Branch("LepInfo.MuInnerTrackNHits"         , &MuInnerTrackNHits[0]         , "LepInfo.MuInnerTrackNHits[LepInfo.Size]/I"         );	
         root->Branch("LepInfo.MuNTrackerHits"            , &MuNTrackerHits[0]            , "LepInfo.MuNTrackerHits[LepInfo.Size]/I"         );	
         root->Branch("LepInfo.MuCaloCompat"              , &MuCaloCompat[0]              , "LepInfo.MuCaloCompat[LepInfo.Size]/F"              );
         root->Branch("LepInfo.MuNChambers"               , &MuNChambers[0] 	         , "LepInfo.MuNChambers[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuNChambersMatchesSegment" , &MuNChambersMatchesSegment[0] , "LepInfo.MuNChambersMatchesSegment[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuNPixelLayers"            , &MuNPixelLayers[0]            , "LepInfo.MuNPixelLayers[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuNPixelLayersWMeasurement", &MuNPixelLayersWMeasurement[0], "LepInfo.MuNPixelLayersWMeasurement[LepInfo.Size]/I"       ); //Uly 2011-04-04
         root->Branch("LepInfo.MuNLostInnerHits"          , &MuNLostInnerHits[0]          , "LepInfo.MuNLostInnerHits[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuNLostOuterHits"          , &MuNLostOuterHits[0]          , "LepInfo.MuNLostOuterHits[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuNMuonhits"               , &MuNMuonhits[0]               , "LepInfo.MuNMuonhits[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.MuType"	                 , &MuType[0]	                 , "LepInfo.MuType[LepInfo.Size]/I"        	       );

         root->Branch("LepInfo.MuGlobalNormalizedChi2"    , &MuGlobalNormalizedChi2[0] 	 , "LepInfo.MuGlobalNormalizedChi2[LepInfo.Size]/F"    ); //Dmitry
         root->Branch("LepInfo.dRmin_20"	                 , &dRmin_20[0]	         	 , "LepInfo.dRmin_20[LepInfo.Size]/F"        	       ); //Dmitry
         root->Branch("LepInfo.dRmin_15"	                 , &dRmin_15[0]	         	 , "LepInfo.dRmin_15[LepInfo.Size]/F"        	       ); //Dmitry
         root->Branch("LepInfo.dRmin_10"	                 , &dRmin_10[0]	         	 , "LepInfo.dRmin_10[LepInfo.Size]/F"        	       ); //Dmitry
         root->Branch("LepInfo.dRmin_05"	                 , &dRmin_05[0]	         	 , "LepInfo.dRmin_05[LepInfo.Size]/F"        	       ); //Dmitry
         root->Branch("LepInfo.dRmin"	                 , &dRmin[0]   	         	 , "LepInfo.dRmin[LepInfo.Size]/F"        	       ); //Dmitry
         root->Branch("LepInfo.dRminOfficial"	         , &dRminOfficial[0]             , "LepInfo.dRminOfficial[LepInfo.Size]/F"   	       ); //Dmitry
         root->Branch("LepInfo.dRminOfficial_dz"	         , &dRminOfficial_dz[0]          , "LepInfo.dRminOfficial_dz[LepInfo.Size]/F"         ); //Dmitry
         root->Branch("LepInfo.dRminOfficial_dxy"         , &dRminOfficial_dxy[0]         , "LepInfo.dRminOfficial_dxy[LepInfo.Size]/F"         ); //Dmitry
         root->Branch("LepInfo.dRminOfficial_PtMin"         , &dRminOfficial_PtMin[0]         , "LepInfo.dRminOfficial_PtMin[LepInfo.Size]/F"         ); //Dmitry

         root->Branch("LepInfo.ElTrackNLostHits"           , &ElTrackNLostHits[0]	         , "LepInfo.ElTrackNLostHits[LepInfo.Size]/F"	       );  //yjlei
         root->Branch("LepInfo.ElTrackD0"            , &ElTrackD0[0]            , "LepInfo.ElTrackD0[LepInfo.Size]/F"            );
         root->Branch("LepInfo.ElTrackDxy_BS"            , &ElTrackDxy_BS[0]            , "LepInfo.ElTrackDxy_BS[LepInfo.Size]/F"            );
         root->Branch("LepInfo.ElTrackDxy_PV"            , &ElTrackDxy_PV[0]            , "LepInfo.ElTrackDxy_PV[LepInfo.Size]/F"            );
         root->Branch("LepInfo.ElTrackDxy_PVBS"            , &ElTrackDxy_PVBS[0]            , "LepInfo.ElTrackDxy_PVBS[LepInfo.Size]/F"            );

         root->Branch("LepInfo.simpleEleId95relIso"                   , &simpleEleId95relIso[0]                   , "LepInfo.simpleEleId95relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId90relIso"                   , &simpleEleId90relIso[0]                   , "LepInfo.simpleEleId90relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId85relIso"                   , &simpleEleId85relIso[0]                   , "LepInfo.simpleEleId85relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId80relIso"                   , &simpleEleId80relIso[0]                   , "LepInfo.simpleEleId80relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId70relIso"                   , &simpleEleId70relIso[0]                   , "LepInfo.simpleEleId70relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId60relIso"                   , &simpleEleId60relIso[0]                   , "LepInfo.simpleEleId60relIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId95cIso"                   , &simpleEleId95cIso[0]                   , "LepInfo.simpleEleId95cIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId90cIso"                   , &simpleEleId90cIso[0]                   , "LepInfo.simpleEleId90cIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId85cIso"                   , &simpleEleId85cIso[0]                   , "LepInfo.simpleEleId85cIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId80cIso"                   , &simpleEleId80cIso[0]                   , "LepInfo.simpleEleId80cIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId70cIso"                   , &simpleEleId70cIso[0]                   , "LepInfo.simpleEleId70cIso[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.simpleEleId60cIso"                   , &simpleEleId60cIso[0]                   , "LepInfo.simpleEleId60cIso[LepInfo.Size]/F"                  );  // Add by Jacky

	 root->Branch("LepInfo.eidVeryLoose", &eidVeryLoose[0]                   , "LepInfo.eidVeryLoose[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidLoose", &eidLoose[0]                   , "LepInfo.eidLoose[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidMedium", &eidMedium[0]                   , "LepInfo.eidMedium[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidTight", &eidTight[0]                   , "LepInfo.eidTight[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidSuperTight", &eidSuperTight[0]                   , "LepInfo.eidSuperTight[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight1", &eidHyperTight1[0]                   , "LepInfo.eidHyperTight1[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight2", &eidHyperTight2[0]                   , "LepInfo.eidHyperTight2[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight3", &eidHyperTight3[0]                   , "LepInfo.eidHyperTight3[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight4", &eidHyperTight4[0]                   , "LepInfo.eidHyperTight4[LepInfo.Size]/F");

	 root->Branch("LepInfo.eidVeryLooseMC", &eidVeryLooseMC[0]                   , "LepInfo.eidVeryLooseMC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidLooseMC", &eidLooseMC[0]                   , "LepInfo.eidLooseMC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidMediumMC", &eidMediumMC[0]                   , "LepInfo.eidMediumMC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidTightMC", &eidTightMC[0]                   , "LepInfo.eidTightMC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidSuperTightMC", &eidSuperTightMC[0]                   , "LepInfo.eidSuperTightMC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight1MC", &eidHyperTight1MC[0]                 , "LepInfo.eidHyperTight1MC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight2MC", &eidHyperTight2MC[0]                 , "LepInfo.eidHyperTight2MC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight3MC", &eidHyperTight3MC[0]                 , "LepInfo.eidHyperTight3MC[LepInfo.Size]/F");
	 root->Branch("LepInfo.eidHyperTight4MC", &eidHyperTight4MC[0]                 , "LepInfo.eidHyperTight4MC[LepInfo.Size]/F");

         root->Branch("LepInfo.ElEoverP"         	 , &ElEoverP[0]      		 , "LepInfo.ElEoverP[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.EldeltaEta"       	 , &EldeltaEta[0]    		 , "LepInfo.EldeltaEta[LepInfo.Size]/F"     	       );
         root->Branch("LepInfo.EldeltaPhi"       	 , &EldeltaPhi[0]    		 , "LepInfo.EldeltaPhi[LepInfo.Size]/F"     	       );
         root->Branch("LepInfo.ElHadoverEm"      	 , &ElHadoverEm[0]   		 , "LepInfo.ElHadoverEm[LepInfo.Size]/F"    	       );
         root->Branch("LepInfo.ElsigmaIetaIeta"      	 , &ElsigmaIetaIeta[0] 		 , "LepInfo.ElsigmaIetaIeta[LepInfo.Size]/F"   	       ); // Jacky
         root->Branch("LepInfo.ElscSigmaIetaIeta"      	 , &ElscSigmaIetaIeta[0] 	 , "LepInfo.ElscSigmaIetaIeta[LepInfo.Size]/F"   	       ); // Jacky
         root->Branch("LepInfo.ElEnergyErr"      	 , &ElEnergyErr[0]   		 , "LepInfo.ElEnergyErr[LepInfo.Size]/F"    	       );
         root->Branch("LepInfo.ElMomentumErr"    	 , &ElMomentumErr[0] 		 , "LepInfo.ElMomentumErr[LepInfo.Size]/F"  	       );
         root->Branch("LepInfo.ElTrackNHits"     	 , &ElTrackNHits[0]  		 , "LepInfo.ElTrackNHits[LepInfo.Size]/I"   	       );
         root->Branch("LepInfo.ElSharedHitsFraction"      , &ElSharedHitsFraction[0]      , "ElSharedHitsFraction[LepInfo.Size]/F"              ); //Dmitry
         root->Branch("LepInfo.dR_gsf_ctfTrack"      , &dR_gsf_ctfTrack[0]      , "dR_gsf_ctfTrack[LepInfo.Size]/F"              ); //Dmitry
         root->Branch("LepInfo.dPt_gsf_ctfTrack"      , &dPt_gsf_ctfTrack[0]      , "dPt_gsf_ctfTrack[LepInfo.Size]/F"              ); //Dmitry
         root->Branch("LepInfo.ElNClusters"      	 , &ElNClusters[0]   		 , "LepInfo.ElNClusters[LepInfo.Size]/I"    	       );
         root->Branch("LepInfo.ElClassification"      	 , &ElClassification[0]   	 , "LepInfo.ElClassification[LepInfo.Size]/I"          );

         root->Branch("LepInfo.ElFBrem"  	    	 , &ElFBrem[0]  	 	 , "LepInfo.ElFBrem[LepInfo.Size]/F"       	      ); //Jacky
         root->Branch("LepInfo.ElNumberOfBrems"      	 , &ElNumberOfBrems[0]   	 , "LepInfo.ElNumberOfBrems[LepInfo.Size]/I"          ); //Jacky
         root->Branch("LepInfo.NumberOfExpectedInnerHits"                   , &NumberOfExpectedInnerHits[0]                   , "LepInfo.NumberOfExpectedInnerHits[LepInfo.Size]/I"                  );  // Add by Jacky
         root->Branch("LepInfo.Eldist"                   , &Eldist[0]                   , "LepInfo.Eldist[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.Eldcot"                   , &Eldcot[0]                   , "LepInfo.Eldcot[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.Elconvradius"                   , &Elconvradius[0]                   , "LepInfo.Elconvradius[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElConvPoint_x"                   , &ElConvPoint_x[0]                   , "LepInfo.ElConvPoint_x[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElConvPoint_y"                   , &ElConvPoint_y[0]                   , "LepInfo.ElConvPoint_y[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElConvPoint_z"                   , &ElConvPoint_z[0]                   , "LepInfo.ElConvPoint_z[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.dcotdist"                   , &dcotdist[0]                   , "LepInfo.dcotdist[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElseedEoverP"                   , &ElseedEoverP[0]                   , "LepInfo.ElseedEoverP[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElEcalIso04"                   , &ElEcalIso04[0]                   , "LepInfo.ElEcalIso04[LepInfo.Size]/F"                  );  // Add by Jacky
         root->Branch("LepInfo.ElHcalIso04"                   , &ElHcalIso04[0]                   , "LepInfo.ElHcalIso04[LepInfo.Size]/F"                  );  // Add by Jacky

         root->Branch("LepInfo.GenPt"	        	 , &GenPt[0]	     		 , "LepInfo.GenPt[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.GenEta"	        	 , &GenEta[0]	     		 , "LepInfo.GenEta[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.GenPhi"	        	 , &GenPhi[0]	     		 , "LepInfo.GenPhi[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.GenPdgID"         	 , &GenPdgID[0]      		 , "LepInfo.GenPdgID[LepInfo.Size]/I"	    	       );
         root->Branch("LepInfo.GenMCTag"         	 , &GenMCTag[0]      		 , "LepInfo.GenMCTag[LepInfo.Size]/I"	    	       );
         root->Branch("LepInfo.TrgPt"	        	 , &TrgPt[0]	     		 , "LepInfo.TrgPt[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.TrgEta"	        	 , &TrgEta[0]	     		 , "LepInfo.TrgEta[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.TrgPhi"	        	 , &TrgPhi[0]	     		 , "LepInfo.TrgPhi[LepInfo.Size]/F"	    	       );
         root->Branch("LepInfo.TrgID"         		 , &TrgID[0]      		 , "LepInfo.TrgID[LepInfo.Size]/I"	    	       );

      }  


      void Register(TTree *root) {
         root->SetBranchAddress("LepInfo.Size"			   , &Size			   );
         root->SetBranchAddress("LepInfo.Index"  		   , &Index[0]  		   );
         root->SetBranchAddress("LepInfo.isEcalDriven"  		   , &isEcalDriven[0]  		   );
         root->SetBranchAddress("LepInfo.isTrackerDriven"  	   , &isTrackerDriven[0]	   );
         root->SetBranchAddress("LepInfo.LeptonType"		   , &LeptonType[0]		   );
         root->SetBranchAddress("LepInfo.Charge" 		   , &Charge[0] 		   );
         root->SetBranchAddress("LepInfo.Pt"			   , &Pt[0]			   );
         root->SetBranchAddress("LepInfo.Et"			   , &Et[0]			   );
         root->SetBranchAddress("LepInfo.Eta"			   , &Eta[0]			   );
         root->SetBranchAddress("LepInfo.caloEta"		   , &caloEta[0]		   );
         root->SetBranchAddress("LepInfo.Phi"			   , &Phi[0]			   );
         root->SetBranchAddress("LepInfo.TrackIso"		   , &TrackIso[0]		   );
         root->SetBranchAddress("LepInfo.EcalIso"		   , &EcalIso[0]		   );	
         root->SetBranchAddress("LepInfo.HcalIso"		   , &HcalIso[0]		   ); 
         root->SetBranchAddress("LepInfo.HcalDepth1Iso"		   , &HcalDepth1Iso[0]		   ); 
         root->SetBranchAddress("LepInfo.HcalDepth2Iso"		   , &HcalDepth2Iso[0]		   ); 
         root->SetBranchAddress("LepInfo.CaloEnergy"		   , &CaloEnergy[0]		   );	   
         root->SetBranchAddress("LepInfo.e1x5"		           , &e1x5[0]   		   );	   
         root->SetBranchAddress("LepInfo.e2x5Max"		   , &e2x5Max[0]   		   );	   
         root->SetBranchAddress("LepInfo.e5x5"		           , &e5x5[0]   		   );
         root->SetBranchAddress("LepInfo.Px"			   , &Px[0]			   ); //Uly 2011-04-04
         root->SetBranchAddress("LepInfo.Py"			   , &Py[0]			   ); //Uly 2011-04-04
         root->SetBranchAddress("LepInfo.Pz"			   , &Pz[0]			   ); //Uly 2011-04-04
         root->SetBranchAddress("LepInfo.Energy"		   , &Energy[0]			   ); //Uly 2011-04-04
	 root->SetBranchAddress("LepInfo.vertexZ"	           , &vertexZ[0]   		   ); //Uly 2011-04-04

         root->SetBranchAddress("LepInfo.MuIDAllGlobalMuons"                   , &MuIDAllGlobalMuons[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDAllTrackerMuons"                   , &MuIDAllTrackerMuons[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTrackerMuonArbitrated"                   , &MuIDTrackerMuonArbitrated[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDAllArbitrated"                   , &MuIDAllArbitrated[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDGlobalMuonPromptTight"                   , &MuIDGlobalMuonPromptTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationLoose"                   , &MuIDTMLastStationLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationTight"                   , &MuIDTMLastStationTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTM2DCompatibilityTight"                   , &MuIDTM2DCompatibilityTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMOneStationLoose"                   , &MuIDTMOneStationLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMOneStationTight"                   , &MuIDTMOneStationTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationOptimizedLowPtLoose"                   , &MuIDTMLastStationOptimizedLowPtLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationOptimizedLowPtTight"                   , &MuIDTMLastStationOptimizedLowPtTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDGMTkChiCompatibility"                   , &MuIDGMTkChiCompatibility[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDGMStaChiCompatibility"                   , &MuIDGMStaChiCompatibility[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDGMTkKinkTight"                   , &MuIDGMTkKinkTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationAngLoose"                   , &MuIDTMLastStationAngLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationAngTight"                   , &MuIDTMLastStationAngTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMOneStationAngLoose"                   , &MuIDTMOneStationAngLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMOneStationAngTight"                   , &MuIDTMOneStationAngTight[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationOptimizedBarrelLowPtLoose"                   , &MuIDTMLastStationOptimizedBarrelLowPtLoose[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.MuIDTMLastStationOptimizedBarrelLowPtTight"                   , &MuIDTMLastStationOptimizedBarrelLowPtTight[0]                   ); //Add by Jacky


         root->SetBranchAddress("LepInfo.MuInnerTrackDz" 	   , &MuInnerTrackDz[0] 	   );
         root->SetBranchAddress("LepInfo.MuInnerTrackD0" 	   , &MuInnerTrackD0[0] 	   );
         root->SetBranchAddress("LepInfo.MuInnerTrackDxy_BS" 	   , &MuInnerTrackDxy_BS[0] 	   );
         root->SetBranchAddress("LepInfo.MuInnerTrackDxy_PV" 	   , &MuInnerTrackDxy_PV[0] 	   );
         root->SetBranchAddress("LepInfo.MuInnerTrackDxy_PVBS" 	   , &MuInnerTrackDxy_PVBS[0] 	   );
         root->SetBranchAddress("LepInfo.MuInnerTrackNHits"	   , &MuInnerTrackNHits[0]	   );	    
         root->SetBranchAddress("LepInfo.MuNTrackerHits"	       , &MuNTrackerHits[0]	   );	    
         root->SetBranchAddress("LepInfo.MuCaloCompat"		   , &MuCaloCompat[0]		   );
         root->SetBranchAddress("LepInfo.MuNChambers"		   , &MuNChambers[0]		   );
         root->SetBranchAddress("LepInfo.MuNChambersMatchesSegment" , &MuNChambersMatchesSegment[0] );
         root->SetBranchAddress("LepInfo.MuNPixelLayers"            , &MuNPixelLayers[0]	   );
         root->SetBranchAddress("LepInfo.MuNPixelLayersWMeasurement", &MuNPixelLayersWMeasurement[0]); //Uly 2011-04-04
         root->SetBranchAddress("LepInfo.MuNLostInnerHits"          , &MuNLostInnerHits[0]	   );
         root->SetBranchAddress("LepInfo.MuNLostOuterHits"          , &MuNLostOuterHits[0]	   );
         root->SetBranchAddress("LepInfo.MuNMuonhits"               , &MuNMuonhits[0] 		   );
         root->SetBranchAddress("LepInfo.MuType" 		   , &MuType[0] 		   );

         root->SetBranchAddress("LepInfo.MuGlobalNormalizedChi2"    , &MuGlobalNormalizedChi2[0]	   ); //Dmitry
         root->SetBranchAddress("LepInfo.dRmin_20"	           , &dRmin_20[0]	           ); //Dmitry
         root->SetBranchAddress("LepInfo.dRmin_15"	           , &dRmin_15[0]	           ); //Dmitry
         root->SetBranchAddress("LepInfo.dRmin_10"	           , &dRmin_10[0]	           ); //Dmitry
         root->SetBranchAddress("LepInfo.dRmin_05"	           , &dRmin_05[0]	           ); //Dmitry
         root->SetBranchAddress("LepInfo.dRmin"	                   , &dRmin[0]   	           ); //Dmitry
         root->SetBranchAddress("LepInfo.dRminOfficial"             , &dRminOfficial[0]             ); //Dmitry
         root->SetBranchAddress("LepInfo.dRminOfficial_dz"          , &dRminOfficial_dz[0]          ); //Dmitry
         root->SetBranchAddress("LepInfo.dRminOfficial_dxy"         , &dRminOfficial_dxy[0]         ); //Dmitry
         root->SetBranchAddress("LepInfo.dRminOfficial_PtMin"       , &dRminOfficial_PtMin[0]       ); //Dmitry

         root->SetBranchAddress("LepInfo.ElTrackNLostHits"	   , &ElTrackNLostHits[0]	   );   //yjlei
         root->SetBranchAddress("LepInfo.ElTrackD0" 	   	   , &ElTrackD0[0] 	   	   );
         root->SetBranchAddress("LepInfo.ElTrackDxy_BS" 	   	   , &ElTrackDxy_BS[0] 	   	   );
         root->SetBranchAddress("LepInfo.ElTrackDxy_PV" 	   	   , &ElTrackDxy_PV[0] 	   	   );
         root->SetBranchAddress("LepInfo.ElTrackDxy_PVBS" 	   , &ElTrackDxy_PVBS[0] 	   );

         root->SetBranchAddress("LepInfo.simpleEleId95relIso"                   , &simpleEleId95relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId90relIso"                   , &simpleEleId90relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId85relIso"                   , &simpleEleId85relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId80relIso"                   , &simpleEleId80relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId70relIso"                   , &simpleEleId70relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId60relIso"                   , &simpleEleId60relIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId95cIso"                   , &simpleEleId95cIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId90cIso"                   , &simpleEleId90cIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId85cIso"                   , &simpleEleId85cIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId80cIso"                   , &simpleEleId80cIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId70cIso"                   , &simpleEleId70cIso[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.simpleEleId60cIso"                   , &simpleEleId60cIso[0]                   ); //Add by Jacky

	 root->SetBranchAddress("LepInfo.eidVeryLoose"                   , &eidVeryLoose[0]   );
	 root->SetBranchAddress("LepInfo.eidLoose"                   , &eidLoose[0]   );
	 root->SetBranchAddress("LepInfo.eidMedium"                   , &eidMedium[0]   );
	 root->SetBranchAddress("LepInfo.eidTight"                   , &eidTight[0]   );
	 root->SetBranchAddress("LepInfo.eidSuperTight"                   , &eidSuperTight[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight1"                   , &eidHyperTight1[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight2"                   , &eidHyperTight2[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight3"                   , &eidHyperTight3[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight4"                   , &eidHyperTight4[0]   );

	 root->SetBranchAddress("LepInfo.eidVeryLooseMC"                   , &eidVeryLooseMC[0]   );
	 root->SetBranchAddress("LepInfo.eidLooseMC"                   , &eidLooseMC[0]   );
	 root->SetBranchAddress("LepInfo.eidMediumMC"                   , &eidMediumMC[0]   );
	 root->SetBranchAddress("LepInfo.eidTightMC"                   , &eidTightMC[0]   );
	 root->SetBranchAddress("LepInfo.eidSuperTightMC"                   , &eidSuperTightMC[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight1MC"                   , &eidHyperTight1MC[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight2MC"                   , &eidHyperTight2MC[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight3MC"                   , &eidHyperTight3MC[0]   );
	 root->SetBranchAddress("LepInfo.eidHyperTight4MC"                   , &eidHyperTight4MC[0]   );



         root->SetBranchAddress("LepInfo.ElEoverP"		   , &ElEoverP[0]		   );
         root->SetBranchAddress("LepInfo.EldeltaEta"		   , &EldeltaEta[0]		   );
         root->SetBranchAddress("LepInfo.EldeltaPhi"		   , &EldeltaPhi[0]		   );
         root->SetBranchAddress("LepInfo.ElHadoverEm"		   , &ElHadoverEm[0]		   );
         root->SetBranchAddress("LepInfo.ElsigmaIetaIeta"	   , &ElsigmaIetaIeta[0]	   );// Jacky
         root->SetBranchAddress("LepInfo.ElscSigmaIetaIeta"	   , &ElscSigmaIetaIeta[0]	   );// Jacky
         root->SetBranchAddress("LepInfo.ElEnergyErr"		   , &ElEnergyErr[0]		   );
         root->SetBranchAddress("LepInfo.ElMomentumErr"  	   , &ElMomentumErr[0]  	   );
         root->SetBranchAddress("LepInfo.ElTrackNHits"		   , &ElTrackNHits[0]		   );
         root->SetBranchAddress("LepInfo.ElSharedHitsFraction"      , &ElSharedHitsFraction[0]      ); //Dmitry
         root->SetBranchAddress("LepInfo.dR_gsf_ctfTrack"      , &dR_gsf_ctfTrack[0]      ); //Dmitry
         root->SetBranchAddress("LepInfo.dPt_gsf_ctfTrack"      , &dPt_gsf_ctfTrack[0]      ); //Dmitry
         root->SetBranchAddress("LepInfo.ElNClusters"		   , &ElNClusters[0]		   );
         root->SetBranchAddress("LepInfo.ElClassification"	   , &ElClassification[0]	   );

         root->SetBranchAddress("LepInfo.ElFBrem"	 	   , &ElFBrem[0]		   ); //Jacky
         root->SetBranchAddress("LepInfo.ElNumberOfBrems"	   , &ElNumberOfBrems[0]	   ); //Jacky
         root->SetBranchAddress("LepInfo.NumberOfExpectedInnerHits" , &NumberOfExpectedInnerHits[0] ); //Add by Jacky
         root->SetBranchAddress("LepInfo.Eldist"                   , &Eldist[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.Eldcot"                   , &Eldcot[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.Elconvradius"                   , &Elconvradius[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElConvPoint_x"                   , &ElConvPoint_x[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElConvPoint_y"                   , &ElConvPoint_y[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElConvPoint_z"                   , &ElConvPoint_z[0]                   ); //Add by Jacky

         root->SetBranchAddress("LepInfo.dcotdist"                   , &dcotdist[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElseedEoverP"                   , &ElseedEoverP[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElEcalIso04"                   , &ElEcalIso04[0]                   ); //Add by Jacky
         root->SetBranchAddress("LepInfo.ElHcalIso04"                   , &ElHcalIso04[0]                   ); //Add by Jacky

         root->SetBranchAddress("LepInfo.GenPt"  		   , &GenPt[0]  		   );
         root->SetBranchAddress("LepInfo.GenEta" 		   , &GenEta[0] 		   );
         root->SetBranchAddress("LepInfo.GenPhi" 		   , &GenPhi[0] 		   );
         root->SetBranchAddress("LepInfo.GenPdgID"		   , &GenPdgID[0]		   );
         root->SetBranchAddress("LepInfo.GenMCTag"		   , &GenMCTag[0]		   );
         root->SetBranchAddress("LepInfo.TrgPt"  		   , &TrgPt[0]  		   );
         root->SetBranchAddress("LepInfo.TrgEta" 		   , &TrgEta[0] 		   );
         root->SetBranchAddress("LepInfo.TrgPhi" 		   , &TrgPhi[0] 		   );
         root->SetBranchAddress("LepInfo.TrgID" 		 	   , &TrgID[0] 		   	   );

      }    
};


class PFJetInfoBranches {
   public:
      int	Size; 
      int   Index[MAX_JETS];
      int   NTracks[MAX_JETS];
      float Et[MAX_JETS];
      float Pt[MAX_JETS];
      float Unc[MAX_JETS];
      float Eta[MAX_JETS];
      float Phi[MAX_JETS];
      int   JetIDLOOSE[MAX_JETS]; //Add by Chiyi
      float JetCharge[MAX_JETS];
      int   NConstituents[MAX_JETS];
      float JVAlpha[MAX_JETS];
      float JVBeta[MAX_JETS];
      float PtCorrRaw[MAX_JETS];  
      float PtCorrL2[MAX_JETS];  
      float PtCorrL3[MAX_JETS];  
      float PtCorrL7g[MAX_JETS];
      float PtCorrL7uds[MAX_JETS];
      float PtCorrL7c[MAX_JETS];  
      float PtCorrL7b[MAX_JETS];  
      float JetBProbBJetTags[MAX_JETS];
      float JetProbBJetTags[MAX_JETS];
      float TrackCountHiPurBJetTags[MAX_JETS];  
      float TrackCountHiEffBJetTags[MAX_JETS]; 
      //float ImpactParaMVABJetTags[MAX_JETS]; //NONE //remove by Chiyi
      float SimpleSVBJetTags[MAX_JETS];  //for 35X sample //Add by Chiyi
      float SimpleSVHEBJetTags[MAX_JETS];  //for 36X sample //Add by Chiyi
      float SimpleSVHPBJetTags[MAX_JETS];  //for 36X sample //Add by Chiyi
      float CombinedSVBJetTags[MAX_JETS];
      float CombinedSVMVABJetTags[MAX_JETS];
      float SoftElecByIP3dBJetTags[MAX_JETS];
      float SoftElecByPtBJetTags[MAX_JETS];  
      float SoftMuonBJetTags[MAX_JETS];      
      float SoftMuonByIP3dBJetTags[MAX_JETS];
      float SoftMuonByPtBJetTags[MAX_JETS];  
      //float JetLRval[MAX_JETS]; //NONE //remove by Chiyi
      //float JetProb[MAX_JETS]; //NONE //remove by Chiyi
      float GenJetPt[MAX_JETS];
      float GenJetEta[MAX_JETS];
      float GenJetPhi[MAX_JETS];
      float GenPt[MAX_JETS];
      float GenEta[MAX_JETS];
      float GenPhi[MAX_JETS];
      int   GenPdgID[MAX_JETS];
      int   GenFlavor[MAX_JETS];
      int	GenMCTag[MAX_JETS]; // 0: unknown, 1: decay from W, 2: decay from Z, (+10) from b', (+20) from t'

      float Px[MAX_JETS]; //Uly 2011-04-04
      float Py[MAX_JETS]; //Uly 2011-04-04
      float Pz[MAX_JETS]; //Uly 2011-04-04
      float Energy[MAX_JETS]; //Uly 2011-04-04

#ifdef __BPRIMEKIT__
      reco::Candidate* CandRef[MAX_JETS]; // backward pointer to the PAT objects
#endif  

      void RegisterTree(TTree *root) {
         root->Branch("PFJetInfo.Size"		       , &Size  		     , "PFJetInfo.Size/I" 				);
         root->Branch("PFJetInfo.Index"		       , &Index[0]		     , "PFJetInfo.Index[PFJetInfo.Size]/I"  		);
         root->Branch("PFJetInfo.NTracks"  	       , &NTracks[0]		     , "PFJetInfo.NTracks[PFJetInfo.Size]/I"		);
         root->Branch("PFJetInfo.Et"		       , &Et[0] 		     , "PFJetInfo.Et[PFJetInfo.Size]/F"			);
         root->Branch("PFJetInfo.Pt"		       , &Pt[0] 		     , "PFJetInfo.Pt[PFJetInfo.Size]/F"			);
         root->Branch("PFJetInfo.Unc"		       , &Unc[0] 		     , "PFJetInfo.Unc[PFJetInfo.Size]/F"			);
         root->Branch("PFJetInfo.Eta"		       , &Eta[0]		     , "PFJetInfo.Eta[PFJetInfo.Size]/F"			);
         root->Branch("PFJetInfo.Phi"		       , &Phi[0]		     , "PFJetInfo.Phi[PFJetInfo.Size]/F"			);
         root->Branch("PFJetInfo.JetIDLOOSE"	       ,&JetIDLOOSE[0]	     , "PFJetInfo.JetIDLOOSE[PFJetInfo.Size]/I"		); //Add by Chiyi
         root->Branch("PFJetInfo.JetCharge"	       , &JetCharge[0]  	     , "PFJetInfo.JetCharge[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.NConstituents"	       , &NConstituents[0]	     , "PFJetInfo.NConstituents[PFJetInfo.Size]/I"		);
         root->Branch("PFJetInfo.JVAlpha" 	       	       , &JVAlpha[0]		     , "PFJetInfo.JVAlpha[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.JVBeta"	       	       , &JVBeta[0]	     	     , "PFJetInfo.JVBeta[PFJetInfo.Size]/F"  		); 
         root->Branch("PFJetInfo.PtCorrRaw" 	       , &PtCorrRaw[0]		     , "PFJetInfo.PtCorrRaw[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.PtCorrL2" 	       , &PtCorrL2[0]		     , "PFJetInfo.PtCorrL2[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.PtCorrL3" 	       , &PtCorrL3[0]		     , "PFJetInfo.PtCorrL3[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.PtCorrL7g" 	       , &PtCorrL7g[0]	  	     , "PFJetInfo.PtCorrL7g[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.PtCorrL7uds" 	       , &PtCorrL7uds[0]	     , "PFJetInfo.PtCorrL7uds[PFJetInfo.Size]/F"		);	
         root->Branch("PFJetInfo.PtCorrL7c" 	       , &PtCorrL7c[0]	  	     , "PFJetInfo.PtCorrL7c[PFJetInfo.Size]/F"		);	
         root->Branch("PFJetInfo.PtCorrL7b" 	       , &PtCorrL7b[0]	  	     , "PFJetInfo.PtCorrL7b[PFJetInfo.Size]/F"		);	
         root->Branch("PFJetInfo.JetBProbBJetTags"        , &JetBProbBJetTags[0]	     , "PFJetInfo.JetBProbBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.JetProbBJetTags"	       , &JetProbBJetTags[0]	     , "PFJetInfo.JetProbBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.TrackCountHiPurBJetTags" , &TrackCountHiPurBJetTags[0] , "PFJetInfo.TrackCountHiPurBJetTags[PFJetInfo.Size]/F");	    
         root->Branch("PFJetInfo.TrackCountHiEffBJetTags" , &TrackCountHiEffBJetTags[0] , "PFJetInfo.TrackCountHiEffBJetTags[PFJetInfo.Size]/F");
         //	root->Branch("PFJetInfo.ImpactParaMVABJetTags"   , &ImpactParaMVABJetTags[0]   , "PFJetInfo.ImpactParaMVABJetTags[PFJetInfo.Size]/F"  ); //NONE //remove by Chiyi
         root->Branch("PFJetInfo.SimpleSVBJetTags"        , &SimpleSVBJetTags[0]	     , "PFJetInfo.SimpleSVBJetTags[PFJetInfo.Size]/F"	); //for 35X sample //Add by Chiyi
         root->Branch("PFJetInfo.SimpleSVHEBJetTags"        , &SimpleSVHEBJetTags[0]	     , "PFJetInfo.SimpleSVHEBJetTags[PFJetInfo.Size]/F"	); //for 36X sample //Add by Chiyi
         root->Branch("PFJetInfo.SimpleSVHPBJetTags"        , &SimpleSVHPBJetTags[0]	     , "PFJetInfo.SimpleSVHPBJetTags[PFJetInfo.Size]/F"	); //for 36X sample //Add by Chiyi
         root->Branch("PFJetInfo.CombinedSVBJetTags"      , &CombinedSVBJetTags[0]      , "PFJetInfo.CombinedSVBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.CombinedSVMVABJetTags"   , &CombinedSVMVABJetTags[0]   , "PFJetInfo.CombinedSVMVABJetTags[PFJetInfo.Size]/F"  );

         root->Branch("PFJetInfo.SoftElecByIP3dBJetTags"  , &SoftElecByIP3dBJetTags[0]  , "PFJetInfo.SoftElecByIP3dBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.SoftElecByPtBJetTags"    , &SoftElecByPtBJetTags[0]    , "PFJetInfo.SoftElecByPtBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.SoftMuonBJetTags"        , &SoftMuonBJetTags[0]	     , "PFJetInfo.SoftMuonBJetTags[PFJetInfo.Size]/F"	);
         root->Branch("PFJetInfo.SoftMuonByIP3dBJetTags"  , &SoftMuonByIP3dBJetTags[0]  , "PFJetInfo.SoftMuonByIP3dBJetTags[PFJetInfo.Size]/F"	);	
         root->Branch("PFJetInfo.SoftMuonByPtBJetTags"    , &SoftMuonByPtBJetTags[0]    , "PFJetInfo.SoftMuonByPtBJetTags[PFJetInfo.Size]/F"	);	

         //	root->Branch("PFJetInfo.JetLRval" 	       , &JetLRval[0]		     , "PFJetInfo.JetLRval[PFJetInfo.Size]/F"		); //NONE //remove by Chiyi
         //	root->Branch("PFJetInfo.JetProb"  	       , &JetProb[0]		     , "PFJetInfo.JetProb[PFJetInfo.Size]/F"		); //NONE //remove by Chiyi
         root->Branch("PFJetInfo.GenJetPt" 	       , &GenJetPt[0]		     , "PFJetInfo.GenJetPt[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.GenJetEta"	       , &GenJetEta[0]  	     , "PFJetInfo.GenJetEta[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.GenJetPhi"	       , &GenJetPhi[0]  	     , "PFJetInfo.GenJetPhi[PFJetInfo.Size]/F"		);
         root->Branch("PFJetInfo.GenPt"		       , &GenPt[0]		     , "PFJetInfo.GenPt[PFJetInfo.Size]/F"  		);
         root->Branch("PFJetInfo.GenEta"		       , &GenEta[0]		     , "PFJetInfo.GenEta[PFJetInfo.Size]/F" 		);
         root->Branch("PFJetInfo.GenPhi"		       , &GenPhi[0]		     , "PFJetInfo.GenPhi[PFJetInfo.Size]/F" 		);
         root->Branch("PFJetInfo.GenPdgID" 	       , &GenPdgID[0]		     , "PFJetInfo.GenPdgID[PFJetInfo.Size]/I"		);
         root->Branch("PFJetInfo.GenFlavor"	       , &GenFlavor[0]  	     , "PFJetInfo.GenFlavor[PFJetInfo.Size]/I"		);
         root->Branch("PFJetInfo.GenMCTag"	       	       , &GenMCTag[0]  	             , "PFJetInfo.GenMCTag[PFJetInfo.Size]/I"		);

         root->Branch("PFJetInfo.Px"		       , &Px[0] 		     , "PFJetInfo.Px[PFJetInfo.Size]/F"			); //Uly 2011-04-04
         root->Branch("PFJetInfo.Py"		       , &Py[0] 		     , "PFJetInfo.Py[PFJetInfo.Size]/F"			); //Uly 2011-04-04
         root->Branch("PFJetInfo.Pz"		       , &Pz[0] 		     , "PFJetInfo.Pz[PFJetInfo.Size]/F"			); //Uly 2011-04-04
         root->Branch("PFJetInfo.Energy"	       , &Energy[0] 		     , "PFJetInfo.Energy[PFJetInfo.Size]/F"			); //Uly 2011-04-04
      }  



      void Register(TTree *root) {
         root->SetBranchAddress("PFJetInfo.Size"			 , &Size		       );
         root->SetBranchAddress("PFJetInfo.Index"  		 , &Index[0]		       );
         root->SetBranchAddress("PFJetInfo.NTracks"		 , &NTracks[0]  	       );
         root->SetBranchAddress("PFJetInfo.Et"			 , &Et[0]		       );
         root->SetBranchAddress("PFJetInfo.Pt"			 , &Pt[0]		       );
         root->SetBranchAddress("PFJetInfo.Unc"			 , &Unc[0]		       );
         root->SetBranchAddress("PFJetInfo.Eta"			 , &Eta[0]		       );
         root->SetBranchAddress("PFJetInfo.Phi"			 , &Phi[0]		       );
         root->SetBranchAddress("PFJetInfo.JetIDLOOSE"		 , &JetIDLOOSE[0]	       ); //Add by Chiyi
         root->SetBranchAddress("PFJetInfo.JetCharge"		 , &JetCharge[0]	       );
         root->SetBranchAddress("PFJetInfo.NConstituents"		 , &NConstituents[0]	       );
         root->SetBranchAddress("PFJetInfo.JVAlpha"		 , &JVAlpha[0]  	       );
         root->SetBranchAddress("PFJetInfo.JVBeta" 		 , &JVBeta[0]		       ); 
         root->SetBranchAddress("PFJetInfo.PtCorrRaw"		 , &PtCorrRaw[0]	       );
         root->SetBranchAddress("PFJetInfo.PtCorrL2"		 , &PtCorrL2[0] 	       );
         root->SetBranchAddress("PFJetInfo.PtCorrL3"		 , &PtCorrL3[0] 	       );
         root->SetBranchAddress("PFJetInfo.PtCorrL7g"		 , &PtCorrL7g[0]	       );
         root->SetBranchAddress("PFJetInfo.PtCorrL7uds"		 , &PtCorrL7uds[0]	       );      
         root->SetBranchAddress("PFJetInfo.PtCorrL7c"		 , &PtCorrL7c[0]	       );      
         root->SetBranchAddress("PFJetInfo.PtCorrL7b"		 , &PtCorrL7b[0]	       );      
         root->SetBranchAddress("PFJetInfo.JetBProbBJetTags"	 , &JetBProbBJetTags[0]        );
         root->SetBranchAddress("PFJetInfo.JetProbBJetTags"	 , &JetProbBJetTags[0]         );
         root->SetBranchAddress("PFJetInfo.TrackCountHiPurBJetTags" , &TrackCountHiPurBJetTags[0] );	   
         root->SetBranchAddress("PFJetInfo.TrackCountHiEffBJetTags" , &TrackCountHiEffBJetTags[0] );
         //	root->SetBranchAddress("PFJetInfo.ImpactParaMVABJetTags"   , &ImpactParaMVABJetTags[0]   ); //NONE //remove by Chiyi
         root->SetBranchAddress("PFJetInfo.SimpleSVBJetTags"	 , &SimpleSVBJetTags[0]        ); //for 36X sample //Add by Chiyi
         root->SetBranchAddress("PFJetInfo.SimpleSVHEBJetTags"	 , &SimpleSVHEBJetTags[0]        ); //for 36X sample //Add by Chiyi
         root->SetBranchAddress("PFJetInfo.SimpleSVHPBJetTags"	 , &SimpleSVHPBJetTags[0]        ); //for 36X sample //Add by Chiyi
         root->SetBranchAddress("PFJetInfo.CombinedSVBJetTags"	 , &CombinedSVBJetTags[0]      );
         root->SetBranchAddress("PFJetInfo.CombinedSVMVABJetTags"   , &CombinedSVMVABJetTags[0]   );

         root->SetBranchAddress("PFJetInfo.SoftElecByIP3dBJetTags"  , &SoftElecByIP3dBJetTags[0]	);
         root->SetBranchAddress("PFJetInfo.SoftElecByPtBJetTags"    , &SoftElecByPtBJetTags[0]  	);
         root->SetBranchAddress("PFJetInfo.SoftMuonBJetTags"        , &SoftMuonBJetTags[0]	     	);
         root->SetBranchAddress("PFJetInfo.SoftMuonByIP3dBJetTags"  , &SoftMuonByIP3dBJetTags[0]   );
         root->SetBranchAddress("PFJetInfo.SoftMuonByPtBJetTags"    , &SoftMuonByPtBJetTags[0]   	);	

         //	root->SetBranchAddress("PFJetInfo.JetLRval"		 , &JetLRval[0] 	       ); //NONE //remove by Chiyi
         //	root->SetBranchAddress("PFJetInfo.JetProb"		 , &JetProb[0]  	       ); //NONE //remove by Chiyi
         root->SetBranchAddress("PFJetInfo.GenJetPt"		 , &GenJetPt[0] 	       );
         root->SetBranchAddress("PFJetInfo.GenJetEta"		 , &GenJetEta[0]	       );
         root->SetBranchAddress("PFJetInfo.GenJetPhi"		 , &GenJetPhi[0]	       );
         root->SetBranchAddress("PFJetInfo.GenPt"  		 , &GenPt[0]		       );
         root->SetBranchAddress("PFJetInfo.GenEta" 		 , &GenEta[0]		       );
         root->SetBranchAddress("PFJetInfo.GenPhi" 		 , &GenPhi[0]		       );
         root->SetBranchAddress("PFJetInfo.GenPdgID"		 , &GenPdgID[0] 	       );
         root->SetBranchAddress("PFJetInfo.GenFlavor"		 , &GenFlavor[0]	       );
         root->SetBranchAddress("PFJetInfo.GenMCTag"		 , &GenMCTag[0] 	       );

         root->SetBranchAddress("PFJetInfo.Px"			 , &Px[0]		       ); //Uly 2011-04-04
         root->SetBranchAddress("PFJetInfo.Py"			 , &Py[0]		       ); //Uly 2011-04-04
         root->SetBranchAddress("PFJetInfo.Pz"			 , &Pz[0]		       ); //Uly 2011-04-04
         root->SetBranchAddress("PFJetInfo.Energy"		 , &Energy[0]		       ); //Uly 2011-04-04
      }   
};


class PairInfoBranches {
   public:
      int	Size; 
      int	Index[MAX_PAIRS];
      int	Type[MAX_PAIRS]; // type of pairing - 1: ll (regardless of charge and flavor!), 2: jj
      int   Obj1Index[MAX_PAIRS];
      int   Obj2Index[MAX_PAIRS];
      float Mass[MAX_PAIRS];
      float Pt[MAX_PAIRS];
      float Eta[MAX_PAIRS];
      float Phi[MAX_PAIRS];  
      float GenMass[MAX_PAIRS];
      float GenPt[MAX_PAIRS];
      float GenEta[MAX_PAIRS];
      float GenPhi[MAX_PAIRS];
      int	GenPdgID[MAX_PAIRS];

      void RegisterTree(TTree *root) {
         root->Branch("PairInfo.Size" 	  , &Size	  , "PairInfo.Size/I"			 );
         root->Branch("PairInfo.Index"	  , &Index[0]	  , "PairInfo.Index[PairInfo.Size]/I"	 );
         root->Branch("PairInfo.Type"      , &Type[0]	  , "PairInfo.Type[PairInfo.Size]/I"	 );
         root->Branch("PairInfo.Obj1Index" , &Obj1Index[0] , "PairInfo.Obj1Index[PairInfo.Size]/I"); 
         root->Branch("PairInfo.Obj2Index" , &Obj2Index[0] , "PairInfo.Obj2Index[PairInfo.Size]/I"); 
         root->Branch("PairInfo.Mass"	  , &Mass[0]	  , "PairInfo.Mass[PairInfo.Size]/F"	 );
         root->Branch("PairInfo.Pt"	  , &Pt[0]	  , "PairInfo.Pt[PairInfo.Size]/F"	 );
         root->Branch("PairInfo.Eta"	  , &Eta[0]	  , "PairInfo.Eta[PairInfo.Size]/F"	 ); 
         root->Branch("PairInfo.Phi"  	  , &Phi[0]	  , "PairInfo.Phi[PairInfo.Size]/F"	 ); 
         root->Branch("PairInfo.GenMass"   , &GenMass[0]   , "PairInfo.GenMass[PairInfo.Size]/F"  ); 
         root->Branch("PairInfo.GenPt"	  , &GenPt[0]	  , "PairInfo.GenPt[PairInfo.Size]/F"	 );
         root->Branch("PairInfo.GenEta"	  , &GenEta[0]    , "PairInfo.GenEta[PairInfo.Size]/F"   );
         root->Branch("PairInfo.GenPhi"	  , &GenPhi[0]    , "PairInfo.GenPhi[PairInfo.Size]/F"   );
         root->Branch("PairInfo.GenPdgID"  , &GenPdgID[0]  , "PairInfo.GenPdgID[PairInfo.Size]/I" ); 
      }  	 



      void Register(TTree *root) {
         root->SetBranchAddress("PairInfo.Size"      , &Size	    );
         root->SetBranchAddress("PairInfo.Index"     , &Index[0]     );
         root->SetBranchAddress("PairInfo.Type"      , &Type[0]      );
         root->SetBranchAddress("PairInfo.Obj1Index" , &Obj1Index[0] ); 
         root->SetBranchAddress("PairInfo.Obj2Index" , &Obj2Index[0] ); 
         root->SetBranchAddress("PairInfo.Mass"      , &Mass[0]      );
         root->SetBranchAddress("PairInfo.Pt"	    , &Pt[0]	    );
         root->SetBranchAddress("PairInfo.Eta"	    , &Eta[0]	    ); 
         root->SetBranchAddress("PairInfo.Phi"	    , &Phi[0]	    ); 
         root->SetBranchAddress("PairInfo.GenMass"   , &GenMass[0]   ); 
         root->SetBranchAddress("PairInfo.GenPt"     , &GenPt[0]     );
         root->SetBranchAddress("PairInfo.GenEta"    , &GenEta[0]    );
         root->SetBranchAddress("PairInfo.GenPhi"    , &GenPhi[0]    );
         root->SetBranchAddress("PairInfo.GenPdgID"  , &GenPdgID[0]  ); 
      }  	 
};

class PhotonInfoBranches {
   public:
      int	Size; 
      float Pt[MAX_PHOTONS];
      float Eta[MAX_PHOTONS];
      float Phi[MAX_PHOTONS];
      bool  PIDTest[MAX_PHOTONS];
      bool  caloIso[MAX_PHOTONS];
      bool  ecalIso[MAX_PHOTONS];
      bool  hcalIso[MAX_PHOTONS];
      bool  trackIso[MAX_PHOTONS];
      float GenPt[MAX_PHOTONS];
      float GenEta[MAX_PHOTONS];
      float GenPhi[MAX_PHOTONS];
      int   GenPdgID[MAX_PHOTONS];

      void RegisterTree(TTree *root) {
         root->Branch("PhotonInfo.Size"	     		, &Size		      , "PhotonInfo.Size/I"				       );
         root->Branch("PhotonInfo.Pt"		     	, &Pt[0]	      , "PhotonInfo.Pt[PhotonInfo.Size]/F"		       );
         root->Branch("PhotonInfo.Eta"		     	, &Eta[0]	      , "PhotonInfo.Eta[PhotonInfo.Size]/F"		       );
         root->Branch("PhotonInfo.Phi"		     	, &Phi[0]	      , "PhotonInfo.Phi[PhotonInfo.Size]/F"		       );
         root->Branch("PhotonInfo.PIDTest"	    	, &PIDTest[0]		,"PhotonInfo.PIDTest[PhotonInfo.Size]/O"       );
         root->Branch("PhotonInfo.caloIso"	    	, &caloIso[0]		,"PhotonInfo.caloIso[PhotonInfo.Size]/O"       );
         root->Branch("PhotonInfo.ecalIso"	    	, &ecalIso[0]		,"PhotonInfo.ecalIso[PhotonInfo.Size]/O"       );
         root->Branch("PhotonInfo.hcalIso"	    	, &hcalIso[0]		,"PhotonInfo.hcalIso[PhotonInfo.Size]/O"       );
         root->Branch("PhotonInfo.trackIso"	    	, &trackIso[0]		,"PhotonInfo.trackIso[PhotonInfo.Size]/O"       );
         root->Branch("PhotonInfo.GenPt"			, &GenPt[0]		,"PhotonInfo.GenPt[PhotonInfo.Size]/F"       );
         root->Branch("PhotonInfo.GenEta"	    	, &GenEta[0]		,"PhotonInfo.GenEta[PhotonInfo.Size]/F"       );
         root->Branch("PhotonInfo.GenPhi"	    	, &GenPhi[0]		,"PhotonInfo.GenPhi[PhotonInfo.Size]/F"       );
         root->Branch("PhotonInfo.GenPdgID"	    	, &GenPdgID[0]		,"PhotonInfo.GenPdgID[PhotonInfo.Size]/I"       );

      }  

      void Register(TTree *root) {
         root->SetBranchAddress("PhotonInfo.Size"	 	, &Size			       );
         root->SetBranchAddress("PhotonInfo.Pt"		     	, &Pt[0]		       );
         root->SetBranchAddress("PhotonInfo.Eta"		     	, &Eta[0]		       );
         root->SetBranchAddress("PhotonInfo.Phi"		     	, &Phi[0]		       );
         root->SetBranchAddress("PhotonInfo.PIDTest"	    	, &PIDTest[0]		       );
         root->SetBranchAddress("PhotonInfo.caloIso"	    	, &caloIso[0]		       );
         root->SetBranchAddress("PhotonInfo.ecalIso"	    	, &ecalIso[0]		       );
         root->SetBranchAddress("PhotonInfo.hcalIso"	    	, &hcalIso[0]		       );
         root->SetBranchAddress("PhotonInfo.trackIso"	    	, &trackIso[0]		       );
         root->SetBranchAddress("PhotonInfo.GenPt"		, &GenPt[0]		       );
         root->SetBranchAddress("PhotonInfo.GenEta"	    	, &GenEta[0]		       );
         root->SetBranchAddress("PhotonInfo.GenPhi"	    	, &GenPhi[0]		       );
         root->SetBranchAddress("PhotonInfo.GenPdgID"	    	, &GenPdgID[0]		       );
      }  
};

class VertexInfoBranches {
   public:
      int     Size;
      int     isValid[MAX_Vertices];
      bool    isFake[MAX_Vertices]; //Uly 2011-04-04
      int     Type[MAX_Vertices];   //0 - Offline Primary Vertices, 1 - Offline Primary Vertices with beam spot constraint, 2 - Pixel Vertices
      float   Ndof[MAX_Vertices];
      float   NormalizedChi2[MAX_Vertices];
      float   Pt_Sum[MAX_Vertices];
      float   x[MAX_Vertices];
      float   y[MAX_Vertices];
      float   z[MAX_Vertices];
      float   Rho[MAX_Vertices];

      void RegisterTree(TTree *root) {
         root->Branch("VertexInfo.Size"	    , &Size	       , "VertexInfo.Size/I"	    );
         root->Branch("VertexInfo.isValid"  , &isValid[0]      , "VertexInfo.isValid[VertexInfo.Size]/I"	    );
	 root->Branch("VertexInfo.isFake"   , &isFake[0]       , "VertexInfo.isFake[VertexInfo.Size]/O"	    ); //Uly 2011-04-04
         root->Branch("VertexInfo.Type"	    , &Type[0]	       , "VertexInfo.Type[VertexInfo.Size]/I"	    );
         root->Branch("VertexInfo.Ndof"	    , &Ndof[0]	       , "VertexInfo.Ndof[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.NormalizedChi2"	    , &NormalizedChi2[0]	       , "VertexInfo.NormalizedChi2[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.Pt_Sum"	    , &Pt_Sum[0]	       , "VertexInfo.Pt_Sum[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.x"	    , &x[0]	       , "VertexInfo.x[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.y"	    , &y[0]	       , "VertexInfo.y[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.z"	    , &z[0]	       , "VertexInfo.z[VertexInfo.Size]/F"	    );
         root->Branch("VertexInfo.Rho"	    , &Rho[0]	       , "VertexInfo.Rho[VertexInfo.Size]/F"	    );
      }										    
      void Register(TTree *root) {
         root->SetBranchAddress("VertexInfo.Size"        , &Size  	 );
         root->SetBranchAddress("VertexInfo.isValid"     , &isValid[0]  	 );
	 root->SetBranchAddress("VertexInfo.isFake"      , &isFake[0]  	 ); //Uly 2011-04-04
         root->SetBranchAddress("VertexInfo.Type"        , &Type[0]  	 );
         root->SetBranchAddress("VertexInfo.Ndof"        , &Ndof[0]  	 );
         root->SetBranchAddress("VertexInfo.NormalizedChi2"        , &NormalizedChi2[0]  	 );
         root->SetBranchAddress("VertexInfo.Pt_Sum"        , &Pt_Sum[0]  	 );
         root->SetBranchAddress("VertexInfo.x"        , &x[0]  	 );
         root->SetBranchAddress("VertexInfo.y"        , &y[0]  	 );
         root->SetBranchAddress("VertexInfo.z"        , &z[0]  	 );
         root->SetBranchAddress("VertexInfo.Rho"        , &Rho[0]  	 );
      }  										    
};



class GenInfoBranches {
   public:
      int Size;
      float Pt[MAX_GENS];
      float Eta[MAX_GENS];
      float Phi[MAX_GENS];
      float Mass[MAX_GENS];
      int PdgID[MAX_GENS];
      int Status[MAX_GENS];
      int nMo[MAX_GENS];
      int nDa[MAX_GENS];
      int Mo1[MAX_GENS];
      int Mo2[MAX_GENS];
      int Da1[MAX_GENS];
      int Da2[MAX_GENS];

      void RegisterTree(TTree *root) {
         root->Branch("GenInfo.Size"	, &Size		, "GenInfo.Size/I"			);
         root->Branch("GenInfo.Pt"	, &Pt[0]	, "GenInfo.Pt[GenInfo.Size]/F"		);
         root->Branch("GenInfo.Eta"	, &Eta[0]	, "GenInfo.Eta[GenInfo.Size]/F"		);
         root->Branch("GenInfo.Phi"	, &Phi[0]	, "GenInfo.Phi[GenInfo.Size]/F"		);
         root->Branch("GenInfo.Mass"	, &Mass[0]	, "GenInfo.Mass[GenInfo.Size]/F"	);
         root->Branch("GenInfo.PdgID"	, &PdgID[0]	, "GenInfo.PdgID[GenInfo.Size]/I"	);
         root->Branch("GenInfo.Status"	, &Status[0]	, "GenInfo.Status[GenInfo.Size]/I"	);
         root->Branch("GenInfo.nMo"	, &nMo[0]	, "GenInfo.nMo[GenInfo.Size]/I"		);
         root->Branch("GenInfo.nDa"	, &nDa[0]	, "GenInfo.nDa[GenInfo.Size]/I"		);
         root->Branch("GenInfo.Mo1"	, &Mo1[0]	, "GenInfo.Mo1[GenInfo.Size]/I"		);
         root->Branch("GenInfo.Mo2"	, &Mo2[0]	, "GenInfo.Mo2[GenInfo.Size]/I"		);
         root->Branch("GenInfo.Da1"	, &Da1[0]	, "GenInfo.Da1[GenInfo.Size]/I"		);
         root->Branch("GenInfo.Da2"	, &Da2[0]	, "GenInfo.Da2[GenInfo.Size]/I"		);
      }

      void Register(TTree *root) {
         root->SetBranchAddress("GenInfo.Size"	, &Size		);
         root->SetBranchAddress("GenInfo.Pt"	, &Pt[0]	);
         root->SetBranchAddress("GenInfo.Eta"	, &Eta[0]	);
         root->SetBranchAddress("GenInfo.Phi"	, &Phi[0]	);
         root->SetBranchAddress("GenInfo.Mass"	, &Mass[0]	);
         root->SetBranchAddress("GenInfo.PdgID"	, &PdgID[0]	);
         root->SetBranchAddress("GenInfo.Status"	, &Status[0]	);
         root->SetBranchAddress("GenInfo.nMo"	, &nMo[0]	);
         root->SetBranchAddress("GenInfo.nDa"	, &nDa[0]	);
         root->SetBranchAddress("GenInfo.Mo1"	, &Mo1[0]	);
         root->SetBranchAddress("GenInfo.Mo2"	, &Mo2[0]	);
         root->SetBranchAddress("GenInfo.Da1"	, &Da1[0]	);
         root->SetBranchAddress("GenInfo.Da2"	, &Da2[0]	);
      }

};

//Also Remember to change # inside EvtInfo.TrgBook[123]/I
//char TriggerBooking[N_TRIGGER_BOOKINGS][48] = {
char TriggerBooking[N_TRIGGER_BOOKINGS][88] = {
   "generation_step",                               //000
   "simulation_step",                               //001
   "digitisation_step",                             //002
   "L1simulation_step",                             //003
   "digi2raw_step",                                 //004
   "HLTriggerFirstPath",                            //005
   "HLT_L1Jet15",                                   //006
   "HLT_Jet30",                                     //007
   "HLT_Jet50",                                     //008
   "HLT_Jet80",                                     //009
   "HLT_Jet110",                                    //010
   "HLT_Jet140",                                    //011
   "HLT_Jet180",                                    //012
   "HLT_FwdJet40",                                  //013
   "HLT_DiJetAve15U_1E31",                          //014
   "HLT_DiJetAve30U_1E31",                          //015
   "HLT_DiJetAve50U",                               //016
   "HLT_DiJetAve70U",                               //017
   "HLT_DiJetAve130U",                              //018
   "HLT_QuadJet30",                                 //019
   "HLT_SumET120",                                  //020
   "HLT_L1MET20",                                   //021
   "HLT_MET35",                                     //022
   "HLT_MET60",                                     //023
   "HLT_MET100",                                    //024
   "HLT_HT200",                                     //025
   "HLT_HT300_MHT100",                              //026
   "HLT_L1MuOpen",                                  //027
   "HLT_L1Mu",                                      //028
   "HLT_L1Mu20HQ",                                  //029
   "HLT_L1Mu30",                                    //030
   "HLT_L2Mu11",                                    //031
   "HLT_IsoMu9",                                    //032
   "HLT_Mu5",                                       //033
   "HLT_Mu9",                                       //034
   "HLT_Mu11",                                      //035
   "HLT_Mu15",                                      //036
   "HLT_L1DoubleMuOpen",                            //037
   "HLT_DoubleMu0",                                 //038
   "HLT_DoubleMu3",                                 //039
   "HLT_L1SingleEG5",                               //040
   "HLT_Ele10_SW_L1R",                              //041
   "HLT_Ele15_SW_L1R",                              //042
   "HLT_Ele15_SW_EleId_L1R",                        //043
   "HLT_Ele15_SW_LooseTrackIso_L1R",                //044
   "HLT_Ele15_SiStrip_L1R",                         //045
   "HLT_Ele15_SC15_SW_LooseTrackIso_L1R",           //046
   "HLT_Ele15_SC15_SW_EleId_L1R",                   //047
   "HLT_Ele20_SW_L1R",                              //048
   "HLT_Ele20_SiStrip_L1R",                         //049
   "HLT_Ele20_SC15_SW_L1R",                         //050
   "HLT_Ele25_SW_L1R",                              //051
   "HLT_Ele25_SW_EleId_LooseTrackIso_L1R",          //052
   "HLT_DoubleEle5_SW_Jpsi_L1R",                    //053
   "HLT_DoubleEle5_SW_Upsilon_L1R",                 //054
   "HLT_DoubleEle10_SW_L1R",                        //055
   "HLT_Photon10_L1R",                              //056
   "HLT_Photon10_LooseEcalIso_TrackIso_L1R",        //057
   "HLT_Photon15_L1R",                              //058
   "HLT_Photon20_LooseEcalIso_TrackIso_L1R",        //059
   "HLT_Photon25_L1R",                              //060
   "HLT_Photon25_LooseEcalIso_TrackIso_L1R",        //061
   "HLT_Photon30_L1R_1E31",                         //062
   "HLT_Photon70_L1R",                              //063
   "HLT_DoublePhoton10_L1R",                        //064
   "HLT_DoublePhoton15_L1R",                        //065
   "HLT_DoublePhoton15_VeryLooseEcalIso_L1R",       //066
   "HLT_SingleIsoTau30_Trk5",                       //067
   "HLT_DoubleLooseIsoTau15_Trk5",                  //068
   "HLT_BTagIP_Jet80",                              //069
   "HLT_BTagMu_Jet20",                              //070
   "HLT_BTagIP_Jet120",                             //071
   "HLT_StoppedHSCP_1E31",                          //072
   "HLT_L1Mu14_L1SingleEG10",                       //073
   "HLT_L1Mu14_L1SingleJet15",                      //074
   "HLT_L1Mu14_L1ETM40",                            //075
   "HLT_Ele10_LW_L1R_HT200",                        //076
   "HLT_L2Mu5_Photon9_L1R",                         //077
   "HLT_L2Mu9_DiJet30",                             //078
   "HLT_L2Mu8_HT50",                                //079
   "HLT_Ele10_SW_L1R_TripleJet30",                  //080
   "HLT_Ele10_LW_L1R_HT180",                        //081
   "HLT_ZeroBias",                                  //082
   "HLT_MinBiasHcal",                               //083
   "HLT_MinBiasEcal",                               //084
   "HLT_MinBiasPixel",                              //085
   "HLT_MinBiasPixel_Trk5",                         //086
   "HLT_CSCBeamHalo",                               //087
   "HLT_CSCBeamHaloOverlapRing1",                   //088
   "HLT_CSCBeamHaloOverlapRing2",                   //089
   "HLT_CSCBeamHaloRing2or3",                       //090
   "HLT_BackwardBSC",                               //091
   "HLT_ForwardBSC",                                //092
   "HLT_TrackerCosmics",                            //093
   "HLT_IsoTrack_1E31",                             //094
   "AlCa_HcalPhiSym",                               //095
   "AlCa_EcalPhiSym",                               //096
   "AlCa_EcalPi0_1E31",                             //097
   "AlCa_EcalEta_1E31",                             //098
   "AlCa_RPCMuonNoHits",                            //099
   "AlCa_RPCMuonNormalisation",                     //100
   "HLTriggerFinalPath",                            //101
   "endjob_step",                                   //102
   "HLT_HT240",                                     //103
   "HLT_Mu0_L1MuOpen",                              //104
   "HLT_Mu3_L1MuOpen",                              //105
   "HLT_Mu5_L1MuOpen",                              //106
   "HLT_Mu0_Track0_Jpsi",                           //107
   "HLT_Mu3_Track0_Jpsi",                           //108
   "HLT_Mu5_Track0_Jpsi",                           //109
   "HLT_Ele20_SW_EleId_LooseTrackIso_L1R",          //110
   "HLT_L1Mu14_L1SingleJet20",                      //111
   "HLT_L2Mu7_Photon9_L1R",                         //112
   "HLT_ZeroBiasPixel_SingleTrack",                 //113
   "HLT_HighMultiplicityBSC",                       //114
   "HLT_RPCBarrelCosmics",                          //115
   "HLT_IsoTrackHE_1E31",                           //116
   "HLT_IsoTrackHB_1E31",                           //117
   "HLT_HcalPhiSym",                                //118
   "HLT_HcalNZS_1E31",                              //119
   "AlCa_RPCMuonNoTriggers",                        //120
   "HLT_HighMult40",                                //121
   "HLT_Activity_L1A",                              //122
   "HLT_Activity_PixelClusters",                    //123
   "HLT_Activity_DT",                               //124
   "HLT_Activity_DT_Tuned",                         //125
   "HLT_Activity_Ecal",                             //126
   "HLT_Activity_EcalREM",                          //127
   "HLT_SelectEcalSpikes_L1R",                      //128
   "HLT_SelectEcalSpikesHighEt_L1R",                //129
   "HLT_L1Jet6U",                                   //130
   "HLT_L1Jet6U_NoBPTX",                            //131
   "HLT_L1Jet10U",                                  //132
   "HLT_L1Jet10U_NoBPTX",                           //133
   "HLT_Jet15U",                                    //134
   "HLT_Jet30U",                                    //135
   "HLT_Jet50U",                                    //136
   "HLT_L1SingleForJet",                            //137
   "HLT_L1SingleForJet_NoBPTX",                     //138
   "HLT_L1SingleCenJet",                            //139
   "HLT_L1SingleCenJet_NoBPTX",                     //140
   "HLT_L1SingleTauJet",                            //141
   "HLT_L1SingleTauJet_NoBPTX",                     //142
   "HLT_FwdJet20U",                                 //143
   "HLT_DiJetAve15U_8E29",                          //144
   "HLT_DiJetAve30U_8E29",                          //145
   "HLT_DoubleJet15U_ForwardBackward",              //146
   "HLT_QuadJet15U",                                //147
   "HLT_MET45",                                     //148
   "HLT_HT100U",                                    //149
   "HLT_L1MuOpen_NoBPTX",                           //150
   "HLT_L1MuOpen_AntiBPTX",                         //151
   "HLT_L1Mu20",                                    //152
   "HLT_L2Mu0",                                     //153
   "HLT_L2Mu3",                                     //154
   "HLT_L2Mu5",                                     //155
   "HLT_L2Mu9",                                     //156
   "HLT_L2DoubleMu0",                               //157
   "HLT_IsoMu3",                                    //158
   "HLT_Mu3",                                       //159
   "HLT_Mu0_L2Mu0",                                 //160
   "HLT_Mu3_L2Mu0",                                 //161
   "HLT_Mu5_L2Mu0",                                 //162
   "HLT_L1SingleEG2",                               //163
   "HLT_L1SingleEG2_NoBPTX",                        //164
   "HLT_L1SingleEG5_NoBPTX",                        //165
   "HLT_L1SingleEG8",                               //166
   "HLT_L1DoubleEG5",                               //167
   "HLT_EgammaSuperClusterOnly_L1R",                //168
   "HLT_Ele10_LW_L1R",                              //169
   "HLT_Ele10_LW_EleId_L1R",                        //170
   "HLT_Ele15_LW_L1R",                              //171
   "HLT_Ele15_SC10_LW_L1R",                         //172
   "HLT_Ele20_LW_L1R",                              //173
   "HLT_DoubleEle5_SW_L1R",                         //174
   "HLT_Photon15_TrackIso_L1R",                     //175
   "HLT_Photon15_LooseEcalIso_L1R",                 //176
   "HLT_Photon20_L1R",                              //177
   "HLT_Photon30_L1R_8E29",                         //178
   "HLT_DoublePhoton4_eeRes_L1R",                   //179
   "HLT_DoublePhoton4_Jpsi_L1R",                    //180
   "HLT_DoublePhoton4_Upsilon_L1R",                 //181
   "HLT_DoublePhoton5_Jpsi_L1R",                    //182
   "HLT_DoublePhoton5_Upsilon_L1R",                 //183
   "HLT_DoublePhoton5_L1R",                         //184
   "HLT_SingleLooseIsoTau20",                       //185
   "HLT_DoubleLooseIsoTau15",                       //186
   "HLT_BTagIP_Jet50U",                             //187
   "HLT_BTagMu_Jet10U",                             //188
   "HLT_StoppedHSCP_8E29",                          //189
   "HLT_L1Mu14_L1SingleJet6U",                      //190
   "HLT_L1Mu14_L1ETM30",                            //191
   "HLT_MinBiasBSC",                                //192
   "HLT_MinBiasBSC_NoBPTX",                         //193
   "HLT_MinBiasBSC_OR",                             //194
   "HLT_MinBiasPixel_SingleTrack",                  //195
   "HLT_MinBiasPixel_DoubleTrack",                  //196
   "HLT_MinBiasPixel_DoubleIsoTrack5",              //197
   "HLT_SplashBSC",                                 //198
   "HLT_L1_BscMinBiasOR_BptxPlusORMinus",           //199
   "HLT_L1_BscMinBiasOR_BptxPlusORMinus_NoBPTX",    //200
   "HLT_L1_BscMinBiasOR_BeamGas",                   //201
   "HLT_L1Tech_BSC_halo",                           //202
   "HLT_L1Tech_BSC_halo_forPhysicsBackground",      //203
   "HLT_L1Tech_RPC_TTU_RBst1_collisions",           //204
   "HLT_IsoTrackHE_8E29",                           //205
   "HLT_IsoTrackHB_8E29",                           //206
   "HLT_HcalNZS_8E29",                              //207
   "AlCa_EcalPi0_8E29",                             //208
   "AlCa_EcalEta_8E29",                             //209
   "HLT_DTErrors",                                  //210
   "HLT_Calibration",                               //211
   "HLT_EcalCalibration",                           //212
   "HLT_HcalCalibration",                           //213
   "HLT_Random",                                    //214
   "HLT_L1_HFtech",                                 //215
   "HLT_L1Tech_HCAL_HF_coincidence_PM",             //216
   "HLT_GlobalRunHPDNoise",                         //217
   "HLT_TechTrigHCALNoise",                         //218
   "HLT_L1_BPTX",                                   //219
   "HLT_L1_BPTX_MinusOnly",                         //220
   "HLT_L1_BPTX_PlusOnly",                          //221
   "HLT_L2Mu0_NoVertex",                            //222
   "HLT_TkMu3_NoVertex",                            //223
   "HLT_LogMonitor",                                //224
   "DQM_FEDIntegrity",                              //225
   "AlCa_EcalEta",                                  //226
   "AlCa_EcalPi0",                                  //227
   "DQM_TriggerResults",                            //228
   "HLT_Activity_CSC",                              //229
   "HLT_DiJetAve15U",                               //230
   "HLT_DiJetAve30U",                               //231
   "HLT_DoubleEle4_SW_eeRes_L1R",                   //232
   "HLT_DoubleIsoTau15_OneLeg_Trk5",                //233
   "HLT_DoubleIsoTau15_Trk5",                       //234
   "HLT_DoubleJet25U_ForwardBackward",              //235
   "HLT_DoublePhoton17_L1R",                        //236
   "HLT_DoublePhoton5_CEP_L1R",                     //237
   "HLT_EcalOnly_SumEt160",                         //238
   "HLT_Ele12_SW_TightEleIdIsol_L1R",               //239
   "HLT_Ele12_SW_TightEleIdIsol_NoDEtaInEE_L1R",    //240
   "HLT_Ele12_SW_TightEleId_L1R",                   //241
   "HLT_Ele17_SW_CaloEleId_L1R",                    //242
   "HLT_Ele17_SW_EleId_L1R",                        //243
   "HLT_Ele17_SW_L1R",                              //244
   "HLT_Ele17_SW_LooseEleId_L1R",                   //245
   "HLT_Ele22_SW_CaloEleId_L1R",                    //246
   "HLT_Ele40_SW_L1R",                              //247
   "HLT_HT120U",                                    //248
   "HLT_HT140U",                                    //249
   "HLT_HcalNZS",                                   //250
   "HLT_IsoTrackHB",                                //251
   "HLT_IsoTrackHE",                                //252
   "HLT_Jet100U",                                   //253
   "HLT_Jet70U",                                    //254
   "HLT_L1ETT100",                                  //255
   "HLT_L1Tech_BSC_HighMultiplicity",               //256
   "HLT_L1Tech_BSC_minBias",                        //257
   "HLT_L1Tech_BSC_minBias_OR",                     //258
   "HLT_L1Tech_HCAL_HF",                            //259
   "HLT_L1_BptxXOR_BscMinBiasOR",                   //260
   "HLT_L2Mu25",                                    //261
   "HLT_MET65",                                     //262
   "HLT_Mu0_TkMu0_OST_Jpsi",                        //263
   "HLT_Mu20_NoVertex",                             //264
   "HLT_Mu7",                                       //265
   "HLT_MultiVertex6",                              //266
   "HLT_MultiVertex8_L1ETT60",                      //267
   "HLT_Photon10_Cleaned_L1R",                      //268
   "HLT_Photon15_Cleaned_L1R",                      //269
   "HLT_Photon20_Cleaned_L1R",                      //270
   "HLT_Photon20_NoHE_L1R",                         //271
   "HLT_Photon30_Cleaned_L1R",                      //272
   "HLT_Photon50_NoHE_Cleaned_L1R",                 //273
   "HLT_Photon50_NoHE_L1R",                         //274
   "HLT_PixelTracks_Multiplicity100",               //275
   "HLT_PixelTracks_Multiplicity70",                //276
   "HLT_PixelTracks_Multiplicity85",                //277
   "HLT_QuadJet20U",                                //278
   "HLT_QuadJet25U",                                //279
   "HLT_SingleIsoTau20_Trk15_MET20",                //280
   "HLT_SingleIsoTau20_Trk5_MET20",                 //281
   "HLT_StoppedHSCP",                               //282
   "HLT_Activity_Ecal_SC17",                        //283
   "HLT_Activity_Ecal_SC7",                         //284
   "HLT_BTagMu_DiJet10U_v1",                        //285
   "HLT_BTagMu_DiJet20U_Mu5_v1",                    //286
   "HLT_BTagMu_DiJet20U_v1",                        //287
   "HLT_BTagMu_Jet20U",                             //288
   "HLT_DiJetAve100U_v1",                           //289
   "HLT_DiJetAve70U_v2",                            //290
   "HLT_DoubleEle15_SW_L1R",                        //291
   "HLT_DoubleEle17_SW_L1R",                        //292
   "HLT_DoubleMu0_Quarkonium_v1",                   //293
   "HLT_DoubleMu3_v2",                              //294
   "HLT_DoubleMu5_v1",                              //295
   "HLT_DoublePhoton17SingleIsol_L1R_v1",           //296
   "HLT_DoublePhoton22_L1R_v1",                     //297
   "HLT_EcalOnly_SumEt160_v2",                      //298
   "HLT_Ele12_SW_TighterEleIdIsol_L1R",             //299
   "HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R",        //300
   "HLT_Ele17_SW_TightCaloEleId_SC8HE_L1R",         //301
   "HLT_Ele17_SW_TightEleIdIsol_L1R",               //302
   "HLT_Ele17_SW_TightEleId_L1R",                   //303
   "HLT_Ele17_SW_TighterEleIdIsol_L1R",             //304
   "HLT_Ele17_SW_TighterEleIdIsol_L1R_v2",          //305
   "HLT_Ele17_SW_TighterEleId_L1R",                 //306
   "HLT_Ele22_SW_TighterCaloIdIsol_L1R_v1",         //307
   "HLT_Ele22_SW_TighterEleId_L1R_v2",              //308
   "HLT_Ele27_SW_TightCaloEleIdTrack_L1R",          //309
   "HLT_Ele32_SW_TightCaloEleIdTrack_L1R",          //310
   "HLT_Ele32_SW_TighterEleId_L1R",                 //311
   "HLT_ExclDiJet30U_HFAND_v1",                     //312
   "HLT_ExclDiJet30U_HFOR_v1",                      //313
   "HLT_HT160U_v1",                                 //314
   "HLT_HT200U_v1",                                 //315
   "HLT_HT50U_v1",                                  //316
   "HLT_IsoEle12_PFTau15_v1",                       //317
   "HLT_IsoMu11_v1",                                //318
   "HLT_IsoTrackHB_v2",                             //319
   "HLT_IsoTrackHE_v2",                             //320
   "HLT_Jet100U_v2",                                //321
   "HLT_Jet140U_v1",                                //322
   "HLT_Jet15U_HcalNoiseFiltered",                  //323
   "HLT_Jet70U_v2",                                 //324
   "HLT_L1Mu7_v1",                                  //325
   "HLT_L1MuOpen_DT",                               //326
   "HLT_L2DoubleMu20_NoVertex_v1",                  //327
   "HLT_L2Mu30_v1",                                 //328
   "HLT_L2Mu7_v1",                                  //329
   "HLT_MET100_v2",                                 //330
   "HLT_Mu0_TkMu0_OST_Jpsi_Seagull",                //331
   "HLT_Mu0_TkMu0_OST_Jpsi_Tight",                  //332
   "HLT_Mu13_v1",                                   //333
   "HLT_Mu15_v1",                                   //334
   "HLT_Mu3_TkMu0_OST_Jpsi",                        //335
   "HLT_Mu3_TkMu0_OST_Jpsi_Tight",                  //336
   "HLT_Mu3_Track3_Jpsi",                           //337
   "HLT_Mu5_Ele5_v1",                               //338
   "HLT_Mu5_HT70U_v1",                              //339
   "HLT_Mu5_Jet50U_v1",                             //340
   "HLT_Mu5_MET45_v1",                              //341
   "HLT_Mu5_Photon9_Cleaned_L1R",                   //342
   "HLT_Mu5_TkMu0_OST_Jpsi",                        //343
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight",                  //344
   "HLT_Photon100_NoHE_Cleaned_L1R",                //345
   "HLT_Photon110_NoHE_Cleaned_L1R",                //346
   "HLT_Photon17Isol_SC17HE_L1R",                   //347
   "HLT_Photon17_SC17HE_L1R",                       //348
   "HLT_Photon22_SC22HE_L1R",                       //349
   "HLT_Photon30_Isol_EBOnly_Cleaned_L1R",          //350
   "HLT_Photon35_Isol_Cleaned_L1R",                 //351
   "HLT_Photon40CaloId_Cleaned_L1R",                //352
   "HLT_Photon40Isol_Cleaned_L1R",                  //353
   "HLT_Photon50_Cleaned_L1R",                      //354
   "HLT_Photon70_Cleaned_L1R",                      //355
   "HLT_Photon70_L1R_v1",                           //356
   "HLT_Photon70_NoHE_Cleaned_L1R",                 //357
   "HLT_QuadJet15U_v2",                             //358
   "HLT_QuadJet20U_v2",                             //359
   "HLT_QuadJet25U_v2",                             //360
   "HLT_SingleIsoTau30_Trk5_L120or30",              //361
   "HLT_SingleIsoTau30_Trk5_MET20",                 //362
   "HLT_SingleIsoTau30_Trk5_v2",                    //363
   "HLT_StoppedHSCP_v2",                            //364
   "OpenHLT_BTagMu_DiJet10U",                       //365
   "OpenHLT_BTagMu_DiJet20U",                       //366
   "OpenHLT_BTagMu_DiJet20U_Mu5",                   //367
   "OpenHLT_BTagMu_DiJet30U",                       //368
   "OpenHLT_BTagMu_DiJet30U_Mu5",                   //369
   "OpenHLT_DiJetAve100U",                          //370
   "OpenHLT_DiJetAve140",                           //371
   "OpenHLT_DoubleJet25U_ForwardBackward",          //372
   "OpenHLT_DoubleJet35U_ForwardBackward",          //373
   "OpenHLT_DoubleMu0_Quarkonium",                  //374
   "OpenHLT_DoubleMu0_Quarkonium_LS",               //375
   "OpenHLT_DoubleMu3_HT50U",                       //376
   "OpenHLT_DoubleMu5",                             //377
   "OpenHLT_Ele10_EleId_HT70U",                     //378
   "OpenHLT_Ele10_HT100U",                          //379
   "OpenHLT_Ele10_HT70U",                           //380
   "OpenHLT_Ele10_MET45",                           //381
   "OpenHLT_ExclDiJet30U",                          //382
   "OpenHLT_ExclDiJet30U_HFOR",                     //383
   "OpenHLT_HT120U",                                //384
   "OpenHLT_HT130U",                                //385
   "OpenHLT_HT140U_JT20_Eta3",                      //386
   "OpenHLT_HT140_Eta3_J30",                        //387
   "OpenHLT_HT150U",                                //388
   "OpenHLT_HT150U_Eta3",                           //389
   "OpenHLT_HT160U_Eta3",                           //390
   "OpenHLT_HT160U_JT20",                           //391
   "OpenHLT_HT200U_JT20",                           //392
   "OpenHLT_HT50U",                                 //393
   "OpenHLT_IsoMu11",                               //394
   "OpenHLT_IsoMu13",                               //395
   "OpenHLT_IsoMu15",                               //396
   "OpenHLT_IsoMu17",                               //397
   "OpenHLT_Jet140U",                               //398
   "OpenHLT_Jet180U",                               //399
   "OpenHLT_L1Mu7",                                 //400
   "OpenHLT_L2DoubleMu20",                          //401
   "OpenHLT_L2Mu30",                                //402
   "OpenHLT_L2Mu7",                                 //403
   "OpenHLT_MET120",                                //404
   "OpenHLT_MET45_HT100U",                          //405
   "OpenHLT_MET65",                                 //406
   "OpenHLT_MET65_CenJet50U",                       //407
   "OpenHLT_MET80",                                 //408
   "OpenHLT_MET80_CenJet50U",                       //409
   "OpenHLT_Meff180U",                              //410
   "OpenHLT_Mu0_v1",                                //411
   "OpenHLT_Mu11_Ele8",                             //412
   "OpenHLT_Mu13",                                  //413
   "OpenHLT_Mu15",                                  //414
   "OpenHLT_Mu17",                                  //415
   "OpenHLT_Mu19",                                  //416
   "OpenHLT_Mu25",                                  //417
   "OpenHLT_Mu30_NoVertex",                         //418
   "OpenHLT_Mu3_Track5_Jpsi",                       //419
   "OpenHLT_Mu5_Ele13",                             //420
   "OpenHLT_Mu5_Ele15",                             //421
   "OpenHLT_Mu5_Ele5",                              //422
   "OpenHLT_Mu5_Ele9",                              //423
   "OpenHLT_Mu5_HT100U",                            //424
   "OpenHLT_Mu5_HT50",                              //425
   "OpenHLT_Mu5_Jet35U",                            //426
   "OpenHLT_Mu5_Jet70U",                            //427
   "OpenHLT_Mu5_MET45",                             //428
   "OpenHLT_Mu5_Photon11_L1R",                      //429
   "OpenHLT_Mu7_Ele9",                              //430
   "OpenHLT_Mu7_Photon13_L1R",                      //431
   "OpenHLT_Mu8_Ele8",                              //432
   "OpenHLT_PT12U_50",                              //433
   "OpenHLT_SingleIsoTau20_Trk15_MET25",            //434
   "OpenHLT_SingleIsoTau30_Trk5_MET20",             //435
   "OpenHLT_SingleIsoTau35_Trk15_MET25",            //436
   "DQM_FEDIntegrity_v2",                           //437
   "HLT_Activity_Ecal_SC15",                        //438
   "HLT_BTagMu_DiJet10U_v3",                        //439
   "HLT_BTagMu_DiJet20U_Mu5_v3",                    //440
   "HLT_BTagMu_DiJet20U_v3",                        //441
   "HLT_BTagMu_DiJet30U_Mu5_v3",                    //442
   "HLT_BTagMu_DiJet30U_v3",                        //443
   "HLT_DiJet20U_Meff180U_v3",                      //444
   "HLT_DiJet50U_PT50U_v3",                         //445
   "HLT_DiJetAve100U_v3",                           //446
   "HLT_DiJetAve140U_v3",                           //447
   "HLT_DiJetAve15U_v3",                            //448
   "HLT_DiJetAve30U_v3",                            //449
   "HLT_DiJetAve50U_8E29",                          //450
   "HLT_DiJetAve50U_v3",                            //451
   "HLT_DiJetAve70U_v3",                            //452
   "HLT_DoubleEle15_SW_L1R_v1",                     //453
   "HLT_DoubleEle17_SW_L1R_v1",                     //454
   "HLT_DoubleEle5_SW_Upsilon_L1R_v1",              //455
   "HLT_DoubleEle8_SW_HT70U_L1R_v1",                //456
   "HLT_DoubleIsoTau15_OneLeg_Trk5_v3",             //457
   "HLT_DoubleIsoTau15_Trk5_v3",                    //458
   "HLT_DoubleJet15U_ForwardBackward_v3",           //459
   "HLT_DoubleJet25U_ForwardBackward_v3",           //460
   "HLT_DoubleJet35U_ForwardBackward_v3",           //461
   "HLT_DoubleMu0_Quarkonium_LS_v1",                //462
   "HLT_DoubleMu3_HT50U_v3",                        //463
   "HLT_DoublePhoton17_SingleIsol_L1R_v1",          //464
   "HLT_DoublePhoton20_L1R",                        //465
   "HLT_DoublePhoton5_CEP_L1R_v3",                  //466
   "HLT_DoublePhoton5_eeRes_L1R",                   //467
   "HLT_EcalOnly_SumEt160_v3",                      //468
   "HLT_Ele10_MET45_v1",                            //469
   "HLT_Ele10_SW_EleId_HT70U_L1R_v1",               //470
   "HLT_Ele10_SW_EleId_L1R",                        //471
   "HLT_Ele10_SW_HT100U_L1R_v1",                    //472
   "HLT_Ele10_SW_HT70U_L1R_v1",                     //473
   "HLT_Ele12_SW_TighterEleIdIsol_L1R_v1",          //474
   "HLT_Ele12_SW_TighterEleId_L1R_v1",              //475
   "HLT_Ele15_SW_CaloEleId_L1R",                    //476
   "HLT_Ele17_SW_Isol_L1R_v1",                      //477
   "HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R_v1",     //478
   "HLT_Ele17_SW_TightCaloEleId_SC8HE_L1R_v1",      //479
   "HLT_Ele17_SW_TightEleIdIsol_L1R_v1",            //480
   "HLT_Ele17_SW_TighterEleIdIsol_L1R_v1",          //481
   "HLT_Ele17_SW_TighterEleId_L1R_v1",              //482
   "HLT_Ele22_SW_L1R_v1",                           //483
   "HLT_Ele27_SW_TightCaloEleIdTrack_L1R_v1",       //484
   "HLT_Ele32_SW_TightCaloEleIdTrack_L1R_v1",       //485
   "HLT_Ele32_SW_TighterEleId_L1R_v2",              //486
   "HLT_ExclDiJet30U_HFAND_v3",                     //487
   "HLT_ExclDiJet30U_HFOR_v3",                      //488
   "HLT_HFThreshold10",                             //489
   "HLT_HFThreshold3",                              //490
   "HLT_HT100U_v3",                                 //491
   "HLT_HT130U_v3",                                 //492
   "HLT_HT140U_Eta3_v1",                            //493
   "HLT_HT140U_J30U_Eta3_v3",                       //494
   "HLT_HT150U_Eta3_v3",                            //495
   "HLT_HT150U_v3",                                 //496
   "HLT_HT160U_Eta3_v3",                            //497
   "HLT_HT160U_v3",                                 //498
   "HLT_HT200U_v3",                                 //499
   "HLT_HT50U_v3",                                  //500
   "HLT_IsoMu11_v3",                                //501
   "HLT_IsoMu13_v3",                                //502
   "HLT_IsoMu15_v3",                                //503
   "HLT_IsoMu17_v3",                                //504
   "HLT_IsoMu9_PFTau15_v1",                         //505
   "HLT_IsoMu9_v3",                                 //506
   "HLT_IsoTrackHE_v3",                             //507
   "HLT_Jet100U_v3",                                //508
   "HLT_Jet140U_v3",                                //509
   "HLT_Jet15U_HcalNoiseFiltered_v3",               //510
   "HLT_Jet15U_v3",                                 //511
   "HLT_Jet180U_v3",                                //512
   "HLT_Jet30U_v3",                                 //513
   "HLT_Jet50U_v3",                                 //514
   "HLT_Jet70U_v3",                                 //515
   "HLT_L1DoubleMuOpen_Tight",                      //516
   "HLT_L1ETT140_v1",                               //517
   "HLT_L1MuOpen_AntiBPTX_v2",                      //518
   "HLT_L1MuOpen_DT_v2",                            //519
   "HLT_L1MuOpen_v2",                               //520
   "HLT_L1SingleEG1",                               //521
   "HLT_L1SingleEG1_NoBPTX",                        //522
   "HLT_L1SingleEG20_NoBPTX",                       //523
   "HLT_L1_BSC",                                    //524
   "HLT_L2Mu15",                                    //525
   "HLT_MET100_v3",                                 //526
   "HLT_MET120_v3",                                 //527
   "HLT_MET45_DiJet30U_v3",                         //528
   "HLT_MET45_HT100U_v1",                           //529
   "HLT_MET45_HT120U_v1",                           //530
   "HLT_MET45_v3",                                  //531
   "HLT_MET65_CenJet50U_v3",                        //532
   "HLT_MET80_CenJet50U_v3",                        //533
   "HLT_MET80_v1",                                  //534
   "HLT_MinBias",                                   //535
   "HLT_Mu0_TkMu0_Jpsi",                            //536
   "HLT_Mu0_TkMu0_Jpsi_NoCharge",                   //537
   "HLT_Mu0_TkMu0_OST_Jpsi_Tight_v1",               //538
   "HLT_Mu0_TkMu0_OST_Jpsi_Tight_v2",               //539
   "HLT_Mu0_v2",                                    //540
   "HLT_Mu11_Ele8_v1",                              //541
   "HLT_Mu11_PFTau15_v1",                           //542
   "HLT_Mu17_v1",                                   //543
   "HLT_Mu19_v1",                                   //544
   "HLT_Mu21_v1",                                   //545
   "HLT_Mu25_v1",                                   //546
   "HLT_Mu30_NoVertex_v1",                          //547
   "HLT_Mu3_Ele8_HT70U_v1",                         //548
   "HLT_Mu3_TkMu0_Jpsi",                            //549
   "HLT_Mu3_TkMu0_Jpsi_NoCharge",                   //550
   "HLT_Mu3_TkMu0_OST_Jpsi_Tight_v2",               //551
   "HLT_Mu3_Track3_Jpsi_v2",                        //552
   "HLT_Mu3_Track5_Jpsi_v1",                        //553
   "HLT_Mu3_Track5_Jpsi_v2",                        //554
   "HLT_Mu3_v2",                                    //555
   "HLT_Mu5_Ele13_v2",                              //556
   "HLT_Mu5_Ele17_v1",                              //557
   "HLT_Mu5_Ele9_v1",                               //558
   "HLT_Mu5_HT100U_v3",                             //559
   "HLT_Mu5_HT50U_v1",                              //560
   "HLT_Mu5_HT70U_v3",                              //561
   "HLT_Mu5_Jet35U_v1",                             //562
   "HLT_Mu5_Jet50U_v2",                             //563
   "HLT_Mu5_Jet50U_v3",                             //564
   "HLT_Mu5_Jet70U_v3",                             //565
   "HLT_Mu5_MET45_v3",                              //566
   "HLT_Mu5_Photon11_Cleaned_L1R_v1",               //567
   "HLT_Mu5_TkMu0_Jpsi",                            //568
   "HLT_Mu5_TkMu0_Jpsi_NoCharge",                   //569
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_v1",               //570
   "HLT_Mu7_Photon13_Cleaned_L1R_v1",               //571
   "HLT_Mu8_Ele8_v1",                               //572
   "HLT_Photon100_NoHE_Cleaned_L1R_v1",             //573
   "HLT_Photon110_NoHE_Cleaned_L1R_v1",             //574
   "HLT_Photon15_LooseEcalIso_Cleaned_L1R",         //575
   "HLT_Photon15_TrackIso_Cleaned_L1R",             //576
   "HLT_Photon17_Isol_SC17HE_L1R_v1",               //577
   "HLT_Photon17_SC17HE_L1R_v1",                    //578
   "HLT_Photon20_Isol_Cleaned_L1R_v1",              //579
   "HLT_Photon22_SC22HE_L1R_v1",                    //580
   "HLT_Photon25_Cleaned_L1R",                      //581
   "HLT_Photon30_Isol_EBOnly_Cleaned_L1R_v1",       //582
   "HLT_Photon30_L1R",                              //583
   "HLT_Photon35_Isol_Cleaned_L1R_v1",              //584
   "HLT_Photon40_CaloId_Cleaned_L1R_v1",            //585
   "HLT_Photon40_Isol_Cleaned_L1R_v1",              //586
   "HLT_Photon50_Cleaned_L1R_v1",                   //587
   "HLT_Photon50_L1R",                              //588
   "HLT_Photon70_Cleaned_L1R_v1",                   //589
   "HLT_Photon70_NoHE_Cleaned_L1R_v1",              //590
   "HLT_Physics",                                   //591
   "HLT_PixelTracks_Multiplicity40",                //592
   "HLT_QuadJet15U_v3",                             //593
   "HLT_QuadJet20U_v3",                             //594
   "HLT_QuadJet25U_v3",                             //595
   "HLT_R010U_MR50U",                               //596
   "HLT_R030U_MR100U",                              //597
   "HLT_R033U_MR100U",                              //598
   "HLT_RP025U_MR70U",                              //599
   "HLT_SingleIsoTau20_Trk15_MET25_v3",             //600
   "HLT_SingleIsoTau20_Trk5",                       //601
   "HLT_SingleIsoTau35_Trk15_MET25_v3",             //602
   "HLT_SingleLooseIsoTau20_Trk5",                  //603
   "HLT_SingleLooseIsoTau25",                       //604
   "HLT_SingleLooseIsoTau25_Trk5",                  //605
   "HLT_StoppedHSCP20_v3",                          //606
   "HLT_StoppedHSCP35_v3",                          //607
   "HLT_DoubleEle4_SW_eeRes_L1R_v2",                //608
   "HLT_DoubleEle5_SW_Upsilon_L1R_v2",              //609
   "HLT_DoubleIsoTau15_OneLeg_Trk5_v4",             //610
   "HLT_DoubleIsoTau15_Trk5_v4",                    //611
   "HLT_Ele10_SW_EleId_HT70U_L1R_v2",               //612
   "HLT_Ele10_SW_HT100U_L1R_v2",                    //613
   "HLT_Ele10_SW_HT70U_L1R_v2",                     //614
   "HLT_Ele10_SW_L1R_v2",                           //615
   "HLT_Ele12_SW_TighterEleId_L1R_v2",              //616
   "HLT_Ele17_SW_Isol_L1R_v2",                      //617
   "HLT_Ele17_SW_L1R_v2",                           //618
   "HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R_v2",     //619
   "HLT_Ele17_SW_TighterEleIdIsol_L1R_v3",          //620
   "HLT_Ele22_SW_L1R_v2",                           //621
   "HLT_Ele22_SW_TighterCaloIdIsol_L1R_v2",         //622
   "HLT_Ele22_SW_TighterEleId_L1R_v3",              //623
   "HLT_IsoEle12_PFTau15_v2",                       //624
   "HLT_IsoEle12_PFTau15_v3",                       //625
   "HLT_IsoMu11_v4",                                //626
   "HLT_IsoMu13_v4",                                //627
   "HLT_IsoMu15_v4",                                //628
   "HLT_IsoMu17_v4",                                //629
   "HLT_IsoMu9_PFTau15_v2",                         //630
   "HLT_IsoMu9_v4",                                 //631
   "HLT_Mu0_TkMu0_OST_Jpsi_Tight_v3",               //632
   "HLT_Mu11_PFTau15_v2",                           //633
   "HLT_Mu3_TkMu0_OST_Jpsi_Tight_v3",               //634
   "HLT_Mu3_Track3_Jpsi_v3",                        //635
   "HLT_Mu3_Track5_Jpsi_v3",                        //636
   "HLT_Mu5_Ele17_v2",                              //637
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_v2",               //638
   "HLT_Mu5_Track0_Jpsi_v2",                        //639
   "HLT_MultiVertex6_v2",                           //640
   "HLT_MultiVertex8_L1ETT60_v2",                   //641
   "HLT_SingleIsoTau20_Trk15_MET25_v4",             //642
   "HLT_SingleIsoTau35_Trk15_MET25_v4",             //643
   "HLT_BeamGas_BSC_v1",                            //644
   "HLT_BeamGas_BSC_v2",                            //645
   "HLT_BeamGas_HF_v1",                             //646
   "HLT_BeamGas_HF_v2",                             //647
   "HLT_BeamHalo_v2",                               //648
   "HLT_BTagMu_DiJet100_Mu9_v2",                    //649
   "HLT_BTagMu_DiJet20_Mu5_v1",                     //650
   "HLT_BTagMu_DiJet20_Mu5_v2",                     //651
   "HLT_BTagMu_DiJet60_Mu7_v1",                     //652
   "HLT_BTagMu_DiJet60_Mu7_v2",                     //653
   "HLT_BTagMu_DiJet80_Mu9_v1",                     //654
   "HLT_BTagMu_DiJet80_Mu9_v2",                     //655
   "HLT_CentralJet80_MET100_v1",                    //656
   "HLT_CentralJet80_MET160_v1",                    //657
   "HLT_CentralJet80_MET65_v1",                     //658
   "HLT_CentralJet80_MET80_v1",                     //659
   "HLT_DiJet100_PT100_v1",                         //660
   "HLT_DiJet130_PT130_v1",                         //661
   "HLT_DiJet60_MET45_v1",                          //662
   "HLT_DiJet70_PT70_v1",                           //663
   "HLT_DiJetAve100U_v4",                           //664
   "HLT_DiJetAve140U_v4",                           //665
   "HLT_DiJetAve180U_v4",                           //666
   "HLT_DiJetAve300U_v4",                           //667
   "HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v1",      //668
   "HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v2",      //669
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_HT160_v2",       //670
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_HT160_v3",       //671
   "HLT_DoubleEle8_CaloIdT_TrkIdVL_HT160_v2",       //672
   "HLT_DoubleEle8_CaloIdT_TrkIdVL_HT160_v3",       //673
   "HLT_DoubleIsoPFTau20_Trk5_v1",                  //674
   "HLT_DoubleIsoPFTau20_Trk5_v2",                  //675
   "HLT_DoubleJet30_ForwardBackward_v1",            //676
   "HLT_DoubleJet30_ForwardBackward_v2",            //677
   "HLT_DoubleJet60_ForwardBackward_v1",            //678
   "HLT_DoubleJet60_ForwardBackward_v2",            //679
   "HLT_DoubleJet70_ForwardBackward_v1",            //680
   "HLT_DoubleJet70_ForwardBackward_v2",            //681
   "HLT_DoubleJet80_ForwardBackward_v1",            //682
   "HLT_DoubleJet80_ForwardBackward_v2",            //683
   "HLT_DoubleMu2_Bs_v1",                           //684
   "HLT_DoubleMu4_Acoplanarity03_v1",               //685
   "HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v2",         //686
   "HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v3",         //687
   "HLT_DoubleMu5_Ele8_v2",                         //688
   "HLT_DoubleMu5_Ele8_v3",                         //689
   "HLT_DoubleMu6_v1",                              //690
   "HLT_DoubleMu7_v1",                              //691
   "HLT_DoublePhoton33_v1",                         //692
   "HLT_DoublePhoton33_v2",                         //693
   "HLT_DoublePhoton5_IsoVL_CEP_v1",                //694
   "HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v2", //695
   "HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v3", //696
   "HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v2", //697
   "HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v3", //698
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v1", //699
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v2", //700
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v1", //701
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v2", //702
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1", //703
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2", //704
   "HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v1",  //705
   "HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v2",  //706
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v1",      //707
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v2",      //708
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v1", //709
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v2", //710
   "HLT_Ele17_CaloIdL_CaloIsoVL_v1",                //711
   "HLT_Ele17_CaloIdL_CaloIsoVL_v2",                //712
   "HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v2", //713
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v1", //714
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v2", //715
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v1",   //716
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v2",   //717
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v1",     //718
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v2",     //719
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet40_BTagIP_v1", //720
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet40_BTagIP_v2", //721
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v1",  //722
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v2",  //723
   "HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1", //724
   "HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2", //725
   "HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v1",           //726
   "HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v2",           //727
   "HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1", //728
   "HLT_Ele45_CaloIdVT_TrkIdT_v1",                  //729
   "HLT_Ele45_CaloIdVT_TrkIdT_v2",                  //730
   "HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v1",           //731
   "HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v2",           //732
   "HLT_Ele8_CaloIdL_CaloIsoVL_v1",                 //733
   "HLT_Ele8_CaloIdL_CaloIsoVL_v2",                 //734
   "HLT_Ele8_CaloIdL_TrkIdVL_v1",                   //735
   "HLT_Ele8_CaloIdL_TrkIdVL_v2",                   //736
   "HLT_Ele8_v1",                                   //737
   "HLT_Ele8_v2",                                   //738
   "HLT_Ele90_NoSpikeFilter_v1",                    //739
   "HLT_Ele90_NoSpikeFilter_v2",                    //740
   "HLT_ExclDiJet60_HFAND_v1",                      //741
   "HLT_ExclDiJet60_HFOR_v1",                       //742
   "HLT_HT150_AlphaT0p60_v1",                       //743
   "HLT_HT150_AlphaT0p70_v1",                       //744
   "HLT_HT150_v2",                                  //745
   "HLT_HT160_v2",                                  //746
   "HLT_HT250_AlphaT0p55_v1",                       //747
   "HLT_HT250_AlphaT0p62_v1",                       //748
   "HLT_HT250_DoubleDisplacedJet60_v1",             //749
   "HLT_HT250_MHT60_v2",                            //750
   "HLT_HT250_v2",                                  //751
   "HLT_HT260_MHT60_v2",                            //752
   "HLT_HT260_v2",                                  //753
   "HLT_HT300_AlphaT0p52_v1",                       //754
   "HLT_HT300_AlphaT0p54_v1",                       //755
   "HLT_HT300_MHT75_v2",                            //756
   "HLT_HT300_MHT75_v3",                            //757
   "HLT_HT300_v2",                                  //758
   "HLT_HT300_v3",                                  //759
   "HLT_HT350_AlphaT0p51_v1",                       //760
   "HLT_HT350_AlphaT0p53_v1",                       //761
   "HLT_HT350_v2",                                  //762
   "HLT_HT360_v2",                                  //763
   "HLT_HT400_AlphaT0p51_v1",                       //764
   "HLT_HT400_v2",                                  //765
   "HLT_HT440_v2",                                  //766
   "HLT_HT450_v2",                                  //767
   "HLT_HT500_v2",                                  //768
   "HLT_HT520_v2",                                  //769
   "HLT_HT550_v2",                                  //770
   "HLT_IsoMu12_LooseIsoPFTau10_v1",                //771
   "HLT_IsoMu12_LooseIsoPFTau10_v2",                //772
   "HLT_IsoMu12_v1",                                //773
   "HLT_IsoMu15_v5",                                //774
   "HLT_IsoMu17_CentralJet40_BTagIP_v1",            //775
   "HLT_IsoMu17_CentralJet40_BTagIP_v2",            //776
   "HLT_IsoMu17_v5",                                //777
   "HLT_IsoMu24_v1",                                //778
   "HLT_IsoPFTau35_Trk20_MET45_v1",                 //779
   "HLT_IsoPFTau35_Trk20_MET45_v2",                 //780
   "HLT_Jet150_v1",                                 //781
   "HLT_Jet190_v1",                                 //782
   "HLT_Jet240_v1",                                 //783
   "HLT_Jet370_NoJetID_v1",                         //784
   "HLT_Jet370_v1",                                 //785
   "HLT_Jet60_v1",                                  //786
   "HLT_JetE30_NoBPTX3BX_NoHalo_v1",                //787
   "HLT_JetE30_NoBPTX3BX_NoHalo_v2",                //788
   "HLT_JetE30_NoBPTX_NoHalo_v1",                   //789
   "HLT_JetE30_NoBPTX_NoHalo_v2",                   //790
   "HLT_JetE30_NoBPTX_v1",                          //791
   "HLT_L1_BeamHalo_v1",                            //792
   "HLT_L1DoubleMu0_v1",                            //793
   "HLT_L1_Interbunch_BSC_v1",                      //794
   "HLT_L1_PreCollisions_v1",                       //795
   "HLT_L1SingleJet36_v1",                          //796
   "HLT_L1SingleMu10_v1",                           //797
   "HLT_L1SingleMu20_v1",                           //798
   "HLT_L1SingleMuOpen_AntiBPTX_v1",                //799
   "HLT_L1SingleMuOpen_DT_v1",                      //800
   "HLT_L1SingleMuOpen_v1",                         //801
   "HLT_L1Tech_CASTOR_HaloMuon_v1",                 //802
   "HLT_L1Tech_HBHEHO_totalOR_v1",                  //803
   "HLT_L1TrackerCosmics_v2",                       //804
   "HLT_L2DoubleMu23_NoVertex_v1",                  //805
   "HLT_L2DoubleMu35_NoVertex_v1",                  //806
   "HLT_L2Mu10_v1",                                 //807
   "HLT_L2Mu20_v1",                                 //808
   "HLT_L2MuOpen_NoVertex_v1",                      //809
   "HLT_L3MuonsCosmicTracking_v1",                  //810
   "HLT_Meff440_v2",                                //811
   "HLT_Meff520_v2",                                //812
   "HLT_Meff640_v2",                                //813
   "HLT_MET120_v1",                                 //814
   "HLT_MET200_v1",                                 //815
   "HLT_MR100_v1",                                  //816
   "HLT_Mu10_Ele10_CaloIdL_v2",                     //817
   "HLT_Mu10_Ele10_CaloIdL_v3",                     //818
   "HLT_Mu12_v1",                                   //819
   "HLT_Mu17_CentralJet30_v1",                      //820
   "HLT_Mu17_CentralJet30_v2",                      //821
   "HLT_Mu17_CentralJet40_BTagIP_v1",               //822
   "HLT_Mu17_CentralJet40_BTagIP_v2",               //823
   "HLT_Mu17_DiCentralJet30_v1",                    //824
   "HLT_Mu17_DiCentralJet30_v2",                    //825
   "HLT_Mu17_Ele8_CaloIdL_v1",                      //826
   "HLT_Mu17_Ele8_CaloIdL_v2",                      //827
   "HLT_Mu17_TriCentralJet30_v1",                   //828
   "HLT_Mu17_TriCentralJet30_v2",                   //829
   "HLT_Mu20_v1",                                   //830
   "HLT_Mu24_v1",                                   //831
   "HLT_Mu8_Ele17_CaloIdL_v1",                      //832
   "HLT_Mu8_Ele17_CaloIdL_v2",                      //833
   "HLT_Mu8_HT200_v2",                              //834
   "HLT_Mu8_HT200_v3",                              //835
   "HLT_Mu8_Jet40_v2",                              //836
   "HLT_Mu8_Jet40_v3",                              //837
   "HLT_Mu8_Photon20_CaloIdVT_IsoT_v2",             //838
   "HLT_Mu8_v1",                                    //839
   "HLT_PFMHT150_v1",                               //840
   "HLT_PFMHT150_v2",                               //841
   "HLT_Photon125_NoSpikeFilter_v1",                //842
   "HLT_Photon125_NoSpikeFilter_v2",                //843
   "HLT_Photon20_CaloIdVL_IsoL_v1",                 //844
   "HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v1", //845
   "HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v2", //846
   "HLT_Photon20_EBOnly_NoSpikeFilter_v1",          //847
   "HLT_Photon20_NoSpikeFilter_v1",                 //848
   "HLT_Photon20_R9Id_Photon18_R9Id_v1",            //849
   "HLT_Photon20_R9Id_Photon18_R9Id_v2",            //850
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v1", //851
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v2", //852
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v1",   //853
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_v1",        //854
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_v2",        //855
   "HLT_Photon26_IsoVL_Photon18_IsoVL_v1",          //856
   "HLT_Photon26_IsoVL_Photon18_IsoVL_v2",          //857
   "HLT_Photon26_IsoVL_Photon18_v1",                //858
   "HLT_Photon26_IsoVL_Photon18_v2",                //859
   "HLT_Photon26_Photon18_v1",                      //860
   "HLT_Photon26_Photon18_v2",                      //861
   "HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v1",   //862
   "HLT_Photon30_CaloIdVL_IsoL_v1",                 //863
   "HLT_Photon30_CaloIdVL_IsoL_v2",                 //864
   "HLT_Photon30_CaloIdVL_v1",                      //865
   "HLT_Photon30_CaloIdVL_v2",                      //866
   "HLT_Photon32_CaloIdL_Photon26_CaloIdL_v1",      //867
   "HLT_Photon32_CaloIdL_Photon26_CaloIdL_v2",      //868
   "HLT_Photon36_CaloIdL_Photon22_CaloIdL_v1",      //869
   "HLT_Photon50_CaloIdVL_IsoL_v1",                 //870
   "HLT_Photon60_CaloIdL_HT200_v1",                 //871
   "HLT_Photon60_CaloIdL_HT200_v2",                 //872
   "HLT_Photon70_CaloIdL_HT200_v1",                 //873
   "HLT_Photon70_CaloIdL_HT200_v2",                 //874
   "HLT_Photon70_CaloIdL_HT300_v1",                 //875
   "HLT_Photon70_CaloIdL_HT300_v2",                 //876
   "HLT_Photon70_CaloIdL_MHT30_v1",                 //877
   "HLT_Photon70_CaloIdL_MHT30_v2",                 //878
   "HLT_Photon70_CaloIdL_MHT50_v1",                 //879
   "HLT_Photon70_CaloIdL_MHT50_v2",                 //880
   "HLT_Photon75_CaloIdVL_IsoL_v1",                 //881
   "HLT_Photon75_CaloIdVL_IsoL_v2",                 //882
   "HLT_Photon75_CaloIdVL_v1",                      //883
   "HLT_Photon75_CaloIdVL_v2",                      //884
   "HLT_PixelTracks_Multiplicity110_v1",            //885
   "HLT_PixelTracks_Multiplicity125_v1",            //886
   "HLT_PixelTracks_Multiplicity80_v2",             //887
   "HLT_QuadJet40_IsoPFTau40_v1",                   //888
   "HLT_QuadJet40_v1",                              //889
   "HLT_QuadJet40_v2",                              //890
   "HLT_QuadJet50_BTagIP_v1",                       //891
   "HLT_QuadJet50_Jet40_v1",                        //892
   "HLT_QuadJet60_v1",                              //893
   "HLT_QuadJet70_v1",                              //894
   "HLT_R032_MR100_v1",                             //895
   "HLT_R032_v1",                                   //896
   "HLT_R035_MR100_v1",                             //897
   "HLT_RegionalCosmicTracking_v1",                 //898
   "HLT_Spike20_v1",                                //899
   "HLT_TrackerCalibration_v1",                     //900
   "HLT_TripleEle10_CaloIdL_TrkIdVL_v1",            //901
   "HLT_TripleEle10_CaloIdL_TrkIdVL_v2",            //902
   "HLT_TripleMu5_v2",                               //903
   "HLT_BeamGas_HF_v3",                             //904
   "HLT_BTagMu_DiJet110_Mu5_v3",                    //905
   "HLT_BTagMu_DiJet20_Mu5_v3",                     //906
   "HLT_BTagMu_DiJet40_Mu5_v3",                     //907
   "HLT_BTagMu_DiJet70_Mu5_v3",                     //908
   "HLT_CentralJet80_MET100_v2",                    //909
   "HLT_CentralJet80_MET160_v2",                    //910
   "HLT_CentralJet80_MET65_v2",                     //911
   "HLT_CentralJet80_MET80_v2",                     //912
   "HLT_DiJet60_MET45_v2",                          //913
   "HLT_DiJetAve110_v1",                            //914
   "HLT_DiJetAve110_v2",                            //915
   "HLT_DiJetAve150_v1",                            //916
   "HLT_DiJetAve150_v2",                            //917
   "HLT_DiJetAve190_v1",                            //918
   "HLT_DiJetAve190_v2",                            //919
   "HLT_DiJetAve240_v1",                            //920
   "HLT_DiJetAve240_v2",                            //921
   "HLT_DiJetAve300_v1",                            //922
   "HLT_DiJetAve300_v2",                            //923
   "HLT_DiJetAve30_v1",                             //924
   "HLT_DiJetAve30_v2",                             //925
   "HLT_DiJetAve370_v1",                            //926
   "HLT_DiJetAve370_v2",                            //927
   "HLT_DiJetAve60_v1",                             //928
   "HLT_DiJetAve60_v2",                             //929
   "HLT_DiJetAve80_v1",                             //930
   "HLT_DiJetAve80_v2",                             //931
   "HLT_Dimuon0_Barrel_Upsilon_v1",                 //932
   "HLT_Dimuon6p5_Barrel_Jpsi_v1",                  //933
   "HLT_Dimuon6p5_Barrel_PsiPrime_v1",              //934
   "HLT_Dimuon6p5_Jpsi_Displaced_v1",               //935
   "HLT_Dimuon6p5_Jpsi_v1",                         //936
   "HLT_Dimuon6p5_LowMass_Displaced_v1",            //937
   "HLT_Dimuon6p5_LowMass_v1",                      //938
   "HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v3",      //939
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v1",       //940
   "HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v1",       //941
   "HLT_DoubleIsoPFTau20_Trk5_v4",                  //942
   "HLT_DoubleJet30_ForwardBackward_v3",            //943
   "HLT_DoubleJet60_ForwardBackward_v3",            //944
   "HLT_DoubleJet70_ForwardBackward_v3",            //945
   "HLT_DoubleJet80_ForwardBackward_v3",            //946
   "HLT_DoubleMu2_Bs_v2",                           //947
   "HLT_DoubleMu4_Acoplanarity03_v2",               //948
   "HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v4",         //949
   "HLT_DoubleMu5_Ele8_v4",                         //950
   "HLT_DoubleMu6_v2",                              //951
   "HLT_DoubleMu7_v2",                              //952
   "HLT_DoublePhoton33_v3",                         //953
   "HLT_DoublePhoton5_IsoVL_CEP_v2",                //954
   "HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v4", //955
   "HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v4", //956
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v1", //957
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v1", //958
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v4", //959
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v4", //960
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3", //961
   "HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v1", //962
   "HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v4",  //963
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v3",      //964
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v3", //965
   "HLT_Ele17_CaloIdL_CaloIsoVL_v3",                //966
   "HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v3", //967
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v3", //968
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v3",   //969
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v2", //970
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v3",     //971
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v3",  //972
   "HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3", //973
   "HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v3",           //974
   "HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2", //975
   "HLT_Ele45_CaloIdVT_TrkIdT_v3",                  //976
   "HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v3",           //977
   "HLT_Ele8_CaloIdL_CaloIsoVL_v3",                 //978
   "HLT_Ele8_CaloIdL_TrkIdVL_v3",                   //979
   "HLT_Ele8_v3",                                   //980
   "HLT_Ele90_NoSpikeFilter_v3",                    //981
   "HLT_ExclDiJet60_HFAND_v2",                      //982
   "HLT_ExclDiJet60_HFOR_v2",                       //983
   "HLT_HT150_AlphaT0p60_v2",                       //984
   "HLT_HT150_AlphaT0p70_v2",                       //985
   "HLT_HT150_v3",                                  //986
   "HLT_HT250_AlphaT0p55_v2",                       //987
   "HLT_HT250_AlphaT0p62_v2",                       //988
   "HLT_HT250_DoubleDisplacedJet60_v2",             //989
   "HLT_HT250_DoubleLooseIsoPFTau10_Trk3_PFMHT35_v2", //990
   "HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v2", //991
   "HLT_HT250_MHT60_v3",                            //992
   "HLT_HT250_Mu5_PFMHT35_v2",                      //993
   "HLT_HT250_v3",                                  //994
   "HLT_HT300_AlphaT0p52_v2",                       //995
   "HLT_HT300_AlphaT0p54_v2",                       //996
   "HLT_HT300_MHT75_v4",                            //997
   "HLT_HT300_v4",                                  //998
   "HLT_HT350_AlphaT0p51_v2",                       //999
   "HLT_HT350_AlphaT0p53_v2",                       //1000
   "HLT_HT350_v3",                                  //1001
   "HLT_HT400_AlphaT0p51_v2",                       //1002
   "HLT_HT400_v3",                                  //1003
   "HLT_HT450_v3",                                  //1004
   "HLT_HT500_v3",                                  //1005
   "HLT_HT550_v3",                                  //1006
   "HLT_IsoMu12_LooseIsoPFTau10_v4",                //1007
   "HLT_IsoMu12_v2",                                //1008
   "HLT_IsoMu15_v6",                                //1009
   "HLT_IsoMu17_CentralJet30_BTagIP_v2",            //1010
   "HLT_IsoMu17_v6",                                //1011
   "HLT_IsoMu24_v2",                                //1012
   "HLT_IsoPFTau35_Trk20_MET45_v4",                 //1013
   "HLT_Jet150_v2",                                 //1014
   "HLT_Jet190_v2",                                 //1015
   "HLT_Jet240_v2",                                 //1016
   "HLT_Jet370_NoJetID_v2",                         //1017
   "HLT_Jet370_v2",                                 //1018
   "HLT_Jet60_v2",                                  //1019
   "HLT_JetE30_NoBPTX3BX_NoHalo_v4",                //1020
   "HLT_JetE30_NoBPTX_NoHalo_v4",                   //1021
   "HLT_JetE30_NoBPTX_v2",                          //1022
   "HLT_L1DoubleJet36Central_v1",                   //1023
   "HLT_L1ETM30_v1",                                //1024
   "HLT_L1SingleJet16_v1",                          //1025
   "HLT_L2DoubleMu23_NoVertex_v2",                  //1026
   "HLT_L2Mu10_v2",                                 //1027
   "HLT_L2Mu20_v2",                                 //1028
   "HLT_L3MuonsCosmicTracking_v2",                  //1029
   "HLT_Meff440_v3",                                //1030
   "HLT_Meff520_v3",                                //1031
   "HLT_Meff640_v3",                                //1032
   "HLT_MET120_v2",                                 //1033
   "HLT_MET200_v2",                                 //1034
   "HLT_MR100_v2",                                  //1035
   "HLT_Mu10_Ele10_CaloIdL_v4",                     //1036
   "HLT_Mu12_v2",                                   //1037
   "HLT_Mu17_CentralJet30_BTagIP_v2",               //1038
   "HLT_Mu17_CentralJet30_v4",                      //1039
   "HLT_Mu17_DiCentralJet30_v4",                    //1040
   "HLT_Mu17_Ele8_CaloIdL_v3",                      //1041
   "HLT_Mu17_TriCentralJet30_v4",                   //1042
   "HLT_Mu20_v2",                                   //1043
   "HLT_Mu24_v2",                                   //1044
   "HLT_Mu8_Ele17_CaloIdL_v3",                      //1045
   "HLT_Mu8_HT200_v4",                              //1046
   "HLT_Mu8_Jet40_v4",                              //1047
   "HLT_Mu8_Photon20_CaloIdVT_IsoT_v3",             //1048
   "HLT_Mu8_v2",                                    //1049
   "HLT_PFMHT150_v4",                               //1050
   "HLT_Photon125_NoSpikeFilter_v3",                //1051
   "HLT_Photon20_CaloIdVL_IsoL_v2",                 //1052
   "HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v3", //1053
   "HLT_Photon20_R9Id_Photon18_R9Id_v3",            //1054
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v3", //1055
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v2",   //1056
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_v3",        //1057
   "HLT_Photon26_IsoVL_Photon18_IsoVL_v3",          //1058
   "HLT_Photon26_IsoVL_Photon18_v3",                //1059
   "HLT_Photon26_Photon18_v3",                      //1060
   "HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v2",   //1061
   "HLT_Photon30_CaloIdVL_IsoL_v3",                 //1062
   "HLT_Photon30_CaloIdVL_v3",                      //1063
   "HLT_Photon32_CaloIdL_Photon26_CaloIdL_v3",      //1064
   "HLT_Photon36_CaloIdL_Photon22_CaloIdL_v2",      //1065
   "HLT_Photon50_CaloIdVL_IsoL_v2",                 //1066
   "HLT_Photon60_CaloIdL_HT200_v3",                 //1067
   "HLT_Photon70_CaloIdL_HT200_v3",                 //1068
   "HLT_Photon70_CaloIdL_HT300_v3",                 //1069
   "HLT_Photon70_CaloIdL_MHT30_v3",                 //1070
   "HLT_Photon70_CaloIdL_MHT50_v3",                 //1071
   "HLT_Photon75_CaloIdVL_IsoL_v3",                 //1072
   "HLT_Photon75_CaloIdVL_v3",                      //1073
   "HLT_QuadJet40_IsoPFTau40_v3",                   //1074
   "HLT_QuadJet40_v3",                              //1075
   "HLT_QuadJet50_BTagIP_v2",                       //1076
   "HLT_QuadJet50_Jet40_v2",                        //1077
   "HLT_QuadJet60_v2",                              //1078
   "HLT_QuadJet70_v2",                              //1079
   "HLT_R032_MR100_v2",                             //1080
   "HLT_R032_v2",                                   //1081
   "HLT_R035_MR100_v2",                             //1082
   "HLT_RegionalCosmicTracking_v2",                 //1083
   "HLT_TripleEle10_CaloIdL_TrkIdVL_v3",            //1084
   "HLT_TripleMu5_v3",                              //1085
   "AlCa_EcalEta_v2",                               //1086
   "AlCa_EcalEta_v3",                               //1087
   "AlCa_EcalPhiSym_v2",                            //1088
   "AlCa_EcalPi0_v3",                               //1089
   "AlCa_EcalPi0_v4",                               //1090
   "AlCa_RPCMuonNoHits_v2",                         //1091
   "AlCa_RPCMuonNoHits_v3",                         //1092
   "AlCa_RPCMuonNormalisation_v2",                  //1093
   "AlCa_RPCMuonNormalisation_v3",                  //1094
   "AlCa_RPCMuonNoTriggers_v2",                     //1095
   "AlCa_RPCMuonNoTriggers_v3",                     //1096
   "HLT_Activity_Ecal_SC7_v1",                      //1097
   "HLT_Activity_Ecal_SC7_v2",                      //1098
   "HLT_Calibration_v1",                            //1099
   "HLT_DiJetAve15U_v4",                            //1100
   "HLT_DiJetAve30U_v4",                            //1101
   "HLT_DiJetAve50U_v4",                            //1102
   "HLT_DiJetAve70U_v4",                            //1103
   "HLT_DoubleMu3_Bs_v1",                           //1104
   "HLT_DoubleMu3_HT150_v1",                        //1105
   "HLT_DoubleMu3_HT160_v2",                        //1106
   "HLT_DoubleMu3_HT160_v3",                        //1107
   "HLT_DoubleMu3_HT200_v2",                        //1108
   "HLT_DoubleMu3_HT200_v3",                        //1109
   "HLT_DoubleMu3_HT200_v4",                        //1110
   "HLT_DoubleMu3_Jpsi_v1",                         //1111
   "HLT_DoubleMu3_Jpsi_v2",                         //1112
   "HLT_DoubleMu3_LowMass_v1",                      //1113
   "HLT_DoubleMu3_Quarkonium_v1",                   //1114
   "HLT_DoubleMu3_Quarkonium_v2",                   //1115
   "HLT_DoubleMu3_Upsilon_v1",                      //1116
   "HLT_DoubleMu3_v3",                              //1117
   "HLT_DoubleMu3_v4",                              //1118
   "HLT_DTErrors_v1",                               //1119
   "HLT_EcalCalibration_v1",                        //1120
   "HLT_GlobalRunHPDNoise_v2",                      //1121
   "HLT_HcalCalibration_v1",                        //1122
   "HLT_HcalNZS_v2",                                //1123
   "HLT_HcalNZS_v3",                                //1124
   "HLT_HcalPhiSym_v2",                             //1125
   "HLT_HcalPhiSym_v3",                             //1126
   "HLT_HT200_AlphaT0p60_v1",                       //1127
   "HLT_HT200_AlphaT0p60_v2",                       //1128
   "HLT_HT200_AlphaT0p65_v1",                       //1129
   "HLT_HT200_AlphaT0p65_v2",                       //1130
   "HLT_HT200_DoubleLooseIsoPFTau10_Trk3_PFMHT35_v2", //1131
   "HLT_HT200_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v2", //1132
   "HLT_HT200_Mu5_PFMHT35_v2",                      //1133
   "HLT_HT200_v2",                                  //1134
   "HLT_HT200_v3",                                  //1135
   "HLT_HT240_v2",                                  //1136
   "HLT_IsoMu30_v1",                                //1137
   "HLT_IsoMu30_v2",                                //1138
   "HLT_Jet110_v1",                                 //1139
   "HLT_Jet110_v2",                                 //1140
   "HLT_Jet300_v1",                                 //1141
   "HLT_Jet30_v1",                                  //1142
   "HLT_Jet30_v2",                                  //1143
   "HLT_Jet80_v1",                                  //1144
   "HLT_Jet80_v2",                                  //1145
   "HLT_L1MultiJet_v1",                             //1146
   "HLT_L1SingleEG12_v1",                           //1147
   "HLT_L1SingleEG5_v1",                            //1148
   "HLT_L1Tech_BSC_halo_v1",                        //1149
   "HLT_L1Tech_BSC_halo_v3",                        //1150
   "HLT_L1Tech_BSC_minBias_threshold1_v1",          //1151
   "HLT_L1Tech_BSC_minBias_threshold1_v2",          //1152
   "HLT_L1Tech_BSC_minBias_threshold1_v3",          //1153
   "HLT_L2DoubleMu0_v2",                            //1154
   "HLT_L2DoubleMu0_v3",                            //1155
   "HLT_LogMonitor_v1",                             //1156
   "HLT_MET100_v1",                                 //1157
   "HLT_Mu15_DoublePhoton15_CaloIdL_v2",            //1158
   "HLT_Mu15_DoublePhoton15_CaloIdL_v3",            //1159
   "HLT_Mu15_DoublePhoton15_CaloIdL_v4",            //1160
   "HLT_Mu15_LooseIsoPFTau20_v1",                   //1161
   "HLT_Mu15_LooseIsoPFTau20_v2",                   //1162
   "HLT_Mu15_LooseIsoPFTau20_v4",                   //1163
   "HLT_Mu15_Photon20_CaloIdL_v2",                  //1164
   "HLT_Mu15_Photon20_CaloIdL_v3",                  //1165
   "HLT_Mu15_Photon20_CaloIdL_v4",                  //1166
   "HLT_Mu15_v2",                                   //1167
   "HLT_Mu15_v3",                                   //1168
   "HLT_Mu30_v1",                                   //1169
   "HLT_Mu30_v2",                                   //1170
   "HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v1",         //1171
   "HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT160_v2",         //1172
   "HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT160_v3",         //1173
   "HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v1",         //1174
   "HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT160_v2",         //1175
   "HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT160_v3",         //1176
   "HLT_Mu3_Track3_Jpsi_v4",                        //1177
   "HLT_Mu3_Track3_Jpsi_v5",                        //1178
   "HLT_Mu3_v3",                                    //1179
   "HLT_Mu3_v4",                                    //1180
   "HLT_Mu5_DoubleEle8_v2",                         //1181
   "HLT_Mu5_DoubleEle8_v3",                         //1182
   "HLT_Mu5_DoubleEle8_v4",                         //1183
   "HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v2",          //1184
   "HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v3",          //1185
   "HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v4",          //1186
   "HLT_Mu5_HT200_v3",                              //1187
   "HLT_Mu5_HT200_v4",                              //1188
   "HLT_Mu5_HT200_v5",                              //1189
   "HLT_Mu5_L2Mu2_Jpsi_v1",                         //1190
   "HLT_Mu5_L2Mu2_Jpsi_v2",                         //1191
   "HLT_Mu5_L2Mu2_Jpsi_v3",                         //1192
   "HLT_Mu5_L2Mu2_v1",                              //1193
   "HLT_Mu5_L2Mu2_v2",                              //1194
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v1",          //1195
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v2",          //1196
   "HLT_Mu5_Track2_Jpsi_v1",                        //1197
   "HLT_Mu5_Track2_Jpsi_v2",                        //1198
   "HLT_Mu5_v3",                                    //1199
   "HLT_Mu5_v4",                                    //1200
   "HLT_Mu7_Track5_Jpsi_v1",                        //1201
   "HLT_Mu7_Track5_Jpsi_v2",                        //1202
   "HLT_Mu7_Track7_Jpsi_v1",                        //1203
   "HLT_Mu7_Track7_Jpsi_v2",                        //1204
   "HLT_Mu7_Track7_Jpsi_v3",                        //1205
   "HLT_Physics_NanoDST_v1",                        //1206
   "HLT_Physics_v1",                                //1207
   "HLT_PixelTracks_Multiplicity100_v2",            //1208
   "HLT_Random_v1",                                 //1209
   "HLT_ZeroBias_v1",                               //1210
   "HLT_ZeroBias_v2",                               //1211
   "AlCa_EcalEta_v4",                                                                       //1212
   "AlCa_EcalEta_v5",                                                                       //1213
   "AlCa_EcalEta_v6",                                                                       //1214
   "AlCa_EcalEta_vDEAD",                                                                    //1215
   "AlCa_EcalPhiSym_v3",                                                                    //1216
   "AlCa_EcalPhiSym_v5",                                                                    //1217
   "AlCa_EcalPhiSym_v6",                                                                    //1218
   "AlCa_EcalPi0_v5",                                                                       //1219
   "AlCa_EcalPi0_v6",                                                                       //1220
   "AlCa_EcalPi0_v7",                                                                       //1221
   "AlCa_EcalPi0_vDEAD",                                                                    //1222
   "AlCa_RPCMuonNoHits_v4",                                                                 //1223
   "AlCa_RPCMuonNoHits_v5",                                                                 //1224
   "AlCa_RPCMuonNoTriggers_v4",                                                             //1225
   "AlCa_RPCMuonNoTriggers_v5",                                                             //1226
   "AlCa_RPCMuonNormalisation_v4",                                                          //1227
   "AlCa_RPCMuonNormalisation_v5",                                                          //1228
   "HLT_Activity_Ecal_SC7_v3",                                                              //1229
   "HLT_Activity_Ecal_SC7_v5",                                                              //1230
   "HLT_Activity_Ecal_SC7_v6",                                                              //1231
   "HLT_BTagMu_DiJet110_Mu5_v4",                                                            //1232
   "HLT_BTagMu_DiJet110_Mu5_v5",                                                            //1233
   "HLT_BTagMu_DiJet110_Mu5_v6",                                                            //1234
   "HLT_BTagMu_DiJet20_Mu5_v4",                                                             //1235
   "HLT_BTagMu_DiJet20_Mu5_v5",                                                             //1236
   "HLT_BTagMu_DiJet20_Mu5_v6",                                                             //1237
   "HLT_BTagMu_DiJet40_Mu5_v4",                                                             //1238
   "HLT_BTagMu_DiJet40_Mu5_v5",                                                             //1239
   "HLT_BTagMu_DiJet40_Mu5_v6",                                                             //1240
   "HLT_BTagMu_DiJet70_Mu5_v4",                                                             //1241
   "HLT_BTagMu_DiJet70_Mu5_v5",                                                             //1242
   "HLT_BTagMu_DiJet70_Mu5_v6",                                                             //1243
   "HLT_BeamGas_BSC_v3",                                                                    //1244
   "HLT_BeamGas_HF_v4",                                                                     //1245
   "HLT_BeamGas_HF_v5",                                                                     //1246
   "HLT_BeamHalo_v3",                                                                       //1247
   "HLT_CentralJet46_BTagIP3D_CentralJet38_BTagIP3D_v1",                                    //1248
   "HLT_CentralJet46_BTagIP3D_CentralJet38_BTagIP3D_v2",                                    //1249
   "HLT_CentralJet80_MET100_v3",                                                            //1250
   "HLT_CentralJet80_MET100_v4",                                                            //1251
   "HLT_CentralJet80_MET100_v5",                                                            //1252
   "HLT_CentralJet80_MET160_v3",                                                            //1253
   "HLT_CentralJet80_MET160_v4",                                                            //1254
   "HLT_CentralJet80_MET160_v5",                                                            //1255
   "HLT_CentralJet80_MET65_v3",                                                             //1256
   "HLT_CentralJet80_MET65_v4",                                                             //1257
   "HLT_CentralJet80_MET65_v5",                                                             //1258
   "HLT_CentralJet80_MET80HF_v2",                                                           //1259
   "HLT_CentralJet80_MET80HF_v3",                                                           //1260
   "HLT_CentralJet80_MET80HF_v4",                                                           //1261
   "HLT_DTCalibration_v1",                                                                  //1262
   "HLT_DiCentralJet20_BTagIP_MET65_v2",                                                    //1263
   "HLT_DiCentralJet20_BTagIP_MET65_v3",                                                    //1264
   "HLT_DiCentralJet20_BTagIP_MET65_v4",                                                    //1265
   "HLT_DiCentralJet20_MET80_v1",                                                           //1266
   "HLT_DiCentralJet20_MET80_v2",                                                           //1267
   "HLT_DiCentralJet20_MET80_v3",                                                           //1268
   "HLT_DiJet130_PT130_v2",                                                                 //1269
   "HLT_DiJet130_PT130_v3",                                                                 //1270
   "HLT_DiJet130_PT130_v4",                                                                 //1271
   "HLT_DiJet160_PT160_v2",                                                                 //1272
   "HLT_DiJet160_PT160_v3",                                                                 //1273
   "HLT_DiJet160_PT160_v4",                                                                 //1274
   "HLT_DiJet60_MET45_v3",                                                                  //1275
   "HLT_DiJet60_MET45_v4",                                                                  //1276
   "HLT_DiJet60_MET45_v5",                                                                  //1277
   "HLT_DiJetAve110_v3",                                                                    //1278
   "HLT_DiJetAve110_v4",                                                                    //1279
   "HLT_DiJetAve110_v5",                                                                    //1280
   "HLT_DiJetAve150_v3",                                                                    //1281
   "HLT_DiJetAve150_v4",                                                                    //1282
   "HLT_DiJetAve150_v5",                                                                    //1283
   "HLT_DiJetAve190_v3",                                                                    //1284
   "HLT_DiJetAve190_v4",                                                                    //1285
   "HLT_DiJetAve190_v5",                                                                    //1286
   "HLT_DiJetAve240_v3",                                                                    //1287
   "HLT_DiJetAve240_v4",                                                                    //1288
   "HLT_DiJetAve240_v5",                                                                    //1289
   "HLT_DiJetAve300_v3",                                                                    //1290
   "HLT_DiJetAve300_v4",                                                                    //1291
   "HLT_DiJetAve300_v5",                                                                    //1292
   "HLT_DiJetAve30_v3",                                                                     //1293
   "HLT_DiJetAve30_v4",                                                                     //1294
   "HLT_DiJetAve30_v5",                                                                     //1295
   "HLT_DiJetAve370_v3",                                                                    //1296
   "HLT_DiJetAve370_v4",                                                                    //1297
   "HLT_DiJetAve370_v5",                                                                    //1298
   "HLT_DiJetAve60_v3",                                                                     //1299
   "HLT_DiJetAve60_v4",                                                                     //1300
   "HLT_DiJetAve60_v5",                                                                     //1301
   "HLT_DiJetAve80_v3",                                                                     //1302
   "HLT_DiJetAve80_v4",                                                                     //1303
   "HLT_DiJetAve80_v5",                                                                     //1304
   "HLT_Dimuon0_Jpsi_Muon_v1",                                                              //1305
   "HLT_Dimuon0_Jpsi_Muon_v2",                                                              //1306
   "HLT_Dimuon0_Jpsi_Muon_v3",                                                              //1307
   "HLT_Dimuon0_Jpsi_v1",                                                                   //1308
   "HLT_Dimuon0_Jpsi_v2",                                                                   //1309
   "HLT_Dimuon0_Upsilon_Muon_v1",                                                           //1310
   "HLT_Dimuon0_Upsilon_Muon_v2",                                                           //1311
   "HLT_Dimuon0_Upsilon_Muon_v3",                                                           //1312
   "HLT_Dimuon0_Upsilon_v1",                                                                //1313
   "HLT_Dimuon0_Upsilon_v2",                                                                //1314
   "HLT_Dimuon10_Jpsi_Barrel_v1",                                                           //1315
   "HLT_Dimuon10_Jpsi_Barrel_v2",                                                           //1316
   "HLT_Dimuon4_Bs_Barrel_v2",                                                              //1317
   "HLT_Dimuon4_Bs_Barrel_v3",                                                              //1318
   "HLT_Dimuon4_Bs_Barrel_v4",                                                              //1319
   "HLT_Dimuon5_Upsilon_Barrel_v1",                                                         //1320
   "HLT_Dimuon5_Upsilon_Barrel_v2",                                                         //1321
   "HLT_Dimuon6_Bs_v1",                                                                     //1322
   "HLT_Dimuon6_Bs_v2",                                                                     //1323
   "HLT_Dimuon6_Bs_v3",                                                                     //1324
   "HLT_Dimuon7_Jpsi_Displaced_v1",                                                         //1325
   "HLT_Dimuon7_Jpsi_Displaced_v2",                                                         //1326
   "HLT_Dimuon7_Jpsi_X_Barrel_v1",                                                          //1327
   "HLT_Dimuon7_Jpsi_X_Barrel_v2",                                                          //1328
   "HLT_Dimuon7_LowMass_Displaced_v1",                                                      //1329
   "HLT_Dimuon7_LowMass_Displaced_v2",                                                      //1330
   "HLT_Dimuon7_LowMass_Displaced_v3",                                                      //1331
   "HLT_Dimuon7_PsiPrime_v1",                                                               //1332
   "HLT_Dimuon7_PsiPrime_v2",                                                               //1333
   "HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v4",                                              //1334
   "HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v6",                                              //1335
   "HLT_DoubleEle33_CaloIdL_v1",                                                            //1336
   "HLT_DoubleEle33_CaloIdL_v2",                                                            //1337
   "HLT_DoubleEle33_v1",                                                                    //1338
   "HLT_DoubleEle33_v2",                                                                    //1339
   "HLT_DoubleEle45_CaloIdL_v1",                                                            //1340
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v2",                                               //1341
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v3",                                               //1342
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_v1",                                                     //1343
   "HLT_DoubleEle8_CaloIdL_TrkIdVL_v2",                                                     //1344
   "HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v2",                                               //1345
   "HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v3",                                               //1346
   "HLT_DoubleIsoPFTau25_Trk5_eta2p1_v2",                                                   //1347
   "HLT_DoubleIsoPFTau35_Trk5_eta2p1_v2",                                                   //1348
   "HLT_DoubleIsoPFTau35_Trk5_eta2p1_v3",                                                   //1349
   "HLT_DoubleIsoPFTau40_Trk5_eta2p1_v2",                                                   //1350
   "HLT_DoubleIsoPFTau40_Trk5_eta2p1_v3",                                                   //1351
   "HLT_DoubleJet30_ForwardBackward_v4",                                                    //1352
   "HLT_DoubleJet30_ForwardBackward_v5",                                                    //1353
   "HLT_DoubleJet30_ForwardBackward_v6",                                                    //1354
   "HLT_DoubleJet60_ForwardBackward_v4",                                                    //1355
   "HLT_DoubleJet60_ForwardBackward_v5",                                                    //1356
   "HLT_DoubleJet60_ForwardBackward_v6",                                                    //1357
   "HLT_DoubleJet70_ForwardBackward_v4",                                                    //1358
   "HLT_DoubleJet70_ForwardBackward_v5",                                                    //1359
   "HLT_DoubleJet70_ForwardBackward_v6",                                                    //1360
   "HLT_DoubleJet80_ForwardBackward_v4",                                                    //1361
   "HLT_DoubleJet80_ForwardBackward_v5",                                                    //1362
   "HLT_DoubleJet80_ForwardBackward_v6",                                                    //1363
   "HLT_DoubleMu2_Bs_v3",                                                                   //1364
   "HLT_DoubleMu2_Bs_v4",                                                                   //1365
   "HLT_DoubleMu3_HT150_v2",                                                                //1366
   "HLT_DoubleMu3_HT150_v3",                                                                //1367
   "HLT_DoubleMu3_HT150_v4",                                                                //1368
   "HLT_DoubleMu3_HT200_v5",                                                                //1369
   "HLT_DoubleMu3_HT200_v6",                                                                //1370
   "HLT_DoubleMu3_HT200_v7",                                                                //1371
   "HLT_DoubleMu3_v5",                                                                      //1372
   "HLT_DoubleMu3_v6",                                                                      //1373
   "HLT_DoubleMu45_v1",                                                                     //1374
   "HLT_DoubleMu45_v2",                                                                     //1375
   "HLT_DoubleMu4_Acoplanarity03_v3",                                                       //1376
   "HLT_DoubleMu4_Acoplanarity03_v4",                                                       //1377
   "HLT_DoubleMu4_Acoplanarity03_v5",                                                       //1378
   "HLT_DoubleMu5_Acoplanarity03_v1",                                                       //1379
   "HLT_DoubleMu5_Acoplanarity03_v2",                                                       //1380
   "HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v5",                                                 //1381
   "HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v6",                                                 //1382
   "HLT_DoubleMu5_Ele8_v5",                                                                 //1383
   "HLT_DoubleMu5_Ele8_v6",                                                                 //1384
   "HLT_DoubleMu6_v3",                                                                      //1385
   "HLT_DoubleMu6_v4",                                                                      //1386
   "HLT_DoubleMu7_v3",                                                                      //1387
   "HLT_DoubleMu7_v4",                                                                      //1388
   "HLT_DoublePhoton33_HEVT_v1",                                                            //1389
   "HLT_DoublePhoton33_HEVT_v2",                                                            //1390
   "HLT_DoublePhoton33_v4",                                                                 //1391
   "HLT_DoublePhoton33_v5",                                                                 //1392
   "HLT_DoublePhoton40_MR150_v1",                                                           //1393
   "HLT_DoublePhoton40_MR150_v3",                                                           //1394
   "HLT_DoublePhoton40_R014_MR150_v1",                                                      //1395
   "HLT_DoublePhoton40_R014_MR150_v3",                                                      //1396
   "HLT_DoublePhoton50_v1",                                                                 //1397
   "HLT_DoublePhoton50_v2",                                                                 //1398
   "HLT_DoublePhoton5_IsoVL_CEP_v3",                                                        //1399
   "HLT_DoublePhoton5_IsoVL_CEP_v4",                                                        //1400
   "HLT_DoublePhoton60_v1",                                                                 //1401
   "HLT_DoublePhoton60_v2",                                                                 //1402
   "HLT_EcalCalibration_v2",                                                                //1403
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v1",                            //1404
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v3",                            //1405
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v4",                            //1406
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v1",                            //1407
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v3",                            //1408
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v4",                            //1409
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v1",                            //1410
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v3",                            //1411
   "HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v4",                            //1412
   "HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v1",                            //1413
   "HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v3",                            //1414
   "HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v4",                            //1415
   "HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v4",                                  //1416
   "HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v5",                                  //1417
   "HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT250_v4",                                  //1418
   "HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT250_v5",                                  //1419
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v2",                       //1420
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v4",                       //1421
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v2",                       //1422
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v4",                       //1423
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v6",                         //1424
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v6",                         //1425
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v8",                         //1426
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v4",                                         //1427
   "HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v5",                                         //1428
   "HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v2",                                        //1429
   "HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v4",                                        //1430
   "HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v6",                                          //1431
   "HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau20_v2",                                          //1432
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v5",                                              //1433
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v6",                                              //1434
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFT_v1",                                              //1435
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v4",                                 //1436
   "HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v5",                                 //1437
   "HLT_Ele17_CaloIdL_CaloIsoVL_v4",                                                        //1438
   "HLT_Ele17_CaloIdL_CaloIsoVL_v5",                                                        //1439
   "HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v4", //1440
   "HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v5", //1441
   "HLT_Ele17_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT15_v2",       //1442
   "HLT_Ele17_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT15_v4",       //1443
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_Ele8_Mass30_v2",                           //1444
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_Ele8_Mass30_v3",                           //1445
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v4",                            //1446
   "HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v5",                            //1447
   "HLT_Ele17_CaloIdVT_TrkIdT_CentralJet30_CentralJet25_v1",                                //1448
   "HLT_Ele17_CaloIdVT_TrkIdT_CentralJet30_CentralJet25_v4",                                //1449
   "HLT_Ele18_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v2",                         //1450
   "HLT_Ele25_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1",                                       //1451
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_BTagIP_v1",                     //1452
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT20_v2",       //1453
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT20_v4",       //1454
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_v1",                            //1455
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_DiCentralJet30_v1",                          //1456
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_QuadCentralJet30_v1",                        //1457
   "HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_TriCentralJet30_v1",                         //1458
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v4",                                      //1459
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v5",                                      //1460
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v4",                                             //1461
   "HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v5",                                             //1462
   "HLT_Ele25_CaloIdVT_TrkIdT_DiCentralJet30_v3",                                           //1463
   "HLT_Ele25_CaloIdVT_TrkIdT_DiCentralJet30_v4",                                           //1464
   "HLT_Ele25_CaloIdVT_TrkIdT_QuadCentralJet30_v1",                                         //1465
   "HLT_Ele25_CaloIdVT_TrkIdT_TriCentralJet30_v3",                                          //1466
   "HLT_Ele25_CaloIdVT_TrkIdT_TriCentralJet30_v4",                                          //1467
   "HLT_Ele25_WP80_PFMT40_v1",                                                              //1468
   "HLT_Ele27_WP70_PFMT40_PFMHT20_v1",                                                      //1469
   "HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v1",                                     //1470
   "HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v2",                                     //1471
   "HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v3",                                     //1472
   "HLT_Ele32_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1",                                      //1473
   "HLT_Ele32_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v2",                                      //1474
   "HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3",                                         //1475
   "HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v4",                                         //1476
   "HLT_Ele42_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1",                                      //1477
   "HLT_Ele42_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1",                                         //1478
   "HLT_Ele52_CaloIdVT_TrkIdT_v1",                                                          //1479
   "HLT_Ele52_CaloIdVT_TrkIdT_v2",                                                          //1480
   "HLT_Ele65_CaloIdVT_TrkIdT_v1",                                                          //1481
   "HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v4",                                                   //1482
   "HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v5",                                                   //1483
   "HLT_Ele8_CaloIdL_CaloIsoVL_v4",                                                         //1484
   "HLT_Ele8_CaloIdL_CaloIsoVL_v5",                                                         //1485
   "HLT_Ele8_CaloIdL_TrkIdVL_v4",                                                           //1486
   "HLT_Ele8_CaloIdL_TrkIdVL_v5",                                                           //1487
   "HLT_Ele8_CaloIdT_TrkIdT_DiJet30_v1",                                                    //1488
   "HLT_Ele8_CaloIdT_TrkIdT_DiJet30_v2",                                                    //1489
   "HLT_Ele8_CaloIdT_TrkIdT_QuadJet30_v1",                                                  //1490
   "HLT_Ele8_CaloIdT_TrkIdT_QuadJet30_v2",                                                  //1491
   "HLT_Ele8_CaloIdT_TrkIdT_TriJet30_v1",                                                   //1492
   "HLT_Ele8_CaloIdT_TrkIdT_TriJet30_v2",                                                   //1493
   "HLT_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v3",                                        //1494
   "HLT_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v4",                                        //1495
   "HLT_Ele8_v4",                                                                           //1496
   "HLT_Ele8_v5",                                                                           //1497
   "HLT_ExclDiJet60_HFAND_v3",                                                              //1498
   "HLT_ExclDiJet60_HFAND_v4",                                                              //1499
   "HLT_ExclDiJet60_HFAND_v5",                                                              //1500
   "HLT_ExclDiJet60_HFOR_v3",                                                               //1501
   "HLT_ExclDiJet60_HFOR_v4",                                                               //1502
   "HLT_ExclDiJet60_HFOR_v5",                                                               //1503
   "HLT_GlobalRunHPDNoise_v3",                                                              //1504
   "HLT_HT150_AlphaT0p60_v3",                                                               //1505
   "HLT_HT150_AlphaT0p60_v4",                                                               //1506
   "HLT_HT150_AlphaT0p60_v5",                                                               //1507
   "HLT_HT150_v4",                                                                          //1508
   "HLT_HT150_v5",                                                                          //1509
   "HLT_HT150_v6",                                                                          //1510
   "HLT_HT200_AlphaT0p53_v2",                                                               //1511
   "HLT_HT200_AlphaT0p53_v3",                                                               //1512
   "HLT_HT200_AlphaT0p53_v4",                                                               //1513
   "HLT_HT200_AlphaT0p60_v3",                                                               //1514
   "HLT_HT200_AlphaT0p60_v4",                                                               //1515
   "HLT_HT200_AlphaT0p60_v5",                                                               //1516
   "HLT_HT200_v4",                                                                          //1517
   "HLT_HT200_v5",                                                                          //1518
   "HLT_HT200_v6",                                                                          //1519
   "HLT_HT250_AlphaT0p53_v2",                                                               //1520
   "HLT_HT250_AlphaT0p53_v3",                                                               //1521
   "HLT_HT250_AlphaT0p53_v4",                                                               //1522
   "HLT_HT250_AlphaT0p54_v2",                                                               //1523
   "HLT_HT250_AlphaT0p54_v3",                                                               //1524
   "HLT_HT250_AlphaT0p54_v4",                                                               //1525
   "HLT_HT250_DoubleDisplacedJet60_v3",                                                     //1526
   "HLT_HT250_DoubleDisplacedJet60_v4",                                                     //1527
   "HLT_HT250_DoubleDisplacedJet60_v5",                                                     //1528
   "HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v1",                                            //1529
   "HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v3",                                            //1530
   "HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v4",                                            //1531
   "HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v4",                         //1532
   "HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v5",                         //1533
   "HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v6",                         //1534
   "HLT_HT250_MHT60_v4",                                                                    //1535
   "HLT_HT250_MHT60_v6",                                                                    //1536
   "HLT_HT250_MHT60_v7",                                                                    //1537
   "HLT_HT250_MHT70_v1",                                                                    //1538
   "HLT_HT250_MHT70_v3",                                                                    //1539
   "HLT_HT250_MHT70_v4",                                                                    //1540
   "HLT_HT250_MHT80_v3",                                                                    //1541
   "HLT_HT250_MHT80_v4",                                                                    //1542
   "HLT_HT250_Mu15_PFMHT20_v2",                                                             //1543
   "HLT_HT250_Mu15_PFMHT20_v3",                                                             //1544
   "HLT_HT250_Mu15_PFMHT20_v4",                                                             //1545
   "HLT_HT250_Mu5_PFMHT35_v4",                                                              //1546
   "HLT_HT250_Mu5_PFMHT35_v5",                                                              //1547
   "HLT_HT250_Mu5_PFMHT35_v6",                                                              //1548
   "HLT_HT250_v4",                                                                          //1549
   "HLT_HT250_v5",                                                                          //1550
   "HLT_HT250_v6",                                                                          //1551
   "HLT_HT300_AlphaT0p52_v3",                                                               //1552
   "HLT_HT300_AlphaT0p52_v4",                                                               //1553
   "HLT_HT300_AlphaT0p52_v5",                                                               //1554
   "HLT_HT300_AlphaT0p53_v2",                                                               //1555
   "HLT_HT300_AlphaT0p53_v3",                                                               //1556
   "HLT_HT300_AlphaT0p53_v4",                                                               //1557
   "HLT_HT300_CentralJet30_BTagIP_PFMHT55_v2",                                              //1558
   "HLT_HT300_CentralJet30_BTagIP_PFMHT55_v3",                                              //1559
   "HLT_HT300_CentralJet30_BTagIP_PFMHT55_v4",                                              //1560
   "HLT_HT300_CentralJet30_BTagIP_PFMHT75_v2",                                              //1561
   "HLT_HT300_CentralJet30_BTagIP_PFMHT75_v3",                                              //1562
   "HLT_HT300_CentralJet30_BTagIP_PFMHT75_v4",                                              //1563
   "HLT_HT300_CentralJet30_BTagIP_v2",                                                      //1564
   "HLT_HT300_CentralJet30_BTagIP_v3",                                                      //1565
   "HLT_HT300_CentralJet30_BTagIP_v4",                                                      //1566
   "HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v1",                                            //1567
   "HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v3",                                            //1568
   "HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v4",                                            //1569
   "HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v2",                         //1570
   "HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v3",                         //1571
   "HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v4",                         //1572
   "HLT_HT300_MHT75_v5",                                                                    //1573
   "HLT_HT300_MHT75_v7",                                                                    //1574
   "HLT_HT300_MHT75_v8",                                                                    //1575
   "HLT_HT300_Mu5_PFMHT40_v2",                                                              //1576
   "HLT_HT300_Mu5_PFMHT40_v3",                                                              //1577
   "HLT_HT300_Mu5_PFMHT40_v4",                                                              //1578
   "HLT_HT300_PFMHT55_v2",                                                                  //1579
   "HLT_HT300_PFMHT55_v3",                                                                  //1580
   "HLT_HT300_PFMHT55_v4",                                                                  //1581
   "HLT_HT300_v5",                                                                          //1582
   "HLT_HT300_v6",                                                                          //1583
   "HLT_HT300_v7",                                                                          //1584
   "HLT_HT350_AlphaT0p51_v3",                                                               //1585
   "HLT_HT350_AlphaT0p51_v4",                                                               //1586
   "HLT_HT350_AlphaT0p51_v5",                                                               //1587
   "HLT_HT350_AlphaT0p53_v3",                                                               //1588
   "HLT_HT350_AlphaT0p53_v4",                                                               //1589
   "HLT_HT350_AlphaT0p53_v5",                                                               //1590
   "HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v1",                                            //1591
   "HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v3",                                            //1592
   "HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v4",                                            //1593
   "HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v2",                         //1594
   "HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v3",                         //1595
   "HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v4",                         //1596
   "HLT_HT350_Mu5_PFMHT45_v2",                                                              //1597
   "HLT_HT350_Mu5_PFMHT45_v3",                                                              //1598
   "HLT_HT350_Mu5_PFMHT45_v4",                                                              //1599
   "HLT_HT350_v4",                                                                          //1600
   "HLT_HT350_v5",                                                                          //1601
   "HLT_HT350_v6",                                                                          //1602
   "HLT_HT400_AlphaT0p51_v3",                                                               //1603
   "HLT_HT400_AlphaT0p51_v4",                                                               //1604
   "HLT_HT400_AlphaT0p51_v5",                                                               //1605
   "HLT_HT400_v4",                                                                          //1606
   "HLT_HT400_v5",                                                                          //1607
   "HLT_HT400_v6",                                                                          //1608
   "HLT_HT450_v4",                                                                          //1609
   "HLT_HT450_v5",                                                                          //1610
   "HLT_HT450_v6",                                                                          //1611
   "HLT_HT500_v4",                                                                          //1612
   "HLT_HT500_v5",                                                                          //1613
   "HLT_HT500_v6",                                                                          //1614
   "HLT_HT550_v4",                                                                          //1615
   "HLT_HT550_v5",                                                                          //1616
   "HLT_HT550_v6",                                                                          //1617
   "HLT_HcalCalibration_v2",                                                                //1618
   "HLT_HcalNZS_v4",                                                                        //1619
   "HLT_HcalNZS_v5",                                                                        //1620
   "HLT_HcalNZS_vDEAD",                                                                     //1621
   "HLT_HcalPhiSym_v4",                                                                     //1622
   "HLT_HcalPhiSym_v5",                                                                     //1623
   "HLT_HcalPhiSym_vDEAD",                                                                  //1624
   "HLT_IsoMu12_v4",                                                                        //1625
   "HLT_IsoMu12_v5",                                                                        //1626
   "HLT_IsoMu12_v6",                                                                        //1627
   "HLT_IsoMu15_LooseIsoPFTau15_v2",                                                        //1628
   "HLT_IsoMu15_LooseIsoPFTau15_v4",                                                        //1629
   "HLT_IsoMu15_LooseIsoPFTau15_v5",                                                        //1630
   "HLT_IsoMu15_LooseIsoPFTau20_v2",                                                        //1631
   "HLT_IsoMu15_LooseIsoPFTau20_v3",                                                        //1632
   "HLT_IsoMu15_TightIsoPFTau20_v2",                                                        //1633
   "HLT_IsoMu15_TightIsoPFTau20_v3",                                                        //1634
   "HLT_IsoMu15_v10",                                                                       //1635
   "HLT_IsoMu15_v8",                                                                        //1636
   "HLT_IsoMu15_v9",                                                                        //1637
   "HLT_IsoMu17_CentralJet30_BTagIP_v4",                                                    //1638
   "HLT_IsoMu17_CentralJet30_BTagIP_v5",                                                    //1639
   "HLT_IsoMu17_CentralJet30_BTagIP_v6",                                                    //1640
   "HLT_IsoMu17_CentralJet30_v1",                                                           //1641
   "HLT_IsoMu17_CentralJet30_v2",                                                           //1642
   "HLT_IsoMu17_DiCentralJet30_v1",                                                         //1643
   "HLT_IsoMu17_DiCentralJet30_v2",                                                         //1644
   "HLT_IsoMu17_QuadCentralJet30_v1",                                                       //1645
   "HLT_IsoMu17_QuadCentralJet30_v2",                                                       //1646
   "HLT_IsoMu17_TriCentralJet30_v1",                                                        //1647
   "HLT_IsoMu17_TriCentralJet30_v2",                                                        //1648
   "HLT_IsoMu17_v10",                                                                       //1649
   "HLT_IsoMu17_v8",                                                                        //1650
   "HLT_IsoMu17_v9",                                                                        //1651
   "HLT_IsoMu24_v4",                                                                        //1652
   "HLT_IsoMu24_v5",                                                                        //1653
   "HLT_IsoMu24_v6",                                                                        //1654
   "HLT_IsoMu30_v4",                                                                        //1655
   "HLT_IsoMu30_v5",                                                                        //1656
   "HLT_IsoMu30_v6",                                                                        //1657
   "HLT_IsoPFTau35_Trk20_MET45_v6",                                                         //1658
   "HLT_IsoPFTau35_Trk20_MET60_v2",                                                         //1659
   "HLT_IsoPFTau35_Trk20_MET60_v3",                                                         //1660
   "HLT_IsoPFTau35_Trk20_v2",                                                               //1661
   "HLT_IsoPFTau35_Trk20_v3",                                                               //1662
   "HLT_IsoPFTau45_Trk20_MET60_v2",                                                         //1663
   "HLT_IsoPFTau45_Trk20_MET60_v3",                                                         //1664
   "HLT_IsoTrackHB_v3",                                                                     //1665
   "HLT_IsoTrackHB_v4",                                                                     //1666
   "HLT_IsoTrackHE_v4",                                                                     //1667
   "HLT_IsoTrackHE_v5",                                                                     //1668
   "HLT_Jet110_v3",                                                                         //1669
   "HLT_Jet110_v4",                                                                         //1670
   "HLT_Jet110_v5",                                                                         //1671
   "HLT_Jet150_v3",                                                                         //1672
   "HLT_Jet150_v4",                                                                         //1673
   "HLT_Jet150_v5",                                                                         //1674
   "HLT_Jet190_v3",                                                                         //1675
   "HLT_Jet190_v4",                                                                         //1676
   "HLT_Jet190_v5",                                                                         //1677
   "HLT_Jet240_v3",                                                                         //1678
   "HLT_Jet240_v4",                                                                         //1679
   "HLT_Jet240_v5",                                                                         //1680
   "HLT_Jet300_v2",                                                                         //1681
   "HLT_Jet300_v3",                                                                         //1682
   "HLT_Jet300_v4",                                                                         //1683
   "HLT_Jet30_v3",                                                                          //1684
   "HLT_Jet30_v4",                                                                          //1685
   "HLT_Jet30_v5",                                                                          //1686
   "HLT_Jet370_NoJetID_v3",                                                                 //1687
   "HLT_Jet370_NoJetID_v4",                                                                 //1688
   "HLT_Jet370_NoJetID_v5",                                                                 //1689
   "HLT_Jet370_v3",                                                                         //1690
   "HLT_Jet370_v4",                                                                         //1691
   "HLT_Jet370_v5",                                                                         //1692
   "HLT_Jet60_v3",                                                                          //1693
   "HLT_Jet60_v4",                                                                          //1694
   "HLT_Jet60_v5",                                                                          //1695
   "HLT_Jet80_v3",                                                                          //1696
   "HLT_Jet80_v4",                                                                          //1697
   "HLT_Jet80_v5",                                                                          //1698
   "HLT_JetE30_NoBPTX3BX_NoHalo_v5",                                                        //1699
   "HLT_JetE30_NoBPTX3BX_NoHalo_v6",                                                        //1700
   "HLT_JetE30_NoBPTX_NoHalo_v5",                                                           //1701
   "HLT_JetE30_NoBPTX_NoHalo_v6",                                                           //1702
   "HLT_JetE30_NoBPTX_v3",                                                                  //1703
   "HLT_JetE30_NoBPTX_v4",                                                                  //1704
   "HLT_JetE50_NoBPTX3BX_NoHalo_v1",                                                        //1705
   "HLT_JetE50_NoBPTX3BX_NoHalo_v2",                                                        //1706
   "HLT_L1DoubleJet36Central_v2",                                                           //1707
   "HLT_L1DoubleJet36Central_v3",                                                           //1708
   "HLT_L1DoubleMu0_v2",                                                                    //1709
   "HLT_L1DoubleMu0_v3",                                                                    //1710
   "HLT_L1ETM30_v2",                                                                        //1711
   "HLT_L1ETM30_v3",                                                                        //1712
   "HLT_L1MultiJet_v2",                                                                     //1713
   "HLT_L1MultiJet_v3",                                                                     //1714
   "HLT_L1SingleEG12_v2",                                                                   //1715
   "HLT_L1SingleEG5_v2",                                                                    //1716
   "HLT_L1SingleJet16_v2",                                                                  //1717
   "HLT_L1SingleJet16_v3",                                                                  //1718
   "HLT_L1SingleJet36_v2",                                                                  //1719
   "HLT_L1SingleJet36_v3",                                                                  //1720
   "HLT_L1SingleMu10_v2",                                                                   //1721
   "HLT_L1SingleMu10_v3",                                                                   //1722
   "HLT_L1SingleMu20_v2",                                                                   //1723
   "HLT_L1SingleMu20_v3",                                                                   //1724
   "HLT_L1SingleMuOpen_AntiBPTX_v2",                                                        //1725
   "HLT_L1SingleMuOpen_DT_v2",                                                              //1726
   "HLT_L1SingleMuOpen_DT_v3",                                                              //1727
   "HLT_L1SingleMuOpen_v2",                                                                 //1728
   "HLT_L1SingleMuOpen_v3",                                                                 //1729
   "HLT_L1Tech_BSC_halo_v4",                                                                //1730
   "HLT_L1Tech_BSC_minBias_threshold1_v4",                                                  //1731
   "HLT_L1Tech_HBHEHO_totalOR_v2",                                                          //1732
   "HLT_L1TrackerCosmics_v3",                                                               //1733
   "HLT_L1_Interbunch_BSC_v2",                                                              //1734
   "HLT_L1_PreCollisions_v2",                                                               //1735
   "HLT_L2DoubleMu0_v4",                                                                    //1736
   "HLT_L2DoubleMu0_v5",                                                                    //1737
   "HLT_L2DoubleMu23_NoVertex_v3",                                                          //1738
   "HLT_L2DoubleMu23_NoVertex_v4",                                                          //1739
   "HLT_L2Mu10_v3",                                                                         //1740
   "HLT_L2Mu10_v4",                                                                         //1741
   "HLT_L2Mu20_v3",                                                                         //1742
   "HLT_L2Mu20_v4",                                                                         //1743
   "HLT_L2Mu60_1Hit_MET40_v1",                                                              //1744
   "HLT_L2Mu60_1Hit_MET40_v2",                                                              //1745
   "HLT_L2Mu60_1Hit_MET60_v1",                                                              //1746
   "HLT_L2Mu60_1Hit_MET60_v2",                                                              //1747
   "HLT_L3MuonsCosmicTracking_v3",                                                          //1748
   "HLT_MET100_HBHENoiseFiltered_v2",                                                       //1749
   "HLT_MET100_HBHENoiseFiltered_v3",                                                       //1750
   "HLT_MET100_v4",                                                                         //1751
   "HLT_MET100_v5",                                                                         //1752
   "HLT_MET120_HBHENoiseFiltered_v2",                                                       //1753
   "HLT_MET120_HBHENoiseFiltered_v3",                                                       //1754
   "HLT_MET120_v4",                                                                         //1755
   "HLT_MET120_v5",                                                                         //1756
   "HLT_MET200_HBHENoiseFiltered_v2",                                                       //1757
   "HLT_MET200_HBHENoiseFiltered_v3",                                                       //1758
   "HLT_MET200_v3",                                                                         //1759
   "HLT_MET200_v4",                                                                         //1760
   "HLT_MET200_v5",                                                                         //1761
   "HLT_MET65_HBHENoiseFiltered_v1",                                                        //1762
   "HLT_MET65_HBHENoiseFiltered_v2",                                                        //1763
   "HLT_MET65_v1",                                                                          //1764
   "HLT_MET65_v2",                                                                          //1765
   "HLT_Mu100_v1",                                                                          //1766
   "HLT_Mu100_v2",                                                                          //1767
   "HLT_Mu12_CentralJet30_BTagIP_v2",                                                       //1768
   "HLT_Mu12_CentralJet30_BTagIP_v4",                                                       //1769
   "HLT_Mu12_DiCentralJet30_BTagIP3D_v1",                                                   //1770
   "HLT_Mu12_DiCentralJet30_BTagIP3D_v2",                                                   //1771
   "HLT_Mu12_v3",                                                                           //1772
   "HLT_Mu12_v4",                                                                           //1773
   "HLT_Mu13_Mu8_v2",                                                                       //1774
   "HLT_Mu13_Mu8_v3",                                                                       //1775
   "HLT_Mu15_DoublePhoton15_CaloIdL_v5",                                                    //1776
   "HLT_Mu15_DoublePhoton15_CaloIdL_v6",                                                    //1777
   "HLT_Mu15_HT200_v2",                                                                     //1778
   "HLT_Mu15_HT200_v3",                                                                     //1779
   "HLT_Mu15_HT200_v4",                                                                     //1780
   "HLT_Mu15_LooseIsoPFTau15_v2",                                                           //1781
   "HLT_Mu15_LooseIsoPFTau15_v4",                                                           //1782
   "HLT_Mu15_LooseIsoPFTau15_v5",                                                           //1783
   "HLT_Mu15_Photon20_CaloIdL_v5",                                                          //1784
   "HLT_Mu15_Photon20_CaloIdL_v6",                                                          //1785
   "HLT_Mu15_v4",                                                                           //1786
   "HLT_Mu15_v5",                                                                           //1787
   "HLT_Mu17_CentralJet30_BTagIP_v4",                                                       //1788
   "HLT_Mu17_CentralJet30_BTagIP_v5",                                                       //1789
   "HLT_Mu17_CentralJet30_BTagIP_v6",                                                       //1790
   "HLT_Mu17_CentralJet30_v5",                                                              //1791
   "HLT_Mu17_CentralJet30_v6",                                                              //1792
   "HLT_Mu17_CentralJet30_v7",                                                              //1793
   "HLT_Mu17_DiCentralJet30_v5",                                                            //1794
   "HLT_Mu17_DiCentralJet30_v6",                                                            //1795
   "HLT_Mu17_DiCentralJet30_v7",                                                            //1796
   "HLT_Mu17_Ele8_CaloIdL_v4",                                                              //1797
   "HLT_Mu17_Ele8_CaloIdL_v5",                                                              //1798
   "HLT_Mu17_Mu8_v2",                                                                       //1799
   "HLT_Mu17_Mu8_v3",                                                                       //1800
   "HLT_Mu17_QuadCentralJet30_v1",                                                          //1801
   "HLT_Mu17_QuadCentralJet30_v2",                                                          //1802
   "HLT_Mu17_TriCentralJet30_v5",                                                           //1803
   "HLT_Mu17_TriCentralJet30_v6",                                                           //1804
   "HLT_Mu17_TriCentralJet30_v7",                                                           //1805
   "HLT_Mu20_HT200_v2",                                                                     //1806
   "HLT_Mu20_HT200_v3",                                                                     //1807
   "HLT_Mu20_HT200_v4",                                                                     //1808
   "HLT_Mu20_v3",                                                                           //1809
   "HLT_Mu20_v4",                                                                           //1810
   "HLT_Mu24_v3",                                                                           //1811
   "HLT_Mu24_v4",                                                                           //1812
   "HLT_Mu30_v3",                                                                           //1813
   "HLT_Mu30_v4",                                                                           //1814
   "HLT_Mu3_DiJet30_v1",                                                                    //1815
   "HLT_Mu3_DiJet30_v2",                                                                    //1816
   "HLT_Mu3_DiJet30_v3",                                                                    //1817
   "HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v2",                                                 //1818
   "HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v3",                                                 //1819
   "HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v2",                                                 //1820
   "HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v3",                                                 //1821
   "HLT_Mu3_QuadJet30_v1",                                                                  //1822
   "HLT_Mu3_QuadJet30_v2",                                                                  //1823
   "HLT_Mu3_QuadJet30_v3",                                                                  //1824
   "HLT_Mu3_TriJet30_v1",                                                                   //1825
   "HLT_Mu3_TriJet30_v2",                                                                   //1826
   "HLT_Mu3_TriJet30_v3",                                                                   //1827
   "HLT_Mu3_v5",                                                                            //1828
   "HLT_Mu3_v6",                                                                            //1829
   "HLT_Mu40_v1",                                                                           //1830
   "HLT_Mu40_v2",                                                                           //1831
   "HLT_Mu5_DoubleEle8_CaloIdL_TrkIdVL_v1",                                                 //1832
   "HLT_Mu5_DoubleEle8_CaloIdL_TrkIdVL_v2",                                                 //1833
   "HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v5",                                                  //1834
   "HLT_Mu5_L2Mu2_Jpsi_v4",                                                                 //1835
   "HLT_Mu5_L2Mu2_Jpsi_v5",                                                                 //1836
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v4",                                                  //1837
   "HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v5",                                                  //1838
   "HLT_Mu5_Track2_Jpsi_v4",                                                                //1839
   "HLT_Mu5_Track2_Jpsi_v5",                                                                //1840
   "HLT_Mu5_v5",                                                                            //1841
   "HLT_Mu5_v6",                                                                            //1842
   "HLT_Mu7_Track7_Jpsi_v5",                                                                //1843
   "HLT_Mu7_Track7_Jpsi_v6",                                                                //1844
   "HLT_Mu8_Ele17_CaloIdL_v4",                                                              //1845
   "HLT_Mu8_Ele17_CaloIdL_v5",                                                              //1846
   "HLT_Mu8_Jet40_v5",                                                                      //1847
   "HLT_Mu8_Jet40_v6",                                                                      //1848
   "HLT_Mu8_Photon20_CaloIdVT_IsoT_v4",                                                     //1849
   "HLT_Mu8_Photon20_CaloIdVT_IsoT_v5",                                                     //1850
   "HLT_Mu8_R005_MR200_v1",                                                                 //1851
   "HLT_Mu8_R005_MR200_v3",                                                                 //1852
   "HLT_Mu8_R005_MR200_v4",                                                                 //1853
   "HLT_Mu8_R020_MR200_v1",                                                                 //1854
   "HLT_Mu8_R020_MR200_v3",                                                                 //1855
   "HLT_Mu8_R020_MR200_v4",                                                                 //1856
   "HLT_Mu8_R025_MR200_v1",                                                                 //1857
   "HLT_Mu8_R025_MR200_v3",                                                                 //1858
   "HLT_Mu8_R025_MR200_v4",                                                                 //1859
   "HLT_Mu8_v3",                                                                            //1860
   "HLT_Mu8_v4",                                                                            //1861
   "HLT_PFMHT150_v6",                                                                       //1862
   "HLT_PFMHT150_v7",                                                                       //1863
   "HLT_PFMHT150_v8",                                                                       //1864
   "HLT_Photon125_v1",                                                                      //1865
   "HLT_Photon125_v2",                                                                      //1866
   "HLT_Photon200_NoHE_v1",                                                                 //1867
   "HLT_Photon200_NoHE_v2",                                                                 //1868
   "HLT_Photon20_CaloIdVL_IsoL_v3",                                                         //1869
   "HLT_Photon20_CaloIdVL_IsoL_v4",                                                         //1870
   "HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v4",                                  //1871
   "HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v5",                                  //1872
   "HLT_Photon20_R9Id_Photon18_R9Id_v4",                                                    //1873
   "HLT_Photon20_R9Id_Photon18_R9Id_v5",                                                    //1874
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v4",                                  //1875
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v5",                                  //1876
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v3",                                           //1877
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v4",                                           //1878
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_v4",                                                //1879
   "HLT_Photon26_CaloIdL_IsoVL_Photon18_v5",                                                //1880
   "HLT_Photon26_IsoVL_Photon18_IsoVL_v4",                                                  //1881
   "HLT_Photon26_IsoVL_Photon18_IsoVL_v5",                                                  //1882
   "HLT_Photon26_IsoVL_Photon18_v4",                                                        //1883
   "HLT_Photon26_IsoVL_Photon18_v5",                                                        //1884
   "HLT_Photon26_Photon18_v4",                                                              //1885
   "HLT_Photon26_Photon18_v5",                                                              //1886
   "HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v3",                                           //1887
   "HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v4",                                           //1888
   "HLT_Photon26_R9Id_Photon18_R9Id_v1",                                                    //1889
   "HLT_Photon26_R9Id_Photon18_R9Id_v2",                                                    //1890
   "HLT_Photon30_CaloIdVL_IsoL_v4",                                                         //1891
   "HLT_Photon30_CaloIdVL_IsoL_v5",                                                         //1892
   "HLT_Photon30_CaloIdVL_v4",                                                              //1893
   "HLT_Photon30_CaloIdVL_v5",                                                              //1894
   "HLT_Photon32_CaloIdL_Photon26_CaloIdL_v4",                                              //1895
   "HLT_Photon36_CaloIdL_IsoVL_Photon22_CaloIdL_IsoVL_v1",                                  //1896
   "HLT_Photon36_CaloIdL_IsoVL_Photon22_CaloIdL_v1",                                        //1897
   "HLT_Photon36_CaloIdL_IsoVL_Photon22_v1",                                                //1898
   "HLT_Photon36_CaloIdL_IsoVL_Photon22_v2",                                                //1899
   "HLT_Photon36_CaloIdL_Photon22_CaloIdL_v3",                                              //1900
   "HLT_Photon36_CaloIdL_Photon22_CaloIdL_v4",                                              //1901
   "HLT_Photon36_CaloId_IsoVL_Photon22_R9Id_v1",                                            //1902
   "HLT_Photon36_IsoVL_Photon22_v1",                                                        //1903
   "HLT_Photon36_IsoVL_Photon22_v2",                                                        //1904
   "HLT_Photon36_R9Id_Photon22_CaloIdL_IsoVL_v1",                                           //1905
   "HLT_Photon36_R9Id_Photon22_R9Id_v1",                                                    //1906
   "HLT_Photon40_CaloIdL_Photon28_CaloIdL_v1",                                              //1907
   "HLT_Photon40_CaloIdL_Photon28_CaloIdL_v2",                                              //1908
   "HLT_Photon40_R005_MR150_v1",                                                            //1909
   "HLT_Photon40_R005_MR150_v3",                                                            //1910
   "HLT_Photon40_R014_MR450_v1",                                                            //1911
   "HLT_Photon40_R014_MR450_v3",                                                            //1912
   "HLT_Photon40_R020_MR300_v1",                                                            //1913
   "HLT_Photon40_R020_MR300_v3",                                                            //1914
   "HLT_Photon40_R025_MR200_v1",                                                            //1915
   "HLT_Photon40_R025_MR200_v3",                                                            //1916
   "HLT_Photon40_R038_MR150_v1",                                                            //1917
   "HLT_Photon40_R038_MR150_v3",                                                            //1918
   "HLT_Photon50_CaloIdVL_IsoL_v3",                                                         //1919
   "HLT_Photon50_CaloIdVL_IsoL_v4",                                                         //1920
   "HLT_Photon50_CaloIdVL_v1",                                                              //1921
   "HLT_Photon50_CaloIdVL_v2",                                                              //1922
   "HLT_Photon70_CaloIdL_HT300_v4",                                                         //1923
   "HLT_Photon70_CaloIdL_HT300_v6",                                                         //1924
   "HLT_Photon70_CaloIdL_HT350_v3",                                                         //1925
   "HLT_Photon70_CaloIdL_HT350_v5",                                                         //1926
   "HLT_Photon70_CaloIdL_MHT50_v4",                                                         //1927
   "HLT_Photon70_CaloIdL_MHT50_v6",                                                         //1928
   "HLT_Photon70_CaloIdL_MHT70_v3",                                                         //1929
   "HLT_Photon70_CaloIdL_MHT70_v5",                                                         //1930
   "HLT_Photon75_CaloIdVL_IsoL_v4",                                                         //1931
   "HLT_Photon75_CaloIdVL_IsoL_v5",                                                         //1932
   "HLT_Photon75_CaloIdVL_v4",                                                              //1933
   "HLT_Photon75_CaloIdVL_v5",                                                              //1934
   "HLT_Photon90_CaloIdVL_IsoL_v1",                                                         //1935
   "HLT_Photon90_CaloIdVL_IsoL_v2",                                                         //1936
   "HLT_Photon90_CaloIdVL_v1",                                                              //1937
   "HLT_Photon90_CaloIdVL_v2",                                                              //1938
   "HLT_PixelTracks_Multiplicity100_v3",                                                    //1939
   "HLT_PixelTracks_Multiplicity100_v4",                                                    //1940
   "HLT_PixelTracks_Multiplicity80_v3",                                                     //1941
   "HLT_PixelTracks_Multiplicity80_v4",                                                     //1942
   "HLT_QuadJet40_IsoPFTau40_v5",                                                           //1943
   "HLT_QuadJet40_IsoPFTau40_v7",                                                           //1944
   "HLT_QuadJet40_IsoPFTau40_v8",                                                           //1945
   "HLT_QuadJet40_v4",                                                                      //1946
   "HLT_QuadJet40_v5",                                                                      //1947
   "HLT_QuadJet40_v6",                                                                      //1948
   "HLT_QuadJet45_IsoPFTau45_v2",                                                           //1949
   "HLT_QuadJet45_IsoPFTau45_v3",                                                           //1950
   "HLT_QuadJet50_BTagIP_v4",                                                               //1951
   "HLT_QuadJet50_Jet40_Jet30_v1",                                                          //1952
   "HLT_QuadJet50_Jet40_Jet30_v2",                                                          //1953
   "HLT_QuadJet50_Jet40_v3",                                                                //1954
   "HLT_QuadJet60_v3",                                                                      //1955
   "HLT_QuadJet60_v4",                                                                      //1956
   "HLT_QuadJet60_v5",                                                                      //1957
   "HLT_QuadJet70_v3",                                                                      //1958
   "HLT_QuadJet70_v4",                                                                      //1959
   "HLT_QuadJet70_v5",                                                                      //1960
   "HLT_R014_MR150_CentralJet40_BTagIP_v2",                                                 //1961
   "HLT_R014_MR150_CentralJet40_BTagIP_v4",                                                 //1962
   "HLT_R014_MR150_CentralJet40_BTagIP_v5",                                                 //1963
   "HLT_R014_MR150_v1",                                                                     //1964
   "HLT_R014_MR150_v3",                                                                     //1965
   "HLT_R014_MR150_v4",                                                                     //1966
   "HLT_R014_MR450_CentralJet40_BTagIP_v2",                                                 //1967
   "HLT_R014_MR450_CentralJet40_BTagIP_v4",                                                 //1968
   "HLT_R014_MR450_CentralJet40_BTagIP_v5",                                                 //1969
   "HLT_R020_MR150_v1",                                                                     //1970
   "HLT_R020_MR150_v3",                                                                     //1971
   "HLT_R020_MR150_v4",                                                                     //1972
   "HLT_R020_MR350_CentralJet40_BTagIP_v2",                                                 //1973
   "HLT_R020_MR350_CentralJet40_BTagIP_v4",                                                 //1974
   "HLT_R020_MR350_CentralJet40_BTagIP_v5",                                                 //1975
   "HLT_R020_MR500_v1",                                                                     //1976
   "HLT_R020_MR500_v3",                                                                     //1977
   "HLT_R020_MR500_v4",                                                                     //1978
   "HLT_R020_MR550_v1",                                                                     //1979
   "HLT_R020_MR550_v3",                                                                     //1980
   "HLT_R020_MR550_v4",                                                                     //1981
   "HLT_R025_MR150_v1",                                                                     //1982
   "HLT_R025_MR150_v3",                                                                     //1983
   "HLT_R025_MR150_v4",                                                                     //1984
   "HLT_R025_MR250_CentralJet40_BTagIP_v2",                                                 //1985
   "HLT_R025_MR250_CentralJet40_BTagIP_v4",                                                 //1986
   "HLT_R025_MR250_CentralJet40_BTagIP_v5",                                                 //1987
   "HLT_R025_MR400_v1",                                                                     //1988
   "HLT_R025_MR400_v3",                                                                     //1989
   "HLT_R025_MR400_v4",                                                                     //1990
   "HLT_R025_MR450_v1",                                                                     //1991
   "HLT_R025_MR450_v3",                                                                     //1992
   "HLT_R025_MR450_v4",                                                                     //1993
   "HLT_R033_MR300_v1",                                                                     //1994
   "HLT_R033_MR300_v3",                                                                     //1995
   "HLT_R033_MR300_v4",                                                                     //1996
   "HLT_R033_MR350_v1",                                                                     //1997
   "HLT_R033_MR350_v3",                                                                     //1998
   "HLT_R033_MR350_v4",                                                                     //1999
   "HLT_R038_MR200_v1",                                                                     //2000
   "HLT_R038_MR200_v3",                                                                     //2001
   "HLT_R038_MR200_v4",                                                                     //2002
   "HLT_R038_MR250_v1",                                                                     //2003
   "HLT_R038_MR250_v3",                                                                     //2004
   "HLT_R038_MR250_v4",                                                                     //2005
   "HLT_RegionalCosmicTracking_v3",                                                         //2006
   "HLT_RegionalCosmicTracking_v4",                                                         //2007
   "HLT_TrackerCalibration_v2",                                                             //2008
   "HLT_TripleEle10_CaloIdL_TrkIdVL_v4",                                                    //2009
   "HLT_TripleEle10_CaloIdL_TrkIdVL_v6",                                                    //2010
   "HLT_TripleMu5_v4",                                                                      //2011
   "HLT_TripleMu5_v5",                                                                      //2012
   "HLT_ZeroBias_v3"                                                                       //2013
};

enum TriggerBitNumber{
   generation_step,
   simulation_step,
   digitisation_step,
   L1simulation_step,
   digi2raw_step,
   HLTriggerFirstPath,
   HLT_L1Jet15,
   HLT_Jet30,
   HLT_Jet50,
   HLT_Jet80,
   HLT_Jet110,
   HLT_Jet140,
   HLT_Jet180,
   HLT_FwdJet40,
   HLT_DiJetAve15U_1E31,
   HLT_DiJetAve30U_1E31,
   HLT_DiJetAve50U,
   HLT_DiJetAve70U,
   HLT_DiJetAve130U,
   HLT_QuadJet30,
   HLT_SumET120,
   HLT_L1MET20,
   HLT_MET35,
   HLT_MET60,
   HLT_MET100,
   HLT_HT200,
   HLT_HT300_MHT100,
   HLT_L1MuOpen,
   HLT_L1Mu,
   HLT_L1Mu20HQ,
   HLT_L1Mu30,
   HLT_L2Mu11,
   HLT_IsoMu9,
   HLT_Mu5,
   HLT_Mu9,
   HLT_Mu11,
   HLT_Mu15,
   HLT_L1DoubleMuOpen,
   HLT_DoubleMu0,
   HLT_DoubleMu3,
   HLT_L1SingleEG5,
   HLT_Ele10_SW_L1R,
   HLT_Ele15_SW_L1R,
   HLT_Ele15_SW_EleId_L1R,
   HLT_Ele15_SW_LooseTrackIso_L1R,
   HLT_Ele15_SiStrip_L1R,
   HLT_Ele15_SC15_SW_LooseTrackIso_L1R,
   HLT_Ele15_SC15_SW_EleId_L1R,
   HLT_Ele20_SW_L1R,
   HLT_Ele20_SiStrip_L1R,
   HLT_Ele20_SC15_SW_L1R,
   HLT_Ele25_SW_L1R,
   HLT_Ele25_SW_EleId_LooseTrackIso_L1R,
   HLT_DoubleEle5_SW_Jpsi_L1R,
   HLT_DoubleEle5_SW_Upsilon_L1R,
   HLT_DoubleEle10_SW_L1R,
   HLT_Photon10_L1R,
   HLT_Photon10_LooseEcalIso_TrackIso_L1R,
   HLT_Photon15_L1R,
   HLT_Photon20_LooseEcalIso_TrackIso_L1R,
   HLT_Photon25_L1R,
   HLT_Photon25_LooseEcalIso_TrackIso_L1R,
   HLT_Photon30_L1R_1E31,
   HLT_Photon70_L1R,
   HLT_DoublePhoton10_L1R,
   HLT_DoublePhoton15_L1R,
   HLT_DoublePhoton15_VeryLooseEcalIso_L1R,
   HLT_SingleIsoTau30_Trk5,
   HLT_DoubleLooseIsoTau15_Trk5,
   HLT_BTagIP_Jet80,
   HLT_BTagMu_Jet20,
   HLT_BTagIP_Jet120,
   HLT_StoppedHSCP_1E31,
   HLT_L1Mu14_L1SingleEG10,
   HLT_L1Mu14_L1SingleJet15,
   HLT_L1Mu14_L1ETM40,
   HLT_Ele10_LW_L1R_HT200,
   HLT_L2Mu5_Photon9_L1R,
   HLT_L2Mu9_DiJet30,
   HLT_L2Mu8_HT50,
   HLT_Ele10_SW_L1R_TripleJet30,
   HLT_Ele10_LW_L1R_HT180,
   HLT_ZeroBias,
   HLT_MinBiasHcal,
   HLT_MinBiasEcal,
   HLT_MinBiasPixel,
   HLT_MinBiasPixel_Trk5,
   HLT_CSCBeamHalo,
   HLT_CSCBeamHaloOverlapRing1,
   HLT_CSCBeamHaloOverlapRing2,
   HLT_CSCBeamHaloRing2or3,
   HLT_BackwardBSC,
   HLT_ForwardBSC,
   HLT_TrackerCosmics,
   HLT_IsoTrack_1E31,
   AlCa_HcalPhiSym,
   AlCa_EcalPhiSym,
   AlCa_EcalPi0_1E31,
   AlCa_EcalEta_1E31,
   AlCa_RPCMuonNoHits,
   AlCa_RPCMuonNormalisation,
   HLTriggerFinalPath,
   endjob_step,
   HLT_HT240,
   HLT_Mu0_L1MuOpen,
   HLT_Mu3_L1MuOpen,
   HLT_Mu5_L1MuOpen,
   HLT_Mu0_Track0_Jpsi,
   HLT_Mu3_Track0_Jpsi,
   HLT_Mu5_Track0_Jpsi,
   HLT_Ele20_SW_EleId_LooseTrackIso_L1R,
   HLT_L1Mu14_L1SingleJet20,
   HLT_L2Mu7_Photon9_L1R,
   HLT_ZeroBiasPixel_SingleTrack,
   HLT_HighMultiplicityBSC,
   HLT_RPCBarrelCosmics,
   HLT_IsoTrackHE_1E31,
   HLT_IsoTrackHB_1E31,
   HLT_HcalPhiSym,
   HLT_HcalNZS_1E31,
   AlCa_RPCMuonNoTriggers,
   HLT_HighMult40,
   HLT_Activity_L1A,
   HLT_Activity_PixelClusters,
   HLT_Activity_DT,
   HLT_Activity_DT_Tuned,
   HLT_Activity_Ecal,
   HLT_Activity_EcalREM,
   HLT_SelectEcalSpikes_L1R,
   HLT_SelectEcalSpikesHighEt_L1R,
   HLT_L1Jet6U,
   HLT_L1Jet6U_NoBPTX,
   HLT_L1Jet10U,
   HLT_L1Jet10U_NoBPTX,
   HLT_Jet15U,
   HLT_Jet30U,
   HLT_Jet50U,
   HLT_L1SingleForJet,
   HLT_L1SingleForJet_NoBPTX,
   HLT_L1SingleCenJet,
   HLT_L1SingleCenJet_NoBPTX,
   HLT_L1SingleTauJet,
   HLT_L1SingleTauJet_NoBPTX,
   HLT_FwdJet20U,
   HLT_DiJetAve15U_8E29,
   HLT_DiJetAve30U_8E29,
   HLT_DoubleJet15U_ForwardBackward,
   HLT_QuadJet15U,
   HLT_MET45,
   HLT_HT100U,
   HLT_L1MuOpen_NoBPTX,
   HLT_L1MuOpen_AntiBPTX,
   HLT_L1Mu20,
   HLT_L2Mu0,
   HLT_L2Mu3,
   HLT_L2Mu5,
   HLT_L2Mu9,
   HLT_L2DoubleMu0,
   HLT_IsoMu3,
   HLT_Mu3,
   HLT_Mu0_L2Mu0,
   HLT_Mu3_L2Mu0,
   HLT_Mu5_L2Mu0,
   HLT_L1SingleEG2,
   HLT_L1SingleEG2_NoBPTX,
   HLT_L1SingleEG5_NoBPTX,
   HLT_L1SingleEG8,
   HLT_L1DoubleEG5,
   HLT_EgammaSuperClusterOnly_L1R,
   HLT_Ele10_LW_L1R,
   HLT_Ele10_LW_EleId_L1R,
   HLT_Ele15_LW_L1R,
   HLT_Ele15_SC10_LW_L1R,
   HLT_Ele20_LW_L1R,
   HLT_DoubleEle5_SW_L1R,
   HLT_Photon15_TrackIso_L1R,
   HLT_Photon15_LooseEcalIso_L1R,
   HLT_Photon20_L1R,
   HLT_Photon30_L1R_8E29,
   HLT_DoublePhoton4_eeRes_L1R,
   HLT_DoublePhoton4_Jpsi_L1R,
   HLT_DoublePhoton4_Upsilon_L1R,
   HLT_DoublePhoton5_Jpsi_L1R,
   HLT_DoublePhoton5_Upsilon_L1R,
   HLT_DoublePhoton5_L1R,
   HLT_SingleLooseIsoTau20,
   HLT_DoubleLooseIsoTau15,
   HLT_BTagIP_Jet50U,
   HLT_BTagMu_Jet10U,
   HLT_StoppedHSCP_8E29,
   HLT_L1Mu14_L1SingleJet6U,
   HLT_L1Mu14_L1ETM30,
   HLT_MinBiasBSC,
   HLT_MinBiasBSC_NoBPTX,
   HLT_MinBiasBSC_OR,
   HLT_MinBiasPixel_SingleTrack,
   HLT_MinBiasPixel_DoubleTrack,
   HLT_MinBiasPixel_DoubleIsoTrack5,
   HLT_SplashBSC,
   HLT_L1_BscMinBiasOR_BptxPlusORMinus,
   HLT_L1_BscMinBiasOR_BptxPlusORMinus_NoBPTX,
   HLT_L1_BscMinBiasOR_BeamGas,
   HLT_L1Tech_BSC_halo,
   HLT_L1Tech_BSC_halo_forPhysicsBackground,
   HLT_L1Tech_RPC_TTU_RBst1_collisions,
   HLT_IsoTrackHE_8E29,
   HLT_IsoTrackHB_8E29,
   HLT_HcalNZS_8E29,
   AlCa_EcalPi0_8E29,
   AlCa_EcalEta_8E29,
   HLT_DTErrors,
   HLT_Calibration,
   HLT_EcalCalibration,
   HLT_HcalCalibration,
   HLT_Random,
   HLT_L1_HFtech,
   HLT_L1Tech_HCAL_HF_coincidence_PM,
   HLT_GlobalRunHPDNoise,
   HLT_TechTrigHCALNoise,
   HLT_L1_BPTX,
   HLT_L1_BPTX_MinusOnly,
   HLT_L1_BPTX_PlusOnly,
   HLT_L2Mu0_NoVertex,
   HLT_TkMu3_NoVertex,
   HLT_LogMonitor,
   DQM_FEDIntegrity,
   AlCa_EcalEta,
   AlCa_EcalPi0,
   DQM_TriggerResults,
   HLT_Activity_CSC,
   HLT_DiJetAve15U,
   HLT_DiJetAve30U,
   HLT_DoubleEle4_SW_eeRes_L1R,
   HLT_DoubleIsoTau15_OneLeg_Trk5,
   HLT_DoubleIsoTau15_Trk5,
   HLT_DoubleJet25U_ForwardBackward,
   HLT_DoublePhoton17_L1R,
   HLT_DoublePhoton5_CEP_L1R,
   HLT_EcalOnly_SumEt160,
   HLT_Ele12_SW_TightEleIdIsol_L1R,
   HLT_Ele12_SW_TightEleIdIsol_NoDEtaInEE_L1R,
   HLT_Ele12_SW_TightEleId_L1R,
   HLT_Ele17_SW_CaloEleId_L1R,
   HLT_Ele17_SW_EleId_L1R,
   HLT_Ele17_SW_L1R,
   HLT_Ele17_SW_LooseEleId_L1R,
   HLT_Ele22_SW_CaloEleId_L1R,
   HLT_Ele40_SW_L1R,
   HLT_HT120U,
   HLT_HT140U,
   HLT_HcalNZS,
   HLT_IsoTrackHB,
   HLT_IsoTrackHE,
   HLT_Jet100U,
   HLT_Jet70U,
   HLT_L1ETT100,
   HLT_L1Tech_BSC_HighMultiplicity,
   HLT_L1Tech_BSC_minBias,
   HLT_L1Tech_BSC_minBias_OR,
   HLT_L1Tech_HCAL_HF,
   HLT_L1_BptxXOR_BscMinBiasOR,
   HLT_L2Mu25,
   HLT_MET65,
   HLT_Mu0_TkMu0_OST_Jpsi,
   HLT_Mu20_NoVertex,
   HLT_Mu7,
   HLT_MultiVertex6,
   HLT_MultiVertex8_L1ETT60,
   HLT_Photon10_Cleaned_L1R,
   HLT_Photon15_Cleaned_L1R,
   HLT_Photon20_Cleaned_L1R,
   HLT_Photon20_NoHE_L1R,
   HLT_Photon30_Cleaned_L1R,
   HLT_Photon50_NoHE_Cleaned_L1R,
   HLT_Photon50_NoHE_L1R,
   HLT_PixelTracks_Multiplicity100,
   HLT_PixelTracks_Multiplicity70,
   HLT_PixelTracks_Multiplicity85,
   HLT_QuadJet20U,
   HLT_QuadJet25U,
   HLT_SingleIsoTau20_Trk15_MET20,
   HLT_SingleIsoTau20_Trk5_MET20,
   HLT_StoppedHSCP,
   HLT_Activity_Ecal_SC17,
   HLT_Activity_Ecal_SC7,
   HLT_BTagMu_DiJet10U_v1,
   HLT_BTagMu_DiJet20U_Mu5_v1,
   HLT_BTagMu_DiJet20U_v1,
   HLT_BTagMu_Jet20U,
   HLT_DiJetAve100U_v1,
   HLT_DiJetAve70U_v2,
   HLT_DoubleEle15_SW_L1R,
   HLT_DoubleEle17_SW_L1R,
   HLT_DoubleMu0_Quarkonium_v1,
   HLT_DoubleMu3_v2,
   HLT_DoubleMu5_v1,
   HLT_DoublePhoton17SingleIsol_L1R_v1,
   HLT_DoublePhoton22_L1R_v1,
   HLT_EcalOnly_SumEt160_v2,
   HLT_Ele12_SW_TighterEleIdIsol_L1R,
   HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R,
   HLT_Ele17_SW_TightCaloEleId_SC8HE_L1R,
   HLT_Ele17_SW_TightEleIdIsol_L1R,
   HLT_Ele17_SW_TightEleId_L1R,
   HLT_Ele17_SW_TighterEleIdIsol_L1R,
   HLT_Ele17_SW_TighterEleIdIsol_L1R_v2,
   HLT_Ele17_SW_TighterEleId_L1R,
   HLT_Ele22_SW_TighterCaloIdIsol_L1R_v1,
   HLT_Ele22_SW_TighterEleId_L1R_v2,
   HLT_Ele27_SW_TightCaloEleIdTrack_L1R,
   HLT_Ele32_SW_TightCaloEleIdTrack_L1R,
   HLT_Ele32_SW_TighterEleId_L1R,
   HLT_ExclDiJet30U_HFAND_v1,
   HLT_ExclDiJet30U_HFOR_v1,
   HLT_HT160U_v1,
   HLT_HT200U_v1,
   HLT_HT50U_v1,
   HLT_IsoEle12_PFTau15_v1,
   HLT_IsoMu11_v1,
   HLT_IsoTrackHB_v2,
   HLT_IsoTrackHE_v2,
   HLT_Jet100U_v2,
   HLT_Jet140U_v1,
   HLT_Jet15U_HcalNoiseFiltered,
   HLT_Jet70U_v2,
   HLT_L1Mu7_v1,
   HLT_L1MuOpen_DT,
   HLT_L2DoubleMu20_NoVertex_v1,
   HLT_L2Mu30_v1,
   HLT_L2Mu7_v1,
   HLT_MET100_v2,
   HLT_Mu0_TkMu0_OST_Jpsi_Seagull,
   HLT_Mu0_TkMu0_OST_Jpsi_Tight,
   HLT_Mu13_v1,
   HLT_Mu15_v1,
   HLT_Mu3_TkMu0_OST_Jpsi,
   HLT_Mu3_TkMu0_OST_Jpsi_Tight,
   HLT_Mu3_Track3_Jpsi,
   HLT_Mu5_Ele5_v1,
   HLT_Mu5_HT70U_v1,
   HLT_Mu5_Jet50U_v1,
   HLT_Mu5_MET45_v1,
   HLT_Mu5_Photon9_Cleaned_L1R,
   HLT_Mu5_TkMu0_OST_Jpsi,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight,
   HLT_Photon100_NoHE_Cleaned_L1R,
   HLT_Photon110_NoHE_Cleaned_L1R,
   HLT_Photon17Isol_SC17HE_L1R,
   HLT_Photon17_SC17HE_L1R,
   HLT_Photon22_SC22HE_L1R,
   HLT_Photon30_Isol_EBOnly_Cleaned_L1R,
   HLT_Photon35_Isol_Cleaned_L1R,
   HLT_Photon40CaloId_Cleaned_L1R,
   HLT_Photon40Isol_Cleaned_L1R,
   HLT_Photon50_Cleaned_L1R,
   HLT_Photon70_Cleaned_L1R,
   HLT_Photon70_L1R_v1,
   HLT_Photon70_NoHE_Cleaned_L1R,
   HLT_QuadJet15U_v2,
   HLT_QuadJet20U_v2,
   HLT_QuadJet25U_v2,
   HLT_SingleIsoTau30_Trk5_L120or30,
   HLT_SingleIsoTau30_Trk5_MET20,
   HLT_SingleIsoTau30_Trk5_v2,
   HLT_StoppedHSCP_v2,
   OpenHLT_BTagMu_DiJet10U,
   OpenHLT_BTagMu_DiJet20U,
   OpenHLT_BTagMu_DiJet20U_Mu5,
   OpenHLT_BTagMu_DiJet30U,
   OpenHLT_BTagMu_DiJet30U_Mu5,
   OpenHLT_DiJetAve100U,
   OpenHLT_DiJetAve140,
   OpenHLT_DoubleJet25U_ForwardBackward,
   OpenHLT_DoubleJet35U_ForwardBackward,
   OpenHLT_DoubleMu0_Quarkonium,
   OpenHLT_DoubleMu0_Quarkonium_LS,
   OpenHLT_DoubleMu3_HT50U,
   OpenHLT_DoubleMu5,
   OpenHLT_Ele10_EleId_HT70U,
   OpenHLT_Ele10_HT100U,
   OpenHLT_Ele10_HT70U,
   OpenHLT_Ele10_MET45,
   OpenHLT_ExclDiJet30U,
   OpenHLT_ExclDiJet30U_HFOR,
   OpenHLT_HT120U,
   OpenHLT_HT130U,
   OpenHLT_HT140U_JT20_Eta3,
   OpenHLT_HT140_Eta3_J30,
   OpenHLT_HT150U,
   OpenHLT_HT150U_Eta3,
   OpenHLT_HT160U_Eta3,
   OpenHLT_HT160U_JT20,
   OpenHLT_HT200U_JT20,
   OpenHLT_HT50U,
   OpenHLT_IsoMu11,
   OpenHLT_IsoMu13,
   OpenHLT_IsoMu15,
   OpenHLT_IsoMu17,
   OpenHLT_Jet140U,
   OpenHLT_Jet180U,
   OpenHLT_L1Mu7,
   OpenHLT_L2DoubleMu20,
   OpenHLT_L2Mu30,
   OpenHLT_L2Mu7,
   OpenHLT_MET120,
   OpenHLT_MET45_HT100U,
   OpenHLT_MET65,
   OpenHLT_MET65_CenJet50U,
   OpenHLT_MET80,
   OpenHLT_MET80_CenJet50U,
   OpenHLT_Meff180U,
   OpenHLT_Mu0_v1,
   OpenHLT_Mu11_Ele8,
   OpenHLT_Mu13,
   OpenHLT_Mu15,
   OpenHLT_Mu17,
   OpenHLT_Mu19,
   OpenHLT_Mu25,
   OpenHLT_Mu30_NoVertex,
   OpenHLT_Mu3_Track5_Jpsi,
   OpenHLT_Mu5_Ele13,
   OpenHLT_Mu5_Ele15,
   OpenHLT_Mu5_Ele5,
   OpenHLT_Mu5_Ele9,
   OpenHLT_Mu5_HT100U,
   OpenHLT_Mu5_HT50,
   OpenHLT_Mu5_Jet35U,
   OpenHLT_Mu5_Jet70U,
   OpenHLT_Mu5_MET45,
   OpenHLT_Mu5_Photon11_L1R,
   OpenHLT_Mu7_Ele9,
   OpenHLT_Mu7_Photon13_L1R,
   OpenHLT_Mu8_Ele8,
   OpenHLT_PT12U_50,
   OpenHLT_SingleIsoTau20_Trk15_MET25,
   OpenHLT_SingleIsoTau30_Trk5_MET20,
   OpenHLT_SingleIsoTau35_Trk15_MET25,
   DQM_FEDIntegrity_v2,
   HLT_Activity_Ecal_SC15,
   HLT_BTagMu_DiJet10U_v3,
   HLT_BTagMu_DiJet20U_Mu5_v3,
   HLT_BTagMu_DiJet20U_v3,
   HLT_BTagMu_DiJet30U_Mu5_v3,
   HLT_BTagMu_DiJet30U_v3,
   HLT_DiJet20U_Meff180U_v3,
   HLT_DiJet50U_PT50U_v3,
   HLT_DiJetAve100U_v3,
   HLT_DiJetAve140U_v3,
   HLT_DiJetAve15U_v3,
   HLT_DiJetAve30U_v3,
   HLT_DiJetAve50U_8E29,
   HLT_DiJetAve50U_v3,
   HLT_DiJetAve70U_v3,
   HLT_DoubleEle15_SW_L1R_v1,
   HLT_DoubleEle17_SW_L1R_v1,
   HLT_DoubleEle5_SW_Upsilon_L1R_v1,
   HLT_DoubleEle8_SW_HT70U_L1R_v1,
   HLT_DoubleIsoTau15_OneLeg_Trk5_v3,
   HLT_DoubleIsoTau15_Trk5_v3,
   HLT_DoubleJet15U_ForwardBackward_v3,
   HLT_DoubleJet25U_ForwardBackward_v3,
   HLT_DoubleJet35U_ForwardBackward_v3,
   HLT_DoubleMu0_Quarkonium_LS_v1,
   HLT_DoubleMu3_HT50U_v3,
   HLT_DoublePhoton17_SingleIsol_L1R_v1,
   HLT_DoublePhoton20_L1R,
   HLT_DoublePhoton5_CEP_L1R_v3,
   HLT_DoublePhoton5_eeRes_L1R,
   HLT_EcalOnly_SumEt160_v3,
   HLT_Ele10_MET45_v1,
   HLT_Ele10_SW_EleId_HT70U_L1R_v1,
   HLT_Ele10_SW_EleId_L1R,
   HLT_Ele10_SW_HT100U_L1R_v1,
   HLT_Ele10_SW_HT70U_L1R_v1,
   HLT_Ele12_SW_TighterEleIdIsol_L1R_v1,
   HLT_Ele12_SW_TighterEleId_L1R_v1,
   HLT_Ele15_SW_CaloEleId_L1R,
   HLT_Ele17_SW_Isol_L1R_v1,
   HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R_v1,
   HLT_Ele17_SW_TightCaloEleId_SC8HE_L1R_v1,
   HLT_Ele17_SW_TightEleIdIsol_L1R_v1,
   HLT_Ele17_SW_TighterEleIdIsol_L1R_v1,
   HLT_Ele17_SW_TighterEleId_L1R_v1,
   HLT_Ele22_SW_L1R_v1,
   HLT_Ele27_SW_TightCaloEleIdTrack_L1R_v1,
   HLT_Ele32_SW_TightCaloEleIdTrack_L1R_v1,
   HLT_Ele32_SW_TighterEleId_L1R_v2,
   HLT_ExclDiJet30U_HFAND_v3,
   HLT_ExclDiJet30U_HFOR_v3,
   HLT_HFThreshold10,
   HLT_HFThreshold3,
   HLT_HT100U_v3,
   HLT_HT130U_v3,
   HLT_HT140U_Eta3_v1,
   HLT_HT140U_J30U_Eta3_v3,
   HLT_HT150U_Eta3_v3,
   HLT_HT150U_v3,
   HLT_HT160U_Eta3_v3,
   HLT_HT160U_v3,
   HLT_HT200U_v3,
   HLT_HT50U_v3,
   HLT_IsoMu11_v3,
   HLT_IsoMu13_v3,
   HLT_IsoMu15_v3,
   HLT_IsoMu17_v3,
   HLT_IsoMu9_PFTau15_v1,
   HLT_IsoMu9_v3,
   HLT_IsoTrackHE_v3,
   HLT_Jet100U_v3,
   HLT_Jet140U_v3,
   HLT_Jet15U_HcalNoiseFiltered_v3,
   HLT_Jet15U_v3,
   HLT_Jet180U_v3,
   HLT_Jet30U_v3,
   HLT_Jet50U_v3,
   HLT_Jet70U_v3,
   HLT_L1DoubleMuOpen_Tight,
   HLT_L1ETT140_v1,
   HLT_L1MuOpen_AntiBPTX_v2,
   HLT_L1MuOpen_DT_v2,
   HLT_L1MuOpen_v2,
   HLT_L1SingleEG1,
   HLT_L1SingleEG1_NoBPTX,
   HLT_L1SingleEG20_NoBPTX,
   HLT_L1_BSC,
   HLT_L2Mu15,
   HLT_MET100_v3,
   HLT_MET120_v3,
   HLT_MET45_DiJet30U_v3,
   HLT_MET45_HT100U_v1,
   HLT_MET45_HT120U_v1,
   HLT_MET45_v3,
   HLT_MET65_CenJet50U_v3,
   HLT_MET80_CenJet50U_v3,
   HLT_MET80_v1,
   HLT_MinBias,
   HLT_Mu0_TkMu0_Jpsi,
   HLT_Mu0_TkMu0_Jpsi_NoCharge,
   HLT_Mu0_TkMu0_OST_Jpsi_Tight_v1,
   HLT_Mu0_TkMu0_OST_Jpsi_Tight_v2,
   HLT_Mu0_v2,
   HLT_Mu11_Ele8_v1,
   HLT_Mu11_PFTau15_v1,
   HLT_Mu17_v1,
   HLT_Mu19_v1,
   HLT_Mu21_v1,
   HLT_Mu25_v1,
   HLT_Mu30_NoVertex_v1,
   HLT_Mu3_Ele8_HT70U_v1,
   HLT_Mu3_TkMu0_Jpsi,
   HLT_Mu3_TkMu0_Jpsi_NoCharge,
   HLT_Mu3_TkMu0_OST_Jpsi_Tight_v2,
   HLT_Mu3_Track3_Jpsi_v2,
   HLT_Mu3_Track5_Jpsi_v1,
   HLT_Mu3_Track5_Jpsi_v2,
   HLT_Mu3_v2,
   HLT_Mu5_Ele13_v2,
   HLT_Mu5_Ele17_v1,
   HLT_Mu5_Ele9_v1,
   HLT_Mu5_HT100U_v3,
   HLT_Mu5_HT50U_v1,
   HLT_Mu5_HT70U_v3,
   HLT_Mu5_Jet35U_v1,
   HLT_Mu5_Jet50U_v2,
   HLT_Mu5_Jet50U_v3,
   HLT_Mu5_Jet70U_v3,
   HLT_Mu5_MET45_v3,
   HLT_Mu5_Photon11_Cleaned_L1R_v1,
   HLT_Mu5_TkMu0_Jpsi,
   HLT_Mu5_TkMu0_Jpsi_NoCharge,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_v1,
   HLT_Mu7_Photon13_Cleaned_L1R_v1,
   HLT_Mu8_Ele8_v1,
   HLT_Photon100_NoHE_Cleaned_L1R_v1,
   HLT_Photon110_NoHE_Cleaned_L1R_v1,
   HLT_Photon15_LooseEcalIso_Cleaned_L1R,
   HLT_Photon15_TrackIso_Cleaned_L1R,
   HLT_Photon17_Isol_SC17HE_L1R_v1,
   HLT_Photon17_SC17HE_L1R_v1,
   HLT_Photon20_Isol_Cleaned_L1R_v1,
   HLT_Photon22_SC22HE_L1R_v1,
   HLT_Photon25_Cleaned_L1R,
   HLT_Photon30_Isol_EBOnly_Cleaned_L1R_v1,
   HLT_Photon30_L1R,
   HLT_Photon35_Isol_Cleaned_L1R_v1,
   HLT_Photon40_CaloId_Cleaned_L1R_v1,
   HLT_Photon40_Isol_Cleaned_L1R_v1,
   HLT_Photon50_Cleaned_L1R_v1,
   HLT_Photon50_L1R,
   HLT_Photon70_Cleaned_L1R_v1,
   HLT_Photon70_NoHE_Cleaned_L1R_v1,
   HLT_Physics,
   HLT_PixelTracks_Multiplicity40,
   HLT_QuadJet15U_v3,
   HLT_QuadJet20U_v3,
   HLT_QuadJet25U_v3,
   HLT_R010U_MR50U,
   HLT_R030U_MR100U,
   HLT_R033U_MR100U,
   HLT_RP025U_MR70U,
   HLT_SingleIsoTau20_Trk15_MET25_v3,
   HLT_SingleIsoTau20_Trk5,
   HLT_SingleIsoTau35_Trk15_MET25_v3,
   HLT_SingleLooseIsoTau20_Trk5,
   HLT_SingleLooseIsoTau25,
   HLT_SingleLooseIsoTau25_Trk5,
   HLT_StoppedHSCP20_v3,
   HLT_StoppedHSCP35_v3,
   HLT_DoubleEle4_SW_eeRes_L1R_v2,
   HLT_DoubleEle5_SW_Upsilon_L1R_v2,
   HLT_DoubleIsoTau15_OneLeg_Trk5_v4,
   HLT_DoubleIsoTau15_Trk5_v4,
   HLT_Ele10_SW_EleId_HT70U_L1R_v2,
   HLT_Ele10_SW_HT100U_L1R_v2,
   HLT_Ele10_SW_HT70U_L1R_v2,
   HLT_Ele10_SW_L1R_v2,
   HLT_Ele12_SW_TighterEleId_L1R_v2,
   HLT_Ele17_SW_Isol_L1R_v2,
   HLT_Ele17_SW_L1R_v2,
   HLT_Ele17_SW_TightCaloEleId_Ele8HE_L1R_v2,
   HLT_Ele17_SW_TighterEleIdIsol_L1R_v3,
   HLT_Ele22_SW_L1R_v2,
   HLT_Ele22_SW_TighterCaloIdIsol_L1R_v2,
   HLT_Ele22_SW_TighterEleId_L1R_v3,
   HLT_IsoEle12_PFTau15_v2,
   HLT_IsoEle12_PFTau15_v3,
   HLT_IsoMu11_v4,
   HLT_IsoMu13_v4,
   HLT_IsoMu15_v4,
   HLT_IsoMu17_v4,
   HLT_IsoMu9_PFTau15_v2,
   HLT_IsoMu9_v4,
   HLT_Mu0_TkMu0_OST_Jpsi_Tight_v3,
   HLT_Mu11_PFTau15_v2,
   HLT_Mu3_TkMu0_OST_Jpsi_Tight_v3,
   HLT_Mu3_Track3_Jpsi_v3,
   HLT_Mu3_Track5_Jpsi_v3,
   HLT_Mu5_Ele17_v2,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_v2,
   HLT_Mu5_Track0_Jpsi_v2,
   HLT_MultiVertex6_v2,
   HLT_MultiVertex8_L1ETT60_v2,
   HLT_SingleIsoTau20_Trk15_MET25_v4,
   HLT_SingleIsoTau35_Trk15_MET25_v4,
   HLT_BeamGas_BSC_v1,
   HLT_BeamGas_BSC_v2,
   HLT_BeamGas_HF_v1,
   HLT_BeamGas_HF_v2,
   HLT_BeamHalo_v2,
   HLT_BTagMu_DiJet100_Mu9_v2,
   HLT_BTagMu_DiJet20_Mu5_v1,
   HLT_BTagMu_DiJet20_Mu5_v2,
   HLT_BTagMu_DiJet60_Mu7_v1,
   HLT_BTagMu_DiJet60_Mu7_v2,
   HLT_BTagMu_DiJet80_Mu9_v1,
   HLT_BTagMu_DiJet80_Mu9_v2,
   HLT_CentralJet80_MET100_v1,
   HLT_CentralJet80_MET160_v1,
   HLT_CentralJet80_MET65_v1,
   HLT_CentralJet80_MET80_v1,
   HLT_DiJet100_PT100_v1,
   HLT_DiJet130_PT130_v1,
   HLT_DiJet60_MET45_v1,
   HLT_DiJet70_PT70_v1,
   HLT_DiJetAve100U_v4,
   HLT_DiJetAve140U_v4,
   HLT_DiJetAve180U_v4,
   HLT_DiJetAve300U_v4,
   HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v1,
   HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v2,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_HT160_v2,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_HT160_v3,
   HLT_DoubleEle8_CaloIdT_TrkIdVL_HT160_v2,
   HLT_DoubleEle8_CaloIdT_TrkIdVL_HT160_v3,
   HLT_DoubleIsoPFTau20_Trk5_v1,
   HLT_DoubleIsoPFTau20_Trk5_v2,
   HLT_DoubleJet30_ForwardBackward_v1,
   HLT_DoubleJet30_ForwardBackward_v2,
   HLT_DoubleJet60_ForwardBackward_v1,
   HLT_DoubleJet60_ForwardBackward_v2,
   HLT_DoubleJet70_ForwardBackward_v1,
   HLT_DoubleJet70_ForwardBackward_v2,
   HLT_DoubleJet80_ForwardBackward_v1,
   HLT_DoubleJet80_ForwardBackward_v2,
   HLT_DoubleMu2_Bs_v1,
   HLT_DoubleMu4_Acoplanarity03_v1,
   HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v2,
   HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v3,
   HLT_DoubleMu5_Ele8_v2,
   HLT_DoubleMu5_Ele8_v3,
   HLT_DoubleMu6_v1,
   HLT_DoubleMu7_v1,
   HLT_DoublePhoton33_v1,
   HLT_DoublePhoton33_v2,
   HLT_DoublePhoton5_IsoVL_CEP_v1,
   HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v2,
   HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v3,
   HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v2,
   HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v3,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v1,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v2,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v1,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v2,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2,
   HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v1,
   HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v2,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v1,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v2,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v1,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v2,
   HLT_Ele17_CaloIdL_CaloIsoVL_v1,
   HLT_Ele17_CaloIdL_CaloIsoVL_v2,
   HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v2,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v1,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v2,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v2,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v2,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet40_BTagIP_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet40_BTagIP_v2,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v2,
   HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1,
   HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2,
   HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v1,
   HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v2,
   HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1,
   HLT_Ele45_CaloIdVT_TrkIdT_v1,
   HLT_Ele45_CaloIdVT_TrkIdT_v2,
   HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v1,
   HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v2,
   HLT_Ele8_CaloIdL_CaloIsoVL_v1,
   HLT_Ele8_CaloIdL_CaloIsoVL_v2,
   HLT_Ele8_CaloIdL_TrkIdVL_v1,
   HLT_Ele8_CaloIdL_TrkIdVL_v2,
   HLT_Ele8_v1,
   HLT_Ele8_v2,
   HLT_Ele90_NoSpikeFilter_v1,
   HLT_Ele90_NoSpikeFilter_v2,
   HLT_ExclDiJet60_HFAND_v1,
   HLT_ExclDiJet60_HFOR_v1,
   HLT_HT150_AlphaT0p60_v1,
   HLT_HT150_AlphaT0p70_v1,
   HLT_HT150_v2,
   HLT_HT160_v2,
   HLT_HT250_AlphaT0p55_v1,
   HLT_HT250_AlphaT0p62_v1,
   HLT_HT250_DoubleDisplacedJet60_v1,
   HLT_HT250_MHT60_v2,
   HLT_HT250_v2,
   HLT_HT260_MHT60_v2,
   HLT_HT260_v2,
   HLT_HT300_AlphaT0p52_v1,
   HLT_HT300_AlphaT0p54_v1,
   HLT_HT300_MHT75_v2,
   HLT_HT300_MHT75_v3,
   HLT_HT300_v2,
   HLT_HT300_v3,
   HLT_HT350_AlphaT0p51_v1,
   HLT_HT350_AlphaT0p53_v1,
   HLT_HT350_v2,
   HLT_HT360_v2,
   HLT_HT400_AlphaT0p51_v1,
   HLT_HT400_v2,
   HLT_HT440_v2,
   HLT_HT450_v2,
   HLT_HT500_v2,
   HLT_HT520_v2,
   HLT_HT550_v2,
   HLT_IsoMu12_LooseIsoPFTau10_v1,
   HLT_IsoMu12_LooseIsoPFTau10_v2,
   HLT_IsoMu12_v1,
   HLT_IsoMu15_v5,
   HLT_IsoMu17_CentralJet40_BTagIP_v1,
   HLT_IsoMu17_CentralJet40_BTagIP_v2,
   HLT_IsoMu17_v5,
   HLT_IsoMu24_v1,
   HLT_IsoPFTau35_Trk20_MET45_v1,
   HLT_IsoPFTau35_Trk20_MET45_v2,
   HLT_Jet150_v1,
   HLT_Jet190_v1,
   HLT_Jet240_v1,
   HLT_Jet370_NoJetID_v1,
   HLT_Jet370_v1,
   HLT_Jet60_v1,
   HLT_JetE30_NoBPTX3BX_NoHalo_v1,
   HLT_JetE30_NoBPTX3BX_NoHalo_v2,
   HLT_JetE30_NoBPTX_NoHalo_v1,
   HLT_JetE30_NoBPTX_NoHalo_v2,
   HLT_JetE30_NoBPTX_v1,
   HLT_L1_BeamHalo_v1,
   HLT_L1DoubleMu0_v1,
   HLT_L1_Interbunch_BSC_v1,
   HLT_L1_PreCollisions_v1,
   HLT_L1SingleJet36_v1,
   HLT_L1SingleMu10_v1,
   HLT_L1SingleMu20_v1,
   HLT_L1SingleMuOpen_AntiBPTX_v1,
   HLT_L1SingleMuOpen_DT_v1,
   HLT_L1SingleMuOpen_v1,
   HLT_L1Tech_CASTOR_HaloMuon_v1,
   HLT_L1Tech_HBHEHO_totalOR_v1,
   HLT_L1TrackerCosmics_v2,
   HLT_L2DoubleMu23_NoVertex_v1,
   HLT_L2DoubleMu35_NoVertex_v1,
   HLT_L2Mu10_v1,
   HLT_L2Mu20_v1,
   HLT_L2MuOpen_NoVertex_v1,
   HLT_L3MuonsCosmicTracking_v1,
   HLT_Meff440_v2,
   HLT_Meff520_v2,
   HLT_Meff640_v2,
   HLT_MET120_v1,
   HLT_MET200_v1,
   HLT_MR100_v1,
   HLT_Mu10_Ele10_CaloIdL_v2,
   HLT_Mu10_Ele10_CaloIdL_v3,
   HLT_Mu12_v1,
   HLT_Mu17_CentralJet30_v1,
   HLT_Mu17_CentralJet30_v2,
   HLT_Mu17_CentralJet40_BTagIP_v1,
   HLT_Mu17_CentralJet40_BTagIP_v2,
   HLT_Mu17_DiCentralJet30_v1,
   HLT_Mu17_DiCentralJet30_v2,
   HLT_Mu17_Ele8_CaloIdL_v1,
   HLT_Mu17_Ele8_CaloIdL_v2,
   HLT_Mu17_TriCentralJet30_v1,
   HLT_Mu17_TriCentralJet30_v2,
   HLT_Mu20_v1,
   HLT_Mu24_v1,
   HLT_Mu8_Ele17_CaloIdL_v1,
   HLT_Mu8_Ele17_CaloIdL_v2,
   HLT_Mu8_HT200_v2,
   HLT_Mu8_HT200_v3,
   HLT_Mu8_Jet40_v2,
   HLT_Mu8_Jet40_v3,
   HLT_Mu8_Photon20_CaloIdVT_IsoT_v2,
   HLT_Mu8_v1,
   HLT_PFMHT150_v1,
   HLT_PFMHT150_v2,
   HLT_Photon125_NoSpikeFilter_v1,
   HLT_Photon125_NoSpikeFilter_v2,
   HLT_Photon20_CaloIdVL_IsoL_v1,
   HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v1,
   HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v2,
   HLT_Photon20_EBOnly_NoSpikeFilter_v1,
   HLT_Photon20_NoSpikeFilter_v1,
   HLT_Photon20_R9Id_Photon18_R9Id_v1,
   HLT_Photon20_R9Id_Photon18_R9Id_v2,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v1,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v2,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v1,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_v1,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_v2,
   HLT_Photon26_IsoVL_Photon18_IsoVL_v1,
   HLT_Photon26_IsoVL_Photon18_IsoVL_v2,
   HLT_Photon26_IsoVL_Photon18_v1,
   HLT_Photon26_IsoVL_Photon18_v2,
   HLT_Photon26_Photon18_v1,
   HLT_Photon26_Photon18_v2,
   HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v1,
   HLT_Photon30_CaloIdVL_IsoL_v1,
   HLT_Photon30_CaloIdVL_IsoL_v2,
   HLT_Photon30_CaloIdVL_v1,
   HLT_Photon30_CaloIdVL_v2,
   HLT_Photon32_CaloIdL_Photon26_CaloIdL_v1,
   HLT_Photon32_CaloIdL_Photon26_CaloIdL_v2,
   HLT_Photon36_CaloIdL_Photon22_CaloIdL_v1,
   HLT_Photon50_CaloIdVL_IsoL_v1,
   HLT_Photon60_CaloIdL_HT200_v1,
   HLT_Photon60_CaloIdL_HT200_v2,
   HLT_Photon70_CaloIdL_HT200_v1,
   HLT_Photon70_CaloIdL_HT200_v2,
   HLT_Photon70_CaloIdL_HT300_v1,
   HLT_Photon70_CaloIdL_HT300_v2,
   HLT_Photon70_CaloIdL_MHT30_v1,
   HLT_Photon70_CaloIdL_MHT30_v2,
   HLT_Photon70_CaloIdL_MHT50_v1,
   HLT_Photon70_CaloIdL_MHT50_v2,
   HLT_Photon75_CaloIdVL_IsoL_v1,
   HLT_Photon75_CaloIdVL_IsoL_v2,
   HLT_Photon75_CaloIdVL_v1,
   HLT_Photon75_CaloIdVL_v2,
   HLT_PixelTracks_Multiplicity110_v1,
   HLT_PixelTracks_Multiplicity125_v1,
   HLT_PixelTracks_Multiplicity80_v2,
   HLT_QuadJet40_IsoPFTau40_v1,
   HLT_QuadJet40_v1,
   HLT_QuadJet40_v2,
   HLT_QuadJet50_BTagIP_v1,
   HLT_QuadJet50_Jet40_v1,
   HLT_QuadJet60_v1,
   HLT_QuadJet70_v1,
   HLT_R032_MR100_v1,
   HLT_R032_v1,
   HLT_R035_MR100_v1,
   HLT_RegionalCosmicTracking_v1,
   HLT_Spike20_v1,
   HLT_TrackerCalibration_v1,
   HLT_TripleEle10_CaloIdL_TrkIdVL_v1,
   HLT_TripleEle10_CaloIdL_TrkIdVL_v2,
   HLT_TripleMu5_v2,
   HLT_BeamGas_HF_v3,
   HLT_BTagMu_DiJet110_Mu5_v3,
   HLT_BTagMu_DiJet20_Mu5_v3,
   HLT_BTagMu_DiJet40_Mu5_v3,
   HLT_BTagMu_DiJet70_Mu5_v3,
   HLT_CentralJet80_MET100_v2,
   HLT_CentralJet80_MET160_v2,
   HLT_CentralJet80_MET65_v2,
   HLT_CentralJet80_MET80_v2,
   HLT_DiJet60_MET45_v2,
   HLT_DiJetAve110_v1,
   HLT_DiJetAve110_v2,
   HLT_DiJetAve150_v1,
   HLT_DiJetAve150_v2,
   HLT_DiJetAve190_v1,
   HLT_DiJetAve190_v2,
   HLT_DiJetAve240_v1,
   HLT_DiJetAve240_v2,
   HLT_DiJetAve300_v1,
   HLT_DiJetAve300_v2,
   HLT_DiJetAve30_v1,
   HLT_DiJetAve30_v2,
   HLT_DiJetAve370_v1,
   HLT_DiJetAve370_v2,
   HLT_DiJetAve60_v1,
   HLT_DiJetAve60_v2,
   HLT_DiJetAve80_v1,
   HLT_DiJetAve80_v2,
   HLT_Dimuon0_Barrel_Upsilon_v1,
   HLT_Dimuon6p5_Barrel_Jpsi_v1,
   HLT_Dimuon6p5_Barrel_PsiPrime_v1,
   HLT_Dimuon6p5_Jpsi_Displaced_v1,
   HLT_Dimuon6p5_Jpsi_v1,
   HLT_Dimuon6p5_LowMass_Displaced_v1,
   HLT_Dimuon6p5_LowMass_v1,
   HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v3,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v1,
   HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v1,
   HLT_DoubleIsoPFTau20_Trk5_v4,
   HLT_DoubleJet30_ForwardBackward_v3,
   HLT_DoubleJet60_ForwardBackward_v3,
   HLT_DoubleJet70_ForwardBackward_v3,
   HLT_DoubleJet80_ForwardBackward_v3,
   HLT_DoubleMu2_Bs_v2,
   HLT_DoubleMu4_Acoplanarity03_v2,
   HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v4,
   HLT_DoubleMu5_Ele8_v4,
   HLT_DoubleMu6_v2,
   HLT_DoubleMu7_v2,
   HLT_DoublePhoton33_v3,
   HLT_DoublePhoton5_IsoVL_CEP_v2,
   HLT_Ele10_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_HT200_v4,
   HLT_Ele10_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v1,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v1,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3,
   HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v1,
   HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v4,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v3,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v3,
   HLT_Ele17_CaloIdL_CaloIsoVL_v3,
   HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v3,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v3,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralDiJet30_v3,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v2,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v3,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralTriJet30_v3,
   HLT_Ele27_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3,
   HLT_Ele32_CaloIdL_CaloIsoVL_SC17_v3,
   HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v2,
   HLT_Ele45_CaloIdVT_TrkIdT_v3,
   HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v3,
   HLT_Ele8_CaloIdL_CaloIsoVL_v3,
   HLT_Ele8_CaloIdL_TrkIdVL_v3,
   HLT_Ele8_v3,
   HLT_Ele90_NoSpikeFilter_v3,
   HLT_ExclDiJet60_HFAND_v2,
   HLT_ExclDiJet60_HFOR_v2,
   HLT_HT150_AlphaT0p60_v2,
   HLT_HT150_AlphaT0p70_v2,
   HLT_HT150_v3,
   HLT_HT250_AlphaT0p55_v2,
   HLT_HT250_AlphaT0p62_v2,
   HLT_HT250_DoubleDisplacedJet60_v2,
   HLT_HT250_DoubleLooseIsoPFTau10_Trk3_PFMHT35_v2,
   HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v2,
   HLT_HT250_MHT60_v3,
   HLT_HT250_Mu5_PFMHT35_v2,
   HLT_HT250_v3,
   HLT_HT300_AlphaT0p52_v2,
   HLT_HT300_AlphaT0p54_v2,
   HLT_HT300_MHT75_v4,
   HLT_HT300_v4,
   HLT_HT350_AlphaT0p51_v2,
   HLT_HT350_AlphaT0p53_v2,
   HLT_HT350_v3,
   HLT_HT400_AlphaT0p51_v2,
   HLT_HT400_v3,
   HLT_HT450_v3,
   HLT_HT500_v3,
   HLT_HT550_v3,
   HLT_IsoMu12_LooseIsoPFTau10_v4,
   HLT_IsoMu12_v2,
   HLT_IsoMu15_v6,
   HLT_IsoMu17_CentralJet30_BTagIP_v2,
   HLT_IsoMu17_v6,
   HLT_IsoMu24_v2,
   HLT_IsoPFTau35_Trk20_MET45_v4,
   HLT_Jet150_v2,
   HLT_Jet190_v2,
   HLT_Jet240_v2,
   HLT_Jet370_NoJetID_v2,
   HLT_Jet370_v2,
   HLT_Jet60_v2,
   HLT_JetE30_NoBPTX3BX_NoHalo_v4,
   HLT_JetE30_NoBPTX_NoHalo_v4,
   HLT_JetE30_NoBPTX_v2,
   HLT_L1DoubleJet36Central_v1,
   HLT_L1ETM30_v1,
   HLT_L1SingleJet16_v1,
   HLT_L2DoubleMu23_NoVertex_v2,
   HLT_L2Mu10_v2,
   HLT_L2Mu20_v2,
   HLT_L3MuonsCosmicTracking_v2,
   HLT_Meff440_v3,
   HLT_Meff520_v3,
   HLT_Meff640_v3,
   HLT_MET120_v2,
   HLT_MET200_v2,
   HLT_MR100_v2,
   HLT_Mu10_Ele10_CaloIdL_v4,
   HLT_Mu12_v2,
   HLT_Mu17_CentralJet30_BTagIP_v2,
   HLT_Mu17_CentralJet30_v4,
   HLT_Mu17_DiCentralJet30_v4,
   HLT_Mu17_Ele8_CaloIdL_v3,
   HLT_Mu17_TriCentralJet30_v4,
   HLT_Mu20_v2,
   HLT_Mu24_v2,
   HLT_Mu8_Ele17_CaloIdL_v3,
   HLT_Mu8_HT200_v4,
   HLT_Mu8_Jet40_v4,
   HLT_Mu8_Photon20_CaloIdVT_IsoT_v3,
   HLT_Mu8_v2,
   HLT_PFMHT150_v4,
   HLT_Photon125_NoSpikeFilter_v3,
   HLT_Photon20_CaloIdVL_IsoL_v2,
   HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v3,
   HLT_Photon20_R9Id_Photon18_R9Id_v3,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v3,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v2,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_v3,
   HLT_Photon26_IsoVL_Photon18_IsoVL_v3,
   HLT_Photon26_IsoVL_Photon18_v3,
   HLT_Photon26_Photon18_v3,
   HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v2,
   HLT_Photon30_CaloIdVL_IsoL_v3,
   HLT_Photon30_CaloIdVL_v3,
   HLT_Photon32_CaloIdL_Photon26_CaloIdL_v3,
   HLT_Photon36_CaloIdL_Photon22_CaloIdL_v2,
   HLT_Photon50_CaloIdVL_IsoL_v2,
   HLT_Photon60_CaloIdL_HT200_v3,
   HLT_Photon70_CaloIdL_HT200_v3,
   HLT_Photon70_CaloIdL_HT300_v3,
   HLT_Photon70_CaloIdL_MHT30_v3,
   HLT_Photon70_CaloIdL_MHT50_v3,
   HLT_Photon75_CaloIdVL_IsoL_v3,
   HLT_Photon75_CaloIdVL_v3,
   HLT_QuadJet40_IsoPFTau40_v3,
   HLT_QuadJet40_v3,
   HLT_QuadJet50_BTagIP_v2,
   HLT_QuadJet50_Jet40_v2,
   HLT_QuadJet60_v2,
   HLT_QuadJet70_v2,
   HLT_R032_MR100_v2,
   HLT_R032_v2,
   HLT_R035_MR100_v2,
   HLT_RegionalCosmicTracking_v2,
   HLT_TripleEle10_CaloIdL_TrkIdVL_v3,
   HLT_TripleMu5_v3,
   AlCa_EcalEta_v2,
   AlCa_EcalEta_v3,
   AlCa_EcalPhiSym_v2,
   AlCa_EcalPi0_v3,
   AlCa_EcalPi0_v4,
   AlCa_RPCMuonNoHits_v2,
   AlCa_RPCMuonNoHits_v3,
   AlCa_RPCMuonNormalisation_v2,
   AlCa_RPCMuonNormalisation_v3,
   AlCa_RPCMuonNoTriggers_v2,
   AlCa_RPCMuonNoTriggers_v3,
   HLT_Activity_Ecal_SC7_v1,
   HLT_Activity_Ecal_SC7_v2,
   HLT_Calibration_v1,
   HLT_DiJetAve15U_v4,
   HLT_DiJetAve30U_v4,
   HLT_DiJetAve50U_v4,
   HLT_DiJetAve70U_v4,
   HLT_DoubleMu3_Bs_v1,
   HLT_DoubleMu3_HT150_v1,
   HLT_DoubleMu3_HT160_v2,
   HLT_DoubleMu3_HT160_v3,
   HLT_DoubleMu3_HT200_v2,
   HLT_DoubleMu3_HT200_v3,
   HLT_DoubleMu3_HT200_v4,
   HLT_DoubleMu3_Jpsi_v1,
   HLT_DoubleMu3_Jpsi_v2,
   HLT_DoubleMu3_LowMass_v1,
   HLT_DoubleMu3_Quarkonium_v1,
   HLT_DoubleMu3_Quarkonium_v2,
   HLT_DoubleMu3_Upsilon_v1,
   HLT_DoubleMu3_v3,
   HLT_DoubleMu3_v4,
   HLT_DTErrors_v1,
   HLT_EcalCalibration_v1,
   HLT_GlobalRunHPDNoise_v2,
   HLT_HcalCalibration_v1,
   HLT_HcalNZS_v2,
   HLT_HcalNZS_v3,
   HLT_HcalPhiSym_v2,
   HLT_HcalPhiSym_v3,
   HLT_HT200_AlphaT0p60_v1,
   HLT_HT200_AlphaT0p60_v2,
   HLT_HT200_AlphaT0p65_v1,
   HLT_HT200_AlphaT0p65_v2,
   HLT_HT200_DoubleLooseIsoPFTau10_Trk3_PFMHT35_v2,
   HLT_HT200_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v2,
   HLT_HT200_Mu5_PFMHT35_v2,
   HLT_HT200_v2,
   HLT_HT200_v3,
   HLT_HT240_v2,
   HLT_IsoMu30_v1,
   HLT_IsoMu30_v2,
   HLT_Jet110_v1,
   HLT_Jet110_v2,
   HLT_Jet300_v1,
   HLT_Jet30_v1,
   HLT_Jet30_v2,
   HLT_Jet80_v1,
   HLT_Jet80_v2,
   HLT_L1MultiJet_v1,
   HLT_L1SingleEG12_v1,
   HLT_L1SingleEG5_v1,
   HLT_L1Tech_BSC_halo_v1,
   HLT_L1Tech_BSC_halo_v3,
   HLT_L1Tech_BSC_minBias_threshold1_v1,
   HLT_L1Tech_BSC_minBias_threshold1_v2,
   HLT_L1Tech_BSC_minBias_threshold1_v3,
   HLT_L2DoubleMu0_v2,
   HLT_L2DoubleMu0_v3,
   HLT_LogMonitor_v1,
   HLT_MET100_v1,
   HLT_Mu15_DoublePhoton15_CaloIdL_v2,
   HLT_Mu15_DoublePhoton15_CaloIdL_v3,
   HLT_Mu15_DoublePhoton15_CaloIdL_v4,
   HLT_Mu15_LooseIsoPFTau20_v1,
   HLT_Mu15_LooseIsoPFTau20_v2,
   HLT_Mu15_LooseIsoPFTau20_v4,
   HLT_Mu15_Photon20_CaloIdL_v2,
   HLT_Mu15_Photon20_CaloIdL_v3,
   HLT_Mu15_Photon20_CaloIdL_v4,
   HLT_Mu15_v2,
   HLT_Mu15_v3,
   HLT_Mu30_v1,
   HLT_Mu30_v2,
   HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v1,
   HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT160_v2,
   HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT160_v3,
   HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v1,
   HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT160_v2,
   HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT160_v3,
   HLT_Mu3_Track3_Jpsi_v4,
   HLT_Mu3_Track3_Jpsi_v5,
   HLT_Mu3_v3,
   HLT_Mu3_v4,
   HLT_Mu5_DoubleEle8_v2,
   HLT_Mu5_DoubleEle8_v3,
   HLT_Mu5_DoubleEle8_v4,
   HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v2,
   HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v3,
   HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v4,
   HLT_Mu5_HT200_v3,
   HLT_Mu5_HT200_v4,
   HLT_Mu5_HT200_v5,
   HLT_Mu5_L2Mu2_Jpsi_v1,
   HLT_Mu5_L2Mu2_Jpsi_v2,
   HLT_Mu5_L2Mu2_Jpsi_v3,
   HLT_Mu5_L2Mu2_v1,
   HLT_Mu5_L2Mu2_v2,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v1,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v2,
   HLT_Mu5_Track2_Jpsi_v1,
   HLT_Mu5_Track2_Jpsi_v2,
   HLT_Mu5_v3,
   HLT_Mu5_v4,
   HLT_Mu7_Track5_Jpsi_v1,
   HLT_Mu7_Track5_Jpsi_v2,
   HLT_Mu7_Track7_Jpsi_v1,
   HLT_Mu7_Track7_Jpsi_v2,
   HLT_Mu7_Track7_Jpsi_v3,
   HLT_Physics_NanoDST_v1,
   HLT_Physics_v1,
   HLT_PixelTracks_Multiplicity100_v2,
   HLT_Random_v1,
   HLT_ZeroBias_v1,
   HLT_ZeroBias_v2,
   AlCa_EcalEta_v4,
   AlCa_EcalEta_v5,
   AlCa_EcalEta_v6,
   AlCa_EcalEta_vDEAD,
   AlCa_EcalPhiSym_v3,
   AlCa_EcalPhiSym_v5,
   AlCa_EcalPhiSym_v6,
   AlCa_EcalPi0_v5,
   AlCa_EcalPi0_v6,
   AlCa_EcalPi0_v7,
   AlCa_EcalPi0_vDEAD,
   AlCa_RPCMuonNoHits_v4,
   AlCa_RPCMuonNoHits_v5,
   AlCa_RPCMuonNoTriggers_v4,
   AlCa_RPCMuonNoTriggers_v5,
   AlCa_RPCMuonNormalisation_v4,
   AlCa_RPCMuonNormalisation_v5,
   HLT_Activity_Ecal_SC7_v3,
   HLT_Activity_Ecal_SC7_v5,
   HLT_Activity_Ecal_SC7_v6,
   HLT_BTagMu_DiJet110_Mu5_v4,
   HLT_BTagMu_DiJet110_Mu5_v5,
   HLT_BTagMu_DiJet110_Mu5_v6,
   HLT_BTagMu_DiJet20_Mu5_v4,
   HLT_BTagMu_DiJet20_Mu5_v5,
   HLT_BTagMu_DiJet20_Mu5_v6,
   HLT_BTagMu_DiJet40_Mu5_v4,
   HLT_BTagMu_DiJet40_Mu5_v5,
   HLT_BTagMu_DiJet40_Mu5_v6,
   HLT_BTagMu_DiJet70_Mu5_v4,
   HLT_BTagMu_DiJet70_Mu5_v5,
   HLT_BTagMu_DiJet70_Mu5_v6,
   HLT_BeamGas_BSC_v3,
   HLT_BeamGas_HF_v4,
   HLT_BeamGas_HF_v5,
   HLT_BeamHalo_v3,
   HLT_CentralJet46_BTagIP3D_CentralJet38_BTagIP3D_v1,
   HLT_CentralJet46_BTagIP3D_CentralJet38_BTagIP3D_v2,
   HLT_CentralJet80_MET100_v3,
   HLT_CentralJet80_MET100_v4,
   HLT_CentralJet80_MET100_v5,
   HLT_CentralJet80_MET160_v3,
   HLT_CentralJet80_MET160_v4,
   HLT_CentralJet80_MET160_v5,
   HLT_CentralJet80_MET65_v3,
   HLT_CentralJet80_MET65_v4,
   HLT_CentralJet80_MET65_v5,
   HLT_CentralJet80_MET80HF_v2,
   HLT_CentralJet80_MET80HF_v3,
   HLT_CentralJet80_MET80HF_v4,
   HLT_DTCalibration_v1,
   HLT_DiCentralJet20_BTagIP_MET65_v2,
   HLT_DiCentralJet20_BTagIP_MET65_v3,
   HLT_DiCentralJet20_BTagIP_MET65_v4,
   HLT_DiCentralJet20_MET80_v1,
   HLT_DiCentralJet20_MET80_v2,
   HLT_DiCentralJet20_MET80_v3,
   HLT_DiJet130_PT130_v2,
   HLT_DiJet130_PT130_v3,
   HLT_DiJet130_PT130_v4,
   HLT_DiJet160_PT160_v2,
   HLT_DiJet160_PT160_v3,
   HLT_DiJet160_PT160_v4,
   HLT_DiJet60_MET45_v3,
   HLT_DiJet60_MET45_v4,
   HLT_DiJet60_MET45_v5,
   HLT_DiJetAve110_v3,
   HLT_DiJetAve110_v4,
   HLT_DiJetAve110_v5,
   HLT_DiJetAve150_v3,
   HLT_DiJetAve150_v4,
   HLT_DiJetAve150_v5,
   HLT_DiJetAve190_v3,
   HLT_DiJetAve190_v4,
   HLT_DiJetAve190_v5,
   HLT_DiJetAve240_v3,
   HLT_DiJetAve240_v4,
   HLT_DiJetAve240_v5,
   HLT_DiJetAve300_v3,
   HLT_DiJetAve300_v4,
   HLT_DiJetAve300_v5,
   HLT_DiJetAve30_v3,
   HLT_DiJetAve30_v4,
   HLT_DiJetAve30_v5,
   HLT_DiJetAve370_v3,
   HLT_DiJetAve370_v4,
   HLT_DiJetAve370_v5,
   HLT_DiJetAve60_v3,
   HLT_DiJetAve60_v4,
   HLT_DiJetAve60_v5,
   HLT_DiJetAve80_v3,
   HLT_DiJetAve80_v4,
   HLT_DiJetAve80_v5,
   HLT_Dimuon0_Jpsi_Muon_v1,
   HLT_Dimuon0_Jpsi_Muon_v2,
   HLT_Dimuon0_Jpsi_Muon_v3,
   HLT_Dimuon0_Jpsi_v1,
   HLT_Dimuon0_Jpsi_v2,
   HLT_Dimuon0_Upsilon_Muon_v1,
   HLT_Dimuon0_Upsilon_Muon_v2,
   HLT_Dimuon0_Upsilon_Muon_v3,
   HLT_Dimuon0_Upsilon_v1,
   HLT_Dimuon0_Upsilon_v2,
   HLT_Dimuon10_Jpsi_Barrel_v1,
   HLT_Dimuon10_Jpsi_Barrel_v2,
   HLT_Dimuon4_Bs_Barrel_v2,
   HLT_Dimuon4_Bs_Barrel_v3,
   HLT_Dimuon4_Bs_Barrel_v4,
   HLT_Dimuon5_Upsilon_Barrel_v1,
   HLT_Dimuon5_Upsilon_Barrel_v2,
   HLT_Dimuon6_Bs_v1,
   HLT_Dimuon6_Bs_v2,
   HLT_Dimuon6_Bs_v3,
   HLT_Dimuon7_Jpsi_Displaced_v1,
   HLT_Dimuon7_Jpsi_Displaced_v2,
   HLT_Dimuon7_Jpsi_X_Barrel_v1,
   HLT_Dimuon7_Jpsi_X_Barrel_v2,
   HLT_Dimuon7_LowMass_Displaced_v1,
   HLT_Dimuon7_LowMass_Displaced_v2,
   HLT_Dimuon7_LowMass_Displaced_v3,
   HLT_Dimuon7_PsiPrime_v1,
   HLT_Dimuon7_PsiPrime_v2,
   HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v4,
   HLT_DoubleEle10_CaloIdL_TrkIdVL_Ele10_v6,
   HLT_DoubleEle33_CaloIdL_v1,
   HLT_DoubleEle33_CaloIdL_v2,
   HLT_DoubleEle33_v1,
   HLT_DoubleEle33_v2,
   HLT_DoubleEle45_CaloIdL_v1,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v2,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_HT150_v3,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_v1,
   HLT_DoubleEle8_CaloIdL_TrkIdVL_v2,
   HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v2,
   HLT_DoubleEle8_CaloIdT_TrkIdVL_HT150_v3,
   HLT_DoubleIsoPFTau25_Trk5_eta2p1_v2,
   HLT_DoubleIsoPFTau35_Trk5_eta2p1_v2,
   HLT_DoubleIsoPFTau35_Trk5_eta2p1_v3,
   HLT_DoubleIsoPFTau40_Trk5_eta2p1_v2,
   HLT_DoubleIsoPFTau40_Trk5_eta2p1_v3,
   HLT_DoubleJet30_ForwardBackward_v4,
   HLT_DoubleJet30_ForwardBackward_v5,
   HLT_DoubleJet30_ForwardBackward_v6,
   HLT_DoubleJet60_ForwardBackward_v4,
   HLT_DoubleJet60_ForwardBackward_v5,
   HLT_DoubleJet60_ForwardBackward_v6,
   HLT_DoubleJet70_ForwardBackward_v4,
   HLT_DoubleJet70_ForwardBackward_v5,
   HLT_DoubleJet70_ForwardBackward_v6,
   HLT_DoubleJet80_ForwardBackward_v4,
   HLT_DoubleJet80_ForwardBackward_v5,
   HLT_DoubleJet80_ForwardBackward_v6,
   HLT_DoubleMu2_Bs_v3,
   HLT_DoubleMu2_Bs_v4,
   HLT_DoubleMu3_HT150_v2,
   HLT_DoubleMu3_HT150_v3,
   HLT_DoubleMu3_HT150_v4,
   HLT_DoubleMu3_HT200_v5,
   HLT_DoubleMu3_HT200_v6,
   HLT_DoubleMu3_HT200_v7,
   HLT_DoubleMu3_v5,
   HLT_DoubleMu3_v6,
   HLT_DoubleMu45_v1,
   HLT_DoubleMu45_v2,
   HLT_DoubleMu4_Acoplanarity03_v3,
   HLT_DoubleMu4_Acoplanarity03_v4,
   HLT_DoubleMu4_Acoplanarity03_v5,
   HLT_DoubleMu5_Acoplanarity03_v1,
   HLT_DoubleMu5_Acoplanarity03_v2,
   HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v5,
   HLT_DoubleMu5_Ele8_CaloIdL_TrkIdVL_v6,
   HLT_DoubleMu5_Ele8_v5,
   HLT_DoubleMu5_Ele8_v6,
   HLT_DoubleMu6_v3,
   HLT_DoubleMu6_v4,
   HLT_DoubleMu7_v3,
   HLT_DoubleMu7_v4,
   HLT_DoublePhoton33_HEVT_v1,
   HLT_DoublePhoton33_HEVT_v2,
   HLT_DoublePhoton33_v4,
   HLT_DoublePhoton33_v5,
   HLT_DoublePhoton40_MR150_v1,
   HLT_DoublePhoton40_MR150_v3,
   HLT_DoublePhoton40_R014_MR150_v1,
   HLT_DoublePhoton40_R014_MR150_v3,
   HLT_DoublePhoton50_v1,
   HLT_DoublePhoton50_v2,
   HLT_DoublePhoton5_IsoVL_CEP_v3,
   HLT_DoublePhoton5_IsoVL_CEP_v4,
   HLT_DoublePhoton60_v1,
   HLT_DoublePhoton60_v2,
   HLT_EcalCalibration_v2,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v1,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v3,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R005_MR200_v4,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v1,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v3,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v4,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v1,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v3,
   HLT_Ele10_CaloIdL_TrkIdVL_CaloIsoVL_TrkIsoVL_R025_MR200_v4,
   HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v1,
   HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v3,
   HLT_Ele10_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_R020_MR200_v4,
   HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v4,
   HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT200_v5,
   HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT250_v4,
   HLT_Ele15_CaloIdT_CaloIsoVL_TrkIdT_TrkIsoVL_HT250_v5,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v2,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta2_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v2,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_Jet35_Jet25_Deta3_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau15_v6,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v6,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v8,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v4,
   HLT_Ele15_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v5,
   HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v2,
   HLT_Ele15_CaloIdVT_TrkIdT_Jet35_Jet25_Deta2_v4,
   HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau15_v6,
   HLT_Ele15_CaloIdVT_TrkIdT_LooseIsoPFTau20_v2,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v5,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFL_v6,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele15_HFT_v1,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v4,
   HLT_Ele17_CaloIdL_CaloIsoVL_Ele8_CaloIdL_CaloIsoVL_v5,
   HLT_Ele17_CaloIdL_CaloIsoVL_v4,
   HLT_Ele17_CaloIdL_CaloIsoVL_v5,
   HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v4,
   HLT_Ele17_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v5,
   HLT_Ele17_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT15_v2,
   HLT_Ele17_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT15_v4,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_Ele8_Mass30_v2,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_Ele8_Mass30_v3,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v4,
   HLT_Ele17_CaloIdVT_CaloIsoVT_TrkIdT_TrkIsoVT_SC8_Mass30_v5,
   HLT_Ele17_CaloIdVT_TrkIdT_CentralJet30_CentralJet25_v1,
   HLT_Ele17_CaloIdVT_TrkIdT_CentralJet30_CentralJet25_v4,
   HLT_Ele18_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_LooseIsoPFTau20_v2,
   HLT_Ele25_CaloIdL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_BTagIP_v1,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT20_v2,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_CentralJet25_PFMHT20_v4,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_CentralJet30_v1,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_DiCentralJet30_v1,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_QuadCentralJet30_v1,
   HLT_Ele25_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_TriCentralJet30_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v4,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_BTagIP_v5,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v4,
   HLT_Ele25_CaloIdVT_TrkIdT_CentralJet30_v5,
   HLT_Ele25_CaloIdVT_TrkIdT_DiCentralJet30_v3,
   HLT_Ele25_CaloIdVT_TrkIdT_DiCentralJet30_v4,
   HLT_Ele25_CaloIdVT_TrkIdT_QuadCentralJet30_v1,
   HLT_Ele25_CaloIdVT_TrkIdT_TriCentralJet30_v3,
   HLT_Ele25_CaloIdVT_TrkIdT_TriCentralJet30_v4,
   HLT_Ele25_WP80_PFMT40_v1,
   HLT_Ele27_WP70_PFMT40_PFMHT20_v1,
   HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v1,
   HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v2,
   HLT_Ele32_CaloIdT_CaloIsoT_TrkIdT_TrkIsoT_SC17_v3,
   HLT_Ele32_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1,
   HLT_Ele32_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v2,
   HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v3,
   HLT_Ele32_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v4,
   HLT_Ele42_CaloIdVL_CaloIsoVL_TrkIdVL_TrkIsoVL_v1,
   HLT_Ele42_CaloIdVT_CaloIsoT_TrkIdT_TrkIsoT_v1,
   HLT_Ele52_CaloIdVT_TrkIdT_v1,
   HLT_Ele52_CaloIdVT_TrkIdT_v2,
   HLT_Ele65_CaloIdVT_TrkIdT_v1,
   HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v4,
   HLT_Ele8_CaloIdL_CaloIsoVL_Jet40_v5,
   HLT_Ele8_CaloIdL_CaloIsoVL_v4,
   HLT_Ele8_CaloIdL_CaloIsoVL_v5,
   HLT_Ele8_CaloIdL_TrkIdVL_v4,
   HLT_Ele8_CaloIdL_TrkIdVL_v5,
   HLT_Ele8_CaloIdT_TrkIdT_DiJet30_v1,
   HLT_Ele8_CaloIdT_TrkIdT_DiJet30_v2,
   HLT_Ele8_CaloIdT_TrkIdT_QuadJet30_v1,
   HLT_Ele8_CaloIdT_TrkIdT_QuadJet30_v2,
   HLT_Ele8_CaloIdT_TrkIdT_TriJet30_v1,
   HLT_Ele8_CaloIdT_TrkIdT_TriJet30_v2,
   HLT_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v3,
   HLT_Ele8_CaloIdT_TrkIdVL_CaloIsoVL_TrkIsoVL_v4,
   HLT_Ele8_v4,
   HLT_Ele8_v5,
   HLT_ExclDiJet60_HFAND_v3,
   HLT_ExclDiJet60_HFAND_v4,
   HLT_ExclDiJet60_HFAND_v5,
   HLT_ExclDiJet60_HFOR_v3,
   HLT_ExclDiJet60_HFOR_v4,
   HLT_ExclDiJet60_HFOR_v5,
   HLT_GlobalRunHPDNoise_v3,
   HLT_HT150_AlphaT0p60_v3,
   HLT_HT150_AlphaT0p60_v4,
   HLT_HT150_AlphaT0p60_v5,
   HLT_HT150_v4,
   HLT_HT150_v5,
   HLT_HT150_v6,
   HLT_HT200_AlphaT0p53_v2,
   HLT_HT200_AlphaT0p53_v3,
   HLT_HT200_AlphaT0p53_v4,
   HLT_HT200_AlphaT0p60_v3,
   HLT_HT200_AlphaT0p60_v4,
   HLT_HT200_AlphaT0p60_v5,
   HLT_HT200_v4,
   HLT_HT200_v5,
   HLT_HT200_v6,
   HLT_HT250_AlphaT0p53_v2,
   HLT_HT250_AlphaT0p53_v3,
   HLT_HT250_AlphaT0p53_v4,
   HLT_HT250_AlphaT0p54_v2,
   HLT_HT250_AlphaT0p54_v3,
   HLT_HT250_AlphaT0p54_v4,
   HLT_HT250_DoubleDisplacedJet60_v3,
   HLT_HT250_DoubleDisplacedJet60_v4,
   HLT_HT250_DoubleDisplacedJet60_v5,
   HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v1,
   HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v3,
   HLT_HT250_DoubleIsoPFTau10_Trk3_PFMHT35_v4,
   HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v4,
   HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v5,
   HLT_HT250_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT35_v6,
   HLT_HT250_MHT60_v4,
   HLT_HT250_MHT60_v6,
   HLT_HT250_MHT60_v7,
   HLT_HT250_MHT70_v1,
   HLT_HT250_MHT70_v3,
   HLT_HT250_MHT70_v4,
   HLT_HT250_MHT80_v3,
   HLT_HT250_MHT80_v4,
   HLT_HT250_Mu15_PFMHT20_v2,
   HLT_HT250_Mu15_PFMHT20_v3,
   HLT_HT250_Mu15_PFMHT20_v4,
   HLT_HT250_Mu5_PFMHT35_v4,
   HLT_HT250_Mu5_PFMHT35_v5,
   HLT_HT250_Mu5_PFMHT35_v6,
   HLT_HT250_v4,
   HLT_HT250_v5,
   HLT_HT250_v6,
   HLT_HT300_AlphaT0p52_v3,
   HLT_HT300_AlphaT0p52_v4,
   HLT_HT300_AlphaT0p52_v5,
   HLT_HT300_AlphaT0p53_v2,
   HLT_HT300_AlphaT0p53_v3,
   HLT_HT300_AlphaT0p53_v4,
   HLT_HT300_CentralJet30_BTagIP_PFMHT55_v2,
   HLT_HT300_CentralJet30_BTagIP_PFMHT55_v3,
   HLT_HT300_CentralJet30_BTagIP_PFMHT55_v4,
   HLT_HT300_CentralJet30_BTagIP_PFMHT75_v2,
   HLT_HT300_CentralJet30_BTagIP_PFMHT75_v3,
   HLT_HT300_CentralJet30_BTagIP_PFMHT75_v4,
   HLT_HT300_CentralJet30_BTagIP_v2,
   HLT_HT300_CentralJet30_BTagIP_v3,
   HLT_HT300_CentralJet30_BTagIP_v4,
   HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v1,
   HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v3,
   HLT_HT300_DoubleIsoPFTau10_Trk3_PFMHT40_v4,
   HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v2,
   HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v3,
   HLT_HT300_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT40_v4,
   HLT_HT300_MHT75_v5,
   HLT_HT300_MHT75_v7,
   HLT_HT300_MHT75_v8,
   HLT_HT300_Mu5_PFMHT40_v2,
   HLT_HT300_Mu5_PFMHT40_v3,
   HLT_HT300_Mu5_PFMHT40_v4,
   HLT_HT300_PFMHT55_v2,
   HLT_HT300_PFMHT55_v3,
   HLT_HT300_PFMHT55_v4,
   HLT_HT300_v5,
   HLT_HT300_v6,
   HLT_HT300_v7,
   HLT_HT350_AlphaT0p51_v3,
   HLT_HT350_AlphaT0p51_v4,
   HLT_HT350_AlphaT0p51_v5,
   HLT_HT350_AlphaT0p53_v3,
   HLT_HT350_AlphaT0p53_v4,
   HLT_HT350_AlphaT0p53_v5,
   HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v1,
   HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v3,
   HLT_HT350_DoubleIsoPFTau10_Trk3_PFMHT45_v4,
   HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v2,
   HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v3,
   HLT_HT350_Ele5_CaloIdVL_TrkIdVL_CaloIsoVL_TrkIsoVL_PFMHT45_v4,
   HLT_HT350_Mu5_PFMHT45_v2,
   HLT_HT350_Mu5_PFMHT45_v3,
   HLT_HT350_Mu5_PFMHT45_v4,
   HLT_HT350_v4,
   HLT_HT350_v5,
   HLT_HT350_v6,
   HLT_HT400_AlphaT0p51_v3,
   HLT_HT400_AlphaT0p51_v4,
   HLT_HT400_AlphaT0p51_v5,
   HLT_HT400_v4,
   HLT_HT400_v5,
   HLT_HT400_v6,
   HLT_HT450_v4,
   HLT_HT450_v5,
   HLT_HT450_v6,
   HLT_HT500_v4,
   HLT_HT500_v5,
   HLT_HT500_v6,
   HLT_HT550_v4,
   HLT_HT550_v5,
   HLT_HT550_v6,
   HLT_HcalCalibration_v2,
   HLT_HcalNZS_v4,
   HLT_HcalNZS_v5,
   HLT_HcalNZS_vDEAD,
   HLT_HcalPhiSym_v4,
   HLT_HcalPhiSym_v5,
   HLT_HcalPhiSym_vDEAD,
   HLT_IsoMu12_v4,
   HLT_IsoMu12_v5,
   HLT_IsoMu12_v6,
   HLT_IsoMu15_LooseIsoPFTau15_v2,
   HLT_IsoMu15_LooseIsoPFTau15_v4,
   HLT_IsoMu15_LooseIsoPFTau15_v5,
   HLT_IsoMu15_LooseIsoPFTau20_v2,
   HLT_IsoMu15_LooseIsoPFTau20_v3,
   HLT_IsoMu15_TightIsoPFTau20_v2,
   HLT_IsoMu15_TightIsoPFTau20_v3,
   HLT_IsoMu15_v10,
   HLT_IsoMu15_v8,
   HLT_IsoMu15_v9,
   HLT_IsoMu17_CentralJet30_BTagIP_v4,
   HLT_IsoMu17_CentralJet30_BTagIP_v5,
   HLT_IsoMu17_CentralJet30_BTagIP_v6,
   HLT_IsoMu17_CentralJet30_v1,
   HLT_IsoMu17_CentralJet30_v2,
   HLT_IsoMu17_DiCentralJet30_v1,
   HLT_IsoMu17_DiCentralJet30_v2,
   HLT_IsoMu17_QuadCentralJet30_v1,
   HLT_IsoMu17_QuadCentralJet30_v2,
   HLT_IsoMu17_TriCentralJet30_v1,
   HLT_IsoMu17_TriCentralJet30_v2,
   HLT_IsoMu17_v10,
   HLT_IsoMu17_v8,
   HLT_IsoMu17_v9,
   HLT_IsoMu24_v4,
   HLT_IsoMu24_v5,
   HLT_IsoMu24_v6,
   HLT_IsoMu30_v4,
   HLT_IsoMu30_v5,
   HLT_IsoMu30_v6,
   HLT_IsoPFTau35_Trk20_MET45_v6,
   HLT_IsoPFTau35_Trk20_MET60_v2,
   HLT_IsoPFTau35_Trk20_MET60_v3,
   HLT_IsoPFTau35_Trk20_v2,
   HLT_IsoPFTau35_Trk20_v3,
   HLT_IsoPFTau45_Trk20_MET60_v2,
   HLT_IsoPFTau45_Trk20_MET60_v3,
   HLT_IsoTrackHB_v3,
   HLT_IsoTrackHB_v4,
   HLT_IsoTrackHE_v4,
   HLT_IsoTrackHE_v5,
   HLT_Jet110_v3,
   HLT_Jet110_v4,
   HLT_Jet110_v5,
   HLT_Jet150_v3,
   HLT_Jet150_v4,
   HLT_Jet150_v5,
   HLT_Jet190_v3,
   HLT_Jet190_v4,
   HLT_Jet190_v5,
   HLT_Jet240_v3,
   HLT_Jet240_v4,
   HLT_Jet240_v5,
   HLT_Jet300_v2,
   HLT_Jet300_v3,
   HLT_Jet300_v4,
   HLT_Jet30_v3,
   HLT_Jet30_v4,
   HLT_Jet30_v5,
   HLT_Jet370_NoJetID_v3,
   HLT_Jet370_NoJetID_v4,
   HLT_Jet370_NoJetID_v5,
   HLT_Jet370_v3,
   HLT_Jet370_v4,
   HLT_Jet370_v5,
   HLT_Jet60_v3,
   HLT_Jet60_v4,
   HLT_Jet60_v5,
   HLT_Jet80_v3,
   HLT_Jet80_v4,
   HLT_Jet80_v5,
   HLT_JetE30_NoBPTX3BX_NoHalo_v5,
   HLT_JetE30_NoBPTX3BX_NoHalo_v6,
   HLT_JetE30_NoBPTX_NoHalo_v5,
   HLT_JetE30_NoBPTX_NoHalo_v6,
   HLT_JetE30_NoBPTX_v3,
   HLT_JetE30_NoBPTX_v4,
   HLT_JetE50_NoBPTX3BX_NoHalo_v1,
   HLT_JetE50_NoBPTX3BX_NoHalo_v2,
   HLT_L1DoubleJet36Central_v2,
   HLT_L1DoubleJet36Central_v3,
   HLT_L1DoubleMu0_v2,
   HLT_L1DoubleMu0_v3,
   HLT_L1ETM30_v2,
   HLT_L1ETM30_v3,
   HLT_L1MultiJet_v2,
   HLT_L1MultiJet_v3,
   HLT_L1SingleEG12_v2,
   HLT_L1SingleEG5_v2,
   HLT_L1SingleJet16_v2,
   HLT_L1SingleJet16_v3,
   HLT_L1SingleJet36_v2,
   HLT_L1SingleJet36_v3,
   HLT_L1SingleMu10_v2,
   HLT_L1SingleMu10_v3,
   HLT_L1SingleMu20_v2,
   HLT_L1SingleMu20_v3,
   HLT_L1SingleMuOpen_AntiBPTX_v2,
   HLT_L1SingleMuOpen_DT_v2,
   HLT_L1SingleMuOpen_DT_v3,
   HLT_L1SingleMuOpen_v2,
   HLT_L1SingleMuOpen_v3,
   HLT_L1Tech_BSC_halo_v4,
   HLT_L1Tech_BSC_minBias_threshold1_v4,
   HLT_L1Tech_HBHEHO_totalOR_v2,
   HLT_L1TrackerCosmics_v3,
   HLT_L1_Interbunch_BSC_v2,
   HLT_L1_PreCollisions_v2,
   HLT_L2DoubleMu0_v4,
   HLT_L2DoubleMu0_v5,
   HLT_L2DoubleMu23_NoVertex_v3,
   HLT_L2DoubleMu23_NoVertex_v4,
   HLT_L2Mu10_v3,
   HLT_L2Mu10_v4,
   HLT_L2Mu20_v3,
   HLT_L2Mu20_v4,
   HLT_L2Mu60_1Hit_MET40_v1,
   HLT_L2Mu60_1Hit_MET40_v2,
   HLT_L2Mu60_1Hit_MET60_v1,
   HLT_L2Mu60_1Hit_MET60_v2,
   HLT_L3MuonsCosmicTracking_v3,
   HLT_MET100_HBHENoiseFiltered_v2,
   HLT_MET100_HBHENoiseFiltered_v3,
   HLT_MET100_v4,
   HLT_MET100_v5,
   HLT_MET120_HBHENoiseFiltered_v2,
   HLT_MET120_HBHENoiseFiltered_v3,
   HLT_MET120_v4,
   HLT_MET120_v5,
   HLT_MET200_HBHENoiseFiltered_v2,
   HLT_MET200_HBHENoiseFiltered_v3,
   HLT_MET200_v3,
   HLT_MET200_v4,
   HLT_MET200_v5,
   HLT_MET65_HBHENoiseFiltered_v1,
   HLT_MET65_HBHENoiseFiltered_v2,
   HLT_MET65_v1,
   HLT_MET65_v2,
   HLT_Mu100_v1,
   HLT_Mu100_v2,
   HLT_Mu12_CentralJet30_BTagIP_v2,
   HLT_Mu12_CentralJet30_BTagIP_v4,
   HLT_Mu12_DiCentralJet30_BTagIP3D_v1,
   HLT_Mu12_DiCentralJet30_BTagIP3D_v2,
   HLT_Mu12_v3,
   HLT_Mu12_v4,
   HLT_Mu13_Mu8_v2,
   HLT_Mu13_Mu8_v3,
   HLT_Mu15_DoublePhoton15_CaloIdL_v5,
   HLT_Mu15_DoublePhoton15_CaloIdL_v6,
   HLT_Mu15_HT200_v2,
   HLT_Mu15_HT200_v3,
   HLT_Mu15_HT200_v4,
   HLT_Mu15_LooseIsoPFTau15_v2,
   HLT_Mu15_LooseIsoPFTau15_v4,
   HLT_Mu15_LooseIsoPFTau15_v5,
   HLT_Mu15_Photon20_CaloIdL_v5,
   HLT_Mu15_Photon20_CaloIdL_v6,
   HLT_Mu15_v4,
   HLT_Mu15_v5,
   HLT_Mu17_CentralJet30_BTagIP_v4,
   HLT_Mu17_CentralJet30_BTagIP_v5,
   HLT_Mu17_CentralJet30_BTagIP_v6,
   HLT_Mu17_CentralJet30_v5,
   HLT_Mu17_CentralJet30_v6,
   HLT_Mu17_CentralJet30_v7,
   HLT_Mu17_DiCentralJet30_v5,
   HLT_Mu17_DiCentralJet30_v6,
   HLT_Mu17_DiCentralJet30_v7,
   HLT_Mu17_Ele8_CaloIdL_v4,
   HLT_Mu17_Ele8_CaloIdL_v5,
   HLT_Mu17_Mu8_v2,
   HLT_Mu17_Mu8_v3,
   HLT_Mu17_QuadCentralJet30_v1,
   HLT_Mu17_QuadCentralJet30_v2,
   HLT_Mu17_TriCentralJet30_v5,
   HLT_Mu17_TriCentralJet30_v6,
   HLT_Mu17_TriCentralJet30_v7,
   HLT_Mu20_HT200_v2,
   HLT_Mu20_HT200_v3,
   HLT_Mu20_HT200_v4,
   HLT_Mu20_v3,
   HLT_Mu20_v4,
   HLT_Mu24_v3,
   HLT_Mu24_v4,
   HLT_Mu30_v3,
   HLT_Mu30_v4,
   HLT_Mu3_DiJet30_v1,
   HLT_Mu3_DiJet30_v2,
   HLT_Mu3_DiJet30_v3,
   HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v2,
   HLT_Mu3_Ele8_CaloIdL_TrkIdVL_HT150_v3,
   HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v2,
   HLT_Mu3_Ele8_CaloIdT_TrkIdVL_HT150_v3,
   HLT_Mu3_QuadJet30_v1,
   HLT_Mu3_QuadJet30_v2,
   HLT_Mu3_QuadJet30_v3,
   HLT_Mu3_TriJet30_v1,
   HLT_Mu3_TriJet30_v2,
   HLT_Mu3_TriJet30_v3,
   HLT_Mu3_v5,
   HLT_Mu3_v6,
   HLT_Mu40_v1,
   HLT_Mu40_v2,
   HLT_Mu5_DoubleEle8_CaloIdL_TrkIdVL_v1,
   HLT_Mu5_DoubleEle8_CaloIdL_TrkIdVL_v2,
   HLT_Mu5_Ele8_CaloIdL_TrkIdVL_Ele8_v5,
   HLT_Mu5_L2Mu2_Jpsi_v4,
   HLT_Mu5_L2Mu2_Jpsi_v5,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v4,
   HLT_Mu5_TkMu0_OST_Jpsi_Tight_B5Q7_v5,
   HLT_Mu5_Track2_Jpsi_v4,
   HLT_Mu5_Track2_Jpsi_v5,
   HLT_Mu5_v5,
   HLT_Mu5_v6,
   HLT_Mu7_Track7_Jpsi_v5,
   HLT_Mu7_Track7_Jpsi_v6,
   HLT_Mu8_Ele17_CaloIdL_v4,
   HLT_Mu8_Ele17_CaloIdL_v5,
   HLT_Mu8_Jet40_v5,
   HLT_Mu8_Jet40_v6,
   HLT_Mu8_Photon20_CaloIdVT_IsoT_v4,
   HLT_Mu8_Photon20_CaloIdVT_IsoT_v5,
   HLT_Mu8_R005_MR200_v1,
   HLT_Mu8_R005_MR200_v3,
   HLT_Mu8_R005_MR200_v4,
   HLT_Mu8_R020_MR200_v1,
   HLT_Mu8_R020_MR200_v3,
   HLT_Mu8_R020_MR200_v4,
   HLT_Mu8_R025_MR200_v1,
   HLT_Mu8_R025_MR200_v3,
   HLT_Mu8_R025_MR200_v4,
   HLT_Mu8_v3,
   HLT_Mu8_v4,
   HLT_PFMHT150_v6,
   HLT_PFMHT150_v7,
   HLT_PFMHT150_v8,
   HLT_Photon125_v1,
   HLT_Photon125_v2,
   HLT_Photon200_NoHE_v1,
   HLT_Photon200_NoHE_v2,
   HLT_Photon20_CaloIdVL_IsoL_v3,
   HLT_Photon20_CaloIdVL_IsoL_v4,
   HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v4,
   HLT_Photon20_CaloIdVT_IsoT_Ele8_CaloIdL_CaloIsoVL_v5,
   HLT_Photon20_R9Id_Photon18_R9Id_v4,
   HLT_Photon20_R9Id_Photon18_R9Id_v5,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v4,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_CaloIdL_IsoVL_v5,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v3,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_R9Id_v4,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_v4,
   HLT_Photon26_CaloIdL_IsoVL_Photon18_v5,
   HLT_Photon26_IsoVL_Photon18_IsoVL_v4,
   HLT_Photon26_IsoVL_Photon18_IsoVL_v5,
   HLT_Photon26_IsoVL_Photon18_v4,
   HLT_Photon26_IsoVL_Photon18_v5,
   HLT_Photon26_Photon18_v4,
   HLT_Photon26_Photon18_v5,
   HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v3,
   HLT_Photon26_R9Id_Photon18_CaloIdL_IsoVL_v4,
   HLT_Photon26_R9Id_Photon18_R9Id_v1,
   HLT_Photon26_R9Id_Photon18_R9Id_v2,
   HLT_Photon30_CaloIdVL_IsoL_v4,
   HLT_Photon30_CaloIdVL_IsoL_v5,
   HLT_Photon30_CaloIdVL_v4,
   HLT_Photon30_CaloIdVL_v5,
   HLT_Photon32_CaloIdL_Photon26_CaloIdL_v4,
   HLT_Photon36_CaloIdL_IsoVL_Photon22_CaloIdL_IsoVL_v1,
   HLT_Photon36_CaloIdL_IsoVL_Photon22_CaloIdL_v1,
   HLT_Photon36_CaloIdL_IsoVL_Photon22_v1,
   HLT_Photon36_CaloIdL_IsoVL_Photon22_v2,
   HLT_Photon36_CaloIdL_Photon22_CaloIdL_v3,
   HLT_Photon36_CaloIdL_Photon22_CaloIdL_v4,
   HLT_Photon36_CaloId_IsoVL_Photon22_R9Id_v1,
   HLT_Photon36_IsoVL_Photon22_v1,
   HLT_Photon36_IsoVL_Photon22_v2,
   HLT_Photon36_R9Id_Photon22_CaloIdL_IsoVL_v1,
   HLT_Photon36_R9Id_Photon22_R9Id_v1,
   HLT_Photon40_CaloIdL_Photon28_CaloIdL_v1,
   HLT_Photon40_CaloIdL_Photon28_CaloIdL_v2,
   HLT_Photon40_R005_MR150_v1,
   HLT_Photon40_R005_MR150_v3,
   HLT_Photon40_R014_MR450_v1,
   HLT_Photon40_R014_MR450_v3,
   HLT_Photon40_R020_MR300_v1,
   HLT_Photon40_R020_MR300_v3,
   HLT_Photon40_R025_MR200_v1,
   HLT_Photon40_R025_MR200_v3,
   HLT_Photon40_R038_MR150_v1,
   HLT_Photon40_R038_MR150_v3,
   HLT_Photon50_CaloIdVL_IsoL_v3,
   HLT_Photon50_CaloIdVL_IsoL_v4,
   HLT_Photon50_CaloIdVL_v1,
   HLT_Photon50_CaloIdVL_v2,
   HLT_Photon70_CaloIdL_HT300_v4,
   HLT_Photon70_CaloIdL_HT300_v6,
   HLT_Photon70_CaloIdL_HT350_v3,
   HLT_Photon70_CaloIdL_HT350_v5,
   HLT_Photon70_CaloIdL_MHT50_v4,
   HLT_Photon70_CaloIdL_MHT50_v6,
   HLT_Photon70_CaloIdL_MHT70_v3,
   HLT_Photon70_CaloIdL_MHT70_v5,
   HLT_Photon75_CaloIdVL_IsoL_v4,
   HLT_Photon75_CaloIdVL_IsoL_v5,
   HLT_Photon75_CaloIdVL_v4,
   HLT_Photon75_CaloIdVL_v5,
   HLT_Photon90_CaloIdVL_IsoL_v1,
   HLT_Photon90_CaloIdVL_IsoL_v2,
   HLT_Photon90_CaloIdVL_v1,
   HLT_Photon90_CaloIdVL_v2,
   HLT_PixelTracks_Multiplicity100_v3,
   HLT_PixelTracks_Multiplicity100_v4,
   HLT_PixelTracks_Multiplicity80_v3,
   HLT_PixelTracks_Multiplicity80_v4,
   HLT_QuadJet40_IsoPFTau40_v5,
   HLT_QuadJet40_IsoPFTau40_v7,
   HLT_QuadJet40_IsoPFTau40_v8,
   HLT_QuadJet40_v4,
   HLT_QuadJet40_v5,
   HLT_QuadJet40_v6,
   HLT_QuadJet45_IsoPFTau45_v2,
   HLT_QuadJet45_IsoPFTau45_v3,
   HLT_QuadJet50_BTagIP_v4,
   HLT_QuadJet50_Jet40_Jet30_v1,
   HLT_QuadJet50_Jet40_Jet30_v2,
   HLT_QuadJet50_Jet40_v3,
   HLT_QuadJet60_v3,
   HLT_QuadJet60_v4,
   HLT_QuadJet60_v5,
   HLT_QuadJet70_v3,
   HLT_QuadJet70_v4,
   HLT_QuadJet70_v5,
   HLT_R014_MR150_CentralJet40_BTagIP_v2,
   HLT_R014_MR150_CentralJet40_BTagIP_v4,
   HLT_R014_MR150_CentralJet40_BTagIP_v5,
   HLT_R014_MR150_v1,
   HLT_R014_MR150_v3,
   HLT_R014_MR150_v4,
   HLT_R014_MR450_CentralJet40_BTagIP_v2,
   HLT_R014_MR450_CentralJet40_BTagIP_v4,
   HLT_R014_MR450_CentralJet40_BTagIP_v5,
   HLT_R020_MR150_v1,
   HLT_R020_MR150_v3,
   HLT_R020_MR150_v4,
   HLT_R020_MR350_CentralJet40_BTagIP_v2,
   HLT_R020_MR350_CentralJet40_BTagIP_v4,
   HLT_R020_MR350_CentralJet40_BTagIP_v5,
   HLT_R020_MR500_v1,
   HLT_R020_MR500_v3,
   HLT_R020_MR500_v4,
   HLT_R020_MR550_v1,
   HLT_R020_MR550_v3,
   HLT_R020_MR550_v4,
   HLT_R025_MR150_v1,
   HLT_R025_MR150_v3,
   HLT_R025_MR150_v4,
   HLT_R025_MR250_CentralJet40_BTagIP_v2,
   HLT_R025_MR250_CentralJet40_BTagIP_v4,
   HLT_R025_MR250_CentralJet40_BTagIP_v5,
   HLT_R025_MR400_v1,
   HLT_R025_MR400_v3,
   HLT_R025_MR400_v4,
   HLT_R025_MR450_v1,
   HLT_R025_MR450_v3,
   HLT_R025_MR450_v4,
   HLT_R033_MR300_v1,
   HLT_R033_MR300_v3,
   HLT_R033_MR300_v4,
   HLT_R033_MR350_v1,
   HLT_R033_MR350_v3,
   HLT_R033_MR350_v4,
   HLT_R038_MR200_v1,
   HLT_R038_MR200_v3,
   HLT_R038_MR200_v4,
   HLT_R038_MR250_v1,
   HLT_R038_MR250_v3,
   HLT_R038_MR250_v4,
   HLT_RegionalCosmicTracking_v3,
   HLT_RegionalCosmicTracking_v4,
   HLT_TrackerCalibration_v2,
   HLT_TripleEle10_CaloIdL_TrkIdVL_v4,
   HLT_TripleEle10_CaloIdL_TrkIdVL_v6,
   HLT_TripleMu5_v4,
   HLT_TripleMu5_v5,
   HLT_ZeroBias_v3
};
