#include "TTree.h"
#include "TChain.h"
#include "format.h"
#include "iostream"
#include "string.h"
#include "checkEvtTool.h"

using namespace std;

void example()
{

    bool debug=true;
    checkEvtTool checkEvt(debug); //or checkEvtTool checkEvt();
    checkEvt.addJson("Cert_254833_13TeV_PromptReco_Collisions15_JSON.txt");
    checkEvt.addJson("Cert_246908-254879_13TeV_PromptReco_Collisions15_JSON.txt");
    checkEvt.makeJsonMap();

    TChain *root = new TChain("bprimeKit/root");
    root->Add("bprimeKitTest.root");

    EvtInfoBranches EvtInfo;
    EvtInfo.Register(root);

    for(int entry=0;entry<root->GetEntries();entry++) {
        root->GetEntry(entry);
        if( !checkEvt.isGoodEvt(EvtInfo.RunNo,EvtInfo.LumiNo) ){
            //cout<<"Exulde: "<<EvtInfo.RunNo<<", "<<EvtInfo.LumiNo<<endl;
            continue;
        }
    }
    checkEvt.saveJson("Cert_246908-254833-254879_13TeV_PromptReco_Collisions15_JSON.txt");
}

